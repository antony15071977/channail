<?php 
$ag_index = 1;
include ('../../inc/db_conf.php');
include ('../../'.$ag_data_dir. '/'. $ag_config); 
include ('../../'.$ag_cfg_lng);// LNG
include ('../../inc/mobile_detect/mobile_detect.php'); 
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
	 <link rel="stylesheet" href="../../css/icons/fontello.css" />
	 <link rel="stylesheet" type="text/css" href="../../css/main.css" />
	 <link rel="stylesheet" type="text/css" href="../../css/style.css" />
	 <meta name="viewport" content="width=device-width, initial-scale=0.8, maximum-scale=0.8, user-scalable=no" />
<meta name="robots" content="noindex, nofollow" />

<title>Icons</title>

<script src="../../js/jquery-2.1.1.js"></script>
<script src="../../js/highlight.jquery.js"></script>
<script src="../../js/jquery.scrollTo.min.js"></script>

	 <script>
      function toggleCodes(on) {
        var obj = document.getElementById('icons');
        
        if (on) {
          obj.className += ' codesOn';
        } else {
          obj.className = obj.className.replace(' codesOn', '');
        }
      }
      
    </script>
	
<style>
.clearfix {
  *zoom: 1;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
  line-height: 0;
}
.clearfix:after {
  clear: both;
}

body {
  margin: 0;
  line-height: 20px;
  color: #333;
  background-color: #fff;
}

.row {
  margin-left: -20px;
  *zoom: 1;
}
.row:before,
.row:after {
  display: table;
  content: "";
  line-height: 0;
}
.row:after {
  clear: both;
}
[class*="span"] {
<?php $mob_detect = new Mobile_Detect; if ($mob_detect->isMobile()) { } else { echo 'float: left;'; }?> 
  min-height: 1px;
  margin-left: 20px;
}
.container,
.navbar-static-top .container,
.navbar-fixed-top .container,
.navbar-fixed-bottom .container {
  width: 940px;
}
.span12 {
  width: 940px;
}
.span11 {
  width: 860px;
}
.span10 {
  width: 780px;
}
.span9 {
  width: 700px;
}
.span8 {
  width: 620px;
}
.span7 {
  width: 540px;
}
.span6 {
  width: 460px;
}
.span5 {
  width: 380px;
}
.span4 {
  width: 300px;
}
.span3 {
  width: 220px;
}
.span2 {
  width: 140px;
}
.span1 {
  width: 60px;
}
[class*="span"].pull-right,
.row-fluid [class*="span"].pull-right {
  float: right;
}
.container {
  margin-right: auto;
  margin-left: auto;
  *zoom: 1;
}
.container:before,
.container:after {
  display: table;
  content: "";
  line-height: 0;
}
.container:after {
  clear: both;
}
p {
  margin: 0 0 10px;
}
.lead {
  margin-bottom: 20px;
  font-size: 21px;
  font-weight: 200;
  line-height: 30px;
}
small {
  font-size: 85%;
}
h1 {
  margin: 10px 0;
  font-family: inherit;
  font-weight: bold;
  line-height: 20px;
  color: inherit;
  text-rendering: optimizelegibility;
}
h1 small {
  font-weight: normal;
  line-height: 1;
  color: #999;
}
h1 {
  line-height: 40px;
}
h1 {
  font-size: 38.5px;
}
h1 small {
  font-size: 24.5px;
}
body {
  padding: 0;
}
.header {
  position: fixed;
  top: 0;
  left: 50%;
  margin-left: -480px;
  background-color: #fff;
  border-bottom: 1px solid #ddd;
  padding-top: 10px;
  z-index: 10;
}
.footer {
  color: #ddd;
  font-size: 12px;
  text-align: center;
  margin-top: 20px;
}
.footer a {
  color: #ccc;
  text-decoration: underline;
}
.the-icons {
  font-size: 14px;
  line-height: 24px;
  
}
.the-icons i, .the-icons span.i-name {cursor:pointer; transition: all 0.2s ease-in-out;}

.switch {
  position: absolute;
  right: 0;
  bottom: 10px;
  color: #666;
}
.switch input {
  margin-right: 0.3em;
}
.codesOn .i-name {
  display: none;
}
.codesOn .i-code {
  display: inline;
}
.i-code {
  display: none;
}
.ag_search_in_list {position:fixed; top:0; left:0; padding:0; width:100%; border-bottom: #E0E0E5 1px solid;}
.ag_search_in_list div {float:right; width:auto; display:inline-block; padding:8px;}
.ag_search_in_list input {padding:8px; background:#fff;}
.ag_search_in_list span {padding:8px;}
#icons_body {padding: 0 0 0 0;}
#icons {
position:absolute;
padding:0;
margin:0;
width:100%;
height: 100%;
max-height: 100%;
overflow-y: auto;
overflow-x: hidden;
}

<?php $mob_detect = new Mobile_Detect; if ($mob_detect->isMobile()) {  ?>
#icons div.ic_list {padding:16px; margin:0 auto; width:252px;}
.ag_search_in_list input {width:140px;}
<?php } else { ?>
#icons div.ic_list {padding:16px; margin:0 auto; width:972px;}
<?php } ?>
body {margin-top: 50px; padding:0;}
</style>	
	
	
</head>
<body>
<!--<label class="switch">
        <input type="checkbox" onclick="toggleCodes(this.checked)">код 
		</label> -->
	

<div class="ag_search_in_list" id="search_ic"><div>

<input type="text" id="ag_ic_inp" placeholder="" />
<span id="ic_search" onclick="ag_search_in_list('ag_ic_inp', 'icons_body', 'icons', 'ic_search', 'ic_next_search')"><?php echo $ag_lng['search']; ?><i class="icon-play-circled"></i></span>
<span id="ic_next_search" class="agt_search_next"><?php echo $ag_lng['next_search']; ?><i class="icon-forward-circled"></i></span>
<div class="clear"></div>

</div></div>

	
<div id="icons_body">	  

<div id="icons" class="container">
<div class="ic_list">

      <div class="row">
        <div title="Code: 0xe800" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search</span><span class="i-code">0xe800</span></div>
        <div title="Code: 0xe801" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail</span><span class="i-code">0xe801</span></div>
        <div title="Code: 0xe802" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart</span><span class="i-code">0xe802</span></div>
        <div title="Code: 0xe803" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-empty</span><span class="i-code">0xe803</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe804" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star</span><span class="i-code">0xe804</span></div>
        <div title="Code: 0xe805" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user</span><span class="i-code">0xe805</span></div>
        <div title="Code: 0xe806" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video</span><span class="i-code">0xe806</span></div>
        <div title="Code: 0xe807" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture</span><span class="i-code">0xe807</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe808" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-large"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-large</span><span class="i-code">0xe808</span></div>
        <div title="Code: 0xe809" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th</span><span class="i-code">0xe809</span></div>
        <div title="Code: 0xe80a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list</span><span class="i-code">0xe80a</span></div>
        <div title="Code: 0xe80b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok</span><span class="i-code">0xe80b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe80c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circle</span><span class="i-code">0xe80c</span></div>
        <div title="Code: 0xe80d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel</span><span class="i-code">0xe80d</span></div>
        <div title="Code: 0xe80e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circle</span><span class="i-code">0xe80e</span></div>
        <div title="Code: 0xe80f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-circle</span><span class="i-code">0xe80f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe810" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-circle</span><span class="i-code">0xe810</span></div>
        <div title="Code: 0xe811" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link</span><span class="i-code">0xe811</span></div>
        <div title="Code: 0xe812" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach</span><span class="i-code">0xe812</span></div>
        <div title="Code: 0xe813" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock</span><span class="i-code">0xe813</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe814" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open</span><span class="i-code">0xe814</span></div>
        <div title="Code: 0xe815" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag</span><span class="i-code">0xe815</span></div>
        <div title="Code: 0xe816" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply</span><span class="i-code">0xe816</span></div>
        <div title="Code: 0xe817" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-all"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-all</span><span class="i-code">0xe817</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe818" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward</span><span class="i-code">0xe818</span></div>
        <div title="Code: 0xe819" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-code"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-code</span><span class="i-code">0xe819</span></div>
        <div title="Code: 0xe81a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-retweet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-retweet</span><span class="i-code">0xe81a</span></div>
        <div title="Code: 0xe81b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment</span><span class="i-code">0xe81b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe81c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-alt</span><span class="i-code">0xe81c</span></div>
        <div title="Code: 0xe81d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat</span><span class="i-code">0xe81d</span></div>
        <div title="Code: 0xe81e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention</span><span class="i-code">0xe81e</span></div>
        <div title="Code: 0xe81f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location</span><span class="i-code">0xe81f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe820" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc</span><span class="i-code">0xe820</span></div>
        <div title="Code: 0xe821" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-docs-landscape"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-docs-landscape</span><span class="i-code">0xe821</span></div>
        <div title="Code: 0xe822" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder</span><span class="i-code">0xe822</span></div>
        <div title="Code: 0xe823" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-archive"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-archive</span><span class="i-code">0xe823</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe824" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss</span><span class="i-code">0xe824</span></div>
        <div title="Code: 0xe825" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-alt</span><span class="i-code">0xe825</span></div>
        <div title="Code: 0xe826" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog</span><span class="i-code">0xe826</span></div>
        <div title="Code: 0xe827" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-logout"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-logout</span><span class="i-code">0xe827</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe828" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock</span><span class="i-code">0xe828</span></div>
        <div title="Code: 0xe829" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block</span><span class="i-code">0xe829</span></div>
        <div title="Code: 0xe82a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full</span><span class="i-code">0xe82a</span></div>
        <div title="Code: 0xe82b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-circle</span><span class="i-code">0xe82b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe82c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup</span><span class="i-code">0xe82c</span></div>
        <div title="Code: 0xe82d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open</span><span class="i-code">0xe82d</span></div>
        <div title="Code: 0xe82e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open</span><span class="i-code">0xe82e</span></div>
        <div title="Code: 0xe82f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circle</span><span class="i-code">0xe82f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe830" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circle</span><span class="i-code">0xe830</span></div>
        <div title="Code: 0xe831" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circle</span><span class="i-code">0xe831</span></div>
        <div title="Code: 0xe832" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circle</span><span class="i-code">0xe832</span></div>
        <div title="Code: 0xe833" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-dir"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-dir</span><span class="i-code">0xe833</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe834" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-dir"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-dir</span><span class="i-code">0xe834</span></div>
        <div title="Code: 0xe835" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-micro"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-micro</span><span class="i-code">0xe835</span></div>
        <div title="Code: 0xe836" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-micro"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-micro</span><span class="i-code">0xe836</span></div>
        <div title="Code: 0xe837" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-circle</span><span class="i-code">0xe837</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe838" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-cw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-cw</span><span class="i-code">0xe838</span></div>
        <div title="Code: 0xe839" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-updown-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-updown-circle</span><span class="i-code">0xe839</span></div>
        <div title="Code: 0xe83a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target</span><span class="i-code">0xe83a</span></div>
        <div title="Code: 0xe83b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal</span><span class="i-code">0xe83b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe83c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-0"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-0</span><span class="i-code">0xe83c</span></div>
        <div title="Code: 0xe83d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-1</span><span class="i-code">0xe83d</span></div>
        <div title="Code: 0xe83e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-2</span><span class="i-code">0xe83e</span></div>
        <div title="Code: 0xe83f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-3</span><span class="i-code">0xe83f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe840" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-4</span><span class="i-code">0xe840</span></div>
        <div title="Code: 0xe841" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-5</span><span class="i-code">0xe841</span></div>
        <div title="Code: 0xe842" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-6</span><span class="i-code">0xe842</span></div>
        <div title="Code: 0xe843" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-7</span><span class="i-code">0xe843</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe844" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-font"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-font</span><span class="i-code">0xe844</span></div>
        <div title="Code: 0xe845" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list</span><span class="i-code">0xe845</span></div>
        <div title="Code: 0xe846" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-numbered"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-numbered</span><span class="i-code">0xe846</span></div>
        <div title="Code: 0xe847" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-left</span><span class="i-code">0xe847</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe848" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-right</span><span class="i-code">0xe848</span></div>
        <div title="Code: 0xe849" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud</span><span class="i-code">0xe849</span></div>
        <div title="Code: 0xe84a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-terminal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-terminal</span><span class="i-code">0xe84a</span></div>
        <div title="Code: 0xe84b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music</span><span class="i-code">0xe84b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe84c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-1</span><span class="i-code">0xe84c</span></div>
        <div title="Code: 0xe84d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-1</span><span class="i-code">0xe84d</span></div>
        <div title="Code: 0xe84e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-1</span><span class="i-code">0xe84e</span></div>
        <div title="Code: 0xe84f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-1</span><span class="i-code">0xe84f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe850" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-1</span><span class="i-code">0xe850</span></div>
        <div title="Code: 0xe851" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam</span><span class="i-code">0xe851</span></div>
        <div title="Code: 0xe852" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera</span><span class="i-code">0xe852</span></div>
        <div title="Code: 0xe853" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-photo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-photo</span><span class="i-code">0xe853</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe854" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-1</span><span class="i-code">0xe854</span></div>
        <div title="Code: 0xe855" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-1</span><span class="i-code">0xe855</span></div>
        <div title="Code: 0xe856" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye</span><span class="i-code">0xe856</span></div>
        <div title="Code: 0xe857" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-1</span><span class="i-code">0xe857</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe858" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up</span><span class="i-code">0xe858</span></div>
        <div title="Code: 0xe859" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil</span><span class="i-code">0xe859</span></div>
        <div title="Code: 0xe85a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-1</span><span class="i-code">0xe85a</span></div>
        <div title="Code: 0xe85b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-1</span><span class="i-code">0xe85b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe85c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cup"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cup</span><span class="i-code">0xe85c</span></div>
        <div title="Code: 0xe85d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash</span><span class="i-code">0xe85d</span></div>
        <div title="Code: 0xe85e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-1</span><span class="i-code">0xe85e</span></div>
        <div title="Code: 0xe85f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-note"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-note</span><span class="i-code">0xe85f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe860" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-1</span><span class="i-code">0xe860</span></div>
        <div title="Code: 0xe861" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-params"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-params</span><span class="i-code">0xe861</span></div>
        <div title="Code: 0xe862" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar</span><span class="i-code">0xe862</span></div>
        <div title="Code: 0xe863" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sound"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sound</span><span class="i-code">0xe863</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe864" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-1</span><span class="i-code">0xe864</span></div>
        <div title="Code: 0xe865" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lightbulb"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lightbulb</span><span class="i-code">0xe865</span></div>
        <div title="Code: 0xe866" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tv</span><span class="i-code">0xe866</span></div>
        <div title="Code: 0xe867" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-desktop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-desktop</span><span class="i-code">0xe867</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe868" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile</span><span class="i-code">0xe868</span></div>
        <div title="Code: 0xe869" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cd</span><span class="i-code">0xe869</span></div>
        <div title="Code: 0xe86a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox</span><span class="i-code">0xe86a</span></div>
        <div title="Code: 0xe86b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe</span><span class="i-code">0xe86b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe86c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-1</span><span class="i-code">0xe86c</span></div>
        <div title="Code: 0xe86d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane</span><span class="i-code">0xe86d</span></div>
        <div title="Code: 0xe86e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fire"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fire</span><span class="i-code">0xe86e</span></div>
        <div title="Code: 0xe86f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-graduation-cap"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-graduation-cap</span><span class="i-code">0xe86f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe870" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-megaphone"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-megaphone</span><span class="i-code">0xe870</span></div>
        <div title="Code: 0xe871" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-database"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-database</span><span class="i-code">0xe871</span></div>
        <div title="Code: 0xe872" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key</span><span class="i-code">0xe872</span></div>
        <div title="Code: 0xe873" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-beaker"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-beaker</span><span class="i-code">0xe873</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe874" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-truck"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-truck</span><span class="i-code">0xe874</span></div>
        <div title="Code: 0xe875" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-money"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-money</span><span class="i-code">0xe875</span></div>
        <div title="Code: 0xe876" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-food"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-food</span><span class="i-code">0xe876</span></div>
        <div title="Code: 0xe877" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shop</span><span class="i-code">0xe877</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe878" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-diamond"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-diamond</span><span class="i-code">0xe878</span></div>
        <div title="Code: 0xe879" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-t-shirt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-t-shirt</span><span class="i-code">0xe879</span></div>
        <div title="Code: 0xe87a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wallet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wallet</span><span class="i-code">0xe87a</span></div>
        <div title="Code: 0xe87b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-1</span><span class="i-code">0xe87b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe87c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wordpress"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wordpress</span><span class="i-code">0xe87c</span></div>
        <div title="Code: 0xe87d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-w3c"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-w3c</span><span class="i-code">0xe87d</span></div>
        <div title="Code: 0xe87e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vkontakte"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vkontakte</span><span class="i-code">0xe87e</span></div>
        <div title="Code: 0xe87f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo</span><span class="i-code">0xe87f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe880" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr</span><span class="i-code">0xe880</span></div>
        <div title="Code: 0xe881" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter</span><span class="i-code">0xe881</span></div>
        <div title="Code: 0xe882" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon</span><span class="i-code">0xe882</span></div>
        <div title="Code: 0xe883" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stackoverflow"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stackoverflow</span><span class="i-code">0xe883</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe884" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-slideshare"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-slideshare</span><span class="i-code">0xe884</span></div>
        <div title="Code: 0xe885" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-1</span><span class="i-code">0xe885</span></div>
        <div title="Code: 0xe886" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reddit"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reddit</span><span class="i-code">0xe886</span></div>
        <div title="Code: 0xe887" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest</span><span class="i-code">0xe887</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe888" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picasa"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picasa</span><span class="i-code">0xe888</span></div>
        <div title="Code: 0xe889" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-path"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-path</span><span class="i-code">0xe889</span></div>
        <div title="Code: 0xe88a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin</span><span class="i-code">0xe88a</span></div>
        <div title="Code: 0xe88b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram</span><span class="i-code">0xe88b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe88c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-googleplus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-googleplus</span><span class="i-code">0xe88c</span></div>
        <div title="Code: 0xe88d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-text"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-text</span><span class="i-code">0xe88d</span></div>
        <div title="Code: 0xe88e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github</span><span class="i-code">0xe88e</span></div>
        <div title="Code: 0xe88f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-friendfeed-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-friendfeed-rect</span><span class="i-code">0xe88f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe890" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-friendfeed"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-friendfeed</span><span class="i-code">0xe890</span></div>
        <div title="Code: 0xe891" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-foursquare"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-foursquare</span><span class="i-code">0xe891</span></div>
        <div title="Code: 0xe892" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr</span><span class="i-code">0xe892</span></div>
        <div title="Code: 0xe893" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook</span><span class="i-code">0xe893</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe894" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble</span><span class="i-code">0xe894</span></div>
        <div title="Code: 0xe895" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-digg"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-digg</span><span class="i-code">0xe895</span></div>
        <div title="Code: 0xe896" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-deviantart"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-deviantart</span><span class="i-code">0xe896</span></div>
        <div title="Code: 0xe897" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-delicious"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-delicious</span><span class="i-code">0xe897</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe898" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-css"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-css</span><span class="i-code">0xe898</span></div>
        <div title="Code: 0xe899" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc</span><span class="i-code">0xe899</span></div>
        <div title="Code: 0xe89a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blogger"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blogger</span><span class="i-code">0xe89a</span></div>
        <div title="Code: 0xe89b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-behance"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-behance</span><span class="i-code">0xe89b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe89c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-female"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-female</span><span class="i-code">0xe89c</span></div>
        <div title="Code: 0xe89d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-male"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-male</span><span class="i-code">0xe89d</span></div>
        <div title="Code: 0xe89e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-universal-access"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-universal-access</span><span class="i-code">0xe89e</span></div>
        <div title="Code: 0xe89f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-accessibility"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-accessibility</span><span class="i-code">0xe89f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8a0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-guidedog"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-guidedog</span><span class="i-code">0xe8a0</span></div>
        <div title="Code: 0xe8a1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blind"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blind</span><span class="i-code">0xe8a1</span></div>
        <div title="Code: 0xe8a2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-child"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-child</span><span class="i-code">0xe8a2</span></div>
        <div title="Code: 0xe8a3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-adult"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-adult</span><span class="i-code">0xe8a3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8a4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-person"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-person</span><span class="i-code">0xe8a4</span></div>
        <div title="Code: 0xe8a5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-iphone-home"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-iphone-home</span><span class="i-code">0xe8a5</span></div>
        <div title="Code: 0xe8a6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hearing-impaired"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hearing-impaired</span><span class="i-code">0xe8a6</span></div>
        <div title="Code: 0xe8a7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-glasses"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-glasses</span><span class="i-code">0xe8a7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8a8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-asl"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-asl</span><span class="i-code">0xe8a8</span></div>
        <div title="Code: 0xe8a9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-address-book-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-address-book-alt</span><span class="i-code">0xe8a9</span></div>
        <div title="Code: 0xe8aa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-address-book"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-address-book</span><span class="i-code">0xe8aa</span></div>
        <div title="Code: 0xe8ab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-smiley-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-smiley-circled</span><span class="i-code">0xe8ab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8ac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-smiley"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-smiley</span><span class="i-code">0xe8ac</span></div>
        <div title="Code: 0xe8ad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gauge"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gauge</span><span class="i-code">0xe8ad</span></div>
        <div title="Code: 0xe8ae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-braille"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-braille</span><span class="i-code">0xe8ae</span></div>
        <div title="Code: 0xe8af" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book</span><span class="i-code">0xe8af</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8b0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-adjust"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-adjust</span><span class="i-code">0xe8b0</span></div>
        <div title="Code: 0xe8b1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tint"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tint</span><span class="i-code">0xe8b1</span></div>
        <div title="Code: 0xe8b2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check</span><span class="i-code">0xe8b2</span></div>
        <div title="Code: 0xe8b3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-empty</span><span class="i-code">0xe8b3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8b4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-asterisk"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-asterisk</span><span class="i-code">0xe8b4</span></div>
        <div title="Code: 0xe8b5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gift"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gift</span><span class="i-code">0xe8b5</span></div>
        <div title="Code: 0xe8b6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fire-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fire-1</span><span class="i-code">0xe8b6</span></div>
        <div title="Code: 0xe8b7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-magnet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-magnet</span><span class="i-code">0xe8b7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8b8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart</span><span class="i-code">0xe8b8</span></div>
        <div title="Code: 0xe8b9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-circled</span><span class="i-code">0xe8b9</span></div>
        <div title="Code: 0xe8ba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card</span><span class="i-code">0xe8ba</span></div>
        <div title="Code: 0xe8bb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-megaphone-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-megaphone-1</span><span class="i-code">0xe8bb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8bc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clipboard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clipboard</span><span class="i-code">0xe8bc</span></div>
        <div title="Code: 0xe8bd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hdd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hdd</span><span class="i-code">0xe8bd</span></div>
        <div title="Code: 0xe8be" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-1</span><span class="i-code">0xe8be</span></div>
        <div title="Code: 0xe8bf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-certificate"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-certificate</span><span class="i-code">0xe8bf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8c0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tasks"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tasks</span><span class="i-code">0xe8c0</span></div>
        <div title="Code: 0xe8c1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-filter"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-filter</span><span class="i-code">0xe8c1</span></div>
        <div title="Code: 0xe8c2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flight"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flight</span><span class="i-code">0xe8c2</span></div>
        <div title="Code: 0xe8c3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-leaf"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-leaf</span><span class="i-code">0xe8c3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8c4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-font-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-font-1</span><span class="i-code">0xe8c4</span></div>
        <div title="Code: 0xe8c5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fontsize"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fontsize</span><span class="i-code">0xe8c5</span></div>
        <div title="Code: 0xe8c6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bold"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bold</span><span class="i-code">0xe8c6</span></div>
        <div title="Code: 0xe8c7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-italic"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-italic</span><span class="i-code">0xe8c7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8c8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-text-height"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-text-height</span><span class="i-code">0xe8c8</span></div>
        <div title="Code: 0xe8c9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-text-width"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-text-width</span><span class="i-code">0xe8c9</span></div>
        <div title="Code: 0xe8ca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-left</span><span class="i-code">0xe8ca</span></div>
        <div title="Code: 0xe8cb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-center"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-center</span><span class="i-code">0xe8cb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8cc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-right</span><span class="i-code">0xe8cc</span></div>
        <div title="Code: 0xe8cd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-justify"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-justify</span><span class="i-code">0xe8cd</span></div>
        <div title="Code: 0xe8ce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-1</span><span class="i-code">0xe8ce</span></div>
        <div title="Code: 0xe8cf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-left-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-left-1</span><span class="i-code">0xe8cf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8d0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-right-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-right-1</span><span class="i-code">0xe8d0</span></div>
        <div title="Code: 0xe8d1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-briefcase"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-briefcase</span><span class="i-code">0xe8d1</span></div>
        <div title="Code: 0xe8d2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-off</span><span class="i-code">0xe8d2</span></div>
        <div title="Code: 0xe8d3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-road"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-road</span><span class="i-code">0xe8d3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8d4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-qrcode"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-qrcode</span><span class="i-code">0xe8d4</span></div>
        <div title="Code: 0xe8d5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-barcode"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-barcode</span><span class="i-code">0xe8d5</span></div>
        <div title="Code: 0xe8d6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-circled</span><span class="i-code">0xe8d6</span></div>
        <div title="Code: 0xe8d7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-2</span><span class="i-code">0xe8d7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8d8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-alt</span><span class="i-code">0xe8d8</span></div>
        <div title="Code: 0xe8d9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-1</span><span class="i-code">0xe8d9</span></div>
        <div title="Code: 0xe8da" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-alt</span><span class="i-code">0xe8da</span></div>
        <div title="Code: 0xe8db" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-circled</span><span class="i-code">0xe8db</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8dc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-1</span><span class="i-code">0xe8dc</span></div>
        <div title="Code: 0xe8dd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-network"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-network</span><span class="i-code">0xe8dd</span></div>
        <div title="Code: 0xe8de" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-laptop-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-laptop-circled</span><span class="i-code">0xe8de</span></div>
        <div title="Code: 0xe8df" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-laptop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-laptop</span><span class="i-code">0xe8df</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8e0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-desktop-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-desktop-circled</span><span class="i-code">0xe8e0</span></div>
        <div title="Code: 0xe8e1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-desktop-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-desktop-1</span><span class="i-code">0xe8e1</span></div>
        <div title="Code: 0xe8e2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal-1</span><span class="i-code">0xe8e2</span></div>
        <div title="Code: 0xe8e3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-1</span><span class="i-code">0xe8e3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8e4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-step-forward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-step-forward</span><span class="i-code">0xe8e4</span></div>
        <div title="Code: 0xe8e5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-step-backward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-step-backward</span><span class="i-code">0xe8e5</span></div>
        <div title="Code: 0xe8e6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-circled</span><span class="i-code">0xe8e6</span></div>
        <div title="Code: 0xe8e7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-1</span><span class="i-code">0xe8e7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8e8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-forward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-forward</span><span class="i-code">0xe8e8</span></div>
        <div title="Code: 0xe8e9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-backward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-backward</span><span class="i-code">0xe8e9</span></div>
        <div title="Code: 0xe8ea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-backward-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-backward-circled</span><span class="i-code">0xe8ea</span></div>
        <div title="Code: 0xe8eb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-backward"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-backward</span><span class="i-code">0xe8eb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8ec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject</span><span class="i-code">0xe8ec</span></div>
        <div title="Code: 0xe8ed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-record"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-record</span><span class="i-code">0xe8ed</span></div>
        <div title="Code: 0xe8ee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-circled</span><span class="i-code">0xe8ee</span></div>
        <div title="Code: 0xe8ef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause</span><span class="i-code">0xe8ef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8f0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-circled</span><span class="i-code">0xe8f0</span></div>
        <div title="Code: 0xe8f1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop</span><span class="i-code">0xe8f1</span></div>
        <div title="Code: 0xe8f2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-circled2</span><span class="i-code">0xe8f2</span></div>
        <div title="Code: 0xe8f3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-circled</span><span class="i-code">0xe8f3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8f4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play</span><span class="i-code">0xe8f4</span></div>
        <div title="Code: 0xe8f5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shuffle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shuffle</span><span class="i-code">0xe8f5</span></div>
        <div title="Code: 0xe8f6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-cw-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-cw-1</span><span class="i-code">0xe8f6</span></div>
        <div title="Code: 0xe8f7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-circled</span><span class="i-code">0xe8f7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8f8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw</span><span class="i-code">0xe8f8</span></div>
        <div title="Code: 0xe8f9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-hand"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-hand</span><span class="i-code">0xe8f9</span></div>
        <div title="Code: 0xe8fa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-hand"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-hand</span><span class="i-code">0xe8fa</span></div>
        <div title="Code: 0xe8fb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-hand"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-hand</span><span class="i-code">0xe8fb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe8fc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-hand"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-hand</span><span class="i-code">0xe8fc</span></div>
        <div title="Code: 0xe8fd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circled</span><span class="i-code">0xe8fd</span></div>
        <div title="Code: 0xe8fe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-1</span><span class="i-code">0xe8fe</span></div>
        <div title="Code: 0xe8ff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-1</span><span class="i-code">0xe8ff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe900" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-alt</span><span class="i-code">0xe900</span></div>
        <div title="Code: 0xe901" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small</span><span class="i-code">0xe901</span></div>
        <div title="Code: 0xe902" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-vertical"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-vertical</span><span class="i-code">0xe902</span></div>
        <div title="Code: 0xe903" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-horizontal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-horizontal</span><span class="i-code">0xe903</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe904" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-move"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-move</span><span class="i-code">0xe904</span></div>
        <div title="Code: 0xe905" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in</span><span class="i-code">0xe905</span></div>
        <div title="Code: 0xe906" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out</span><span class="i-code">0xe906</span></div>
        <div title="Code: 0xe907" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open</span><span class="i-code">0xe907</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe908" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-1</span><span class="i-code">0xe908</span></div>
        <div title="Code: 0xe909" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-1</span><span class="i-code">0xe909</span></div>
        <div title="Code: 0xe90a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open</span><span class="i-code">0xe90a</span></div>
        <div title="Code: 0xe90b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down</span><span class="i-code">0xe90b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe90c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left</span><span class="i-code">0xe90c</span></div>
        <div title="Code: 0xe90d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right</span><span class="i-code">0xe90d</span></div>
        <div title="Code: 0xe90e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up</span><span class="i-code">0xe90e</span></div>
        <div title="Code: 0xe90f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circled</span><span class="i-code">0xe90f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe910" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circled</span><span class="i-code">0xe910</span></div>
        <div title="Code: 0xe911" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circled</span><span class="i-code">0xe911</span></div>
        <div title="Code: 0xe912" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lightbulb-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lightbulb-alt</span><span class="i-code">0xe912</span></div>
        <div title="Code: 0xe913" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lightbulb-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lightbulb-1</span><span class="i-code">0xe913</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe914" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-circled</span><span class="i-code">0xe914</span></div>
        <div title="Code: 0xe915" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-2</span><span class="i-code">0xe915</span></div>
        <div title="Code: 0xe916" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-headphones"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-headphones</span><span class="i-code">0xe916</span></div>
        <div title="Code: 0xe917" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-up</span><span class="i-code">0xe917</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe918" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume</span><span class="i-code">0xe918</span></div>
        <div title="Code: 0xe919" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-down</span><span class="i-code">0xe919</span></div>
        <div title="Code: 0xe91a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-off</span><span class="i-code">0xe91a</span></div>
        <div title="Code: 0xe91b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-circled</span><span class="i-code">0xe91b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe91c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic</span><span class="i-code">0xe91c</span></div>
        <div title="Code: 0xe91d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-circled</span><span class="i-code">0xe91d</span></div>
        <div title="Code: 0xe91e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-1</span><span class="i-code">0xe91e</span></div>
        <div title="Code: 0xe91f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-circled</span><span class="i-code">0xe91f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe920" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket</span><span class="i-code">0xe920</span></div>
        <div title="Code: 0xe921" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-circled</span><span class="i-code">0xe921</span></div>
        <div title="Code: 0xe922" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench</span><span class="i-code">0xe922</span></div>
        <div title="Code: 0xe923" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cogs"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cogs</span><span class="i-code">0xe923</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe924" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-circled</span><span class="i-code">0xe924</span></div>
        <div title="Code: 0xe925" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-2</span><span class="i-code">0xe925</span></div>
        <div title="Code: 0xe926" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-exclamation"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-exclamation</span><span class="i-code">0xe926</span></div>
        <div title="Code: 0xe927" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-error"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-error</span><span class="i-code">0xe927</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe928" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-error-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-error-alt</span><span class="i-code">0xe928</span></div>
        <div title="Code: 0xe929" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-2</span><span class="i-code">0xe929</span></div>
        <div title="Code: 0xe92a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-circled</span><span class="i-code">0xe92a</span></div>
        <div title="Code: 0xe92b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass</span><span class="i-code">0xe92b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe92c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-circled</span><span class="i-code">0xe92c</span></div>
        <div title="Code: 0xe92d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-1</span><span class="i-code">0xe92d</span></div>
        <div title="Code: 0xe92e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-circled</span><span class="i-code">0xe92e</span></div>
        <div title="Code: 0xe92f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-2</span><span class="i-code">0xe92f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe930" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-circled</span><span class="i-code">0xe930</span></div>
        <div title="Code: 0xe931" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-new"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-new</span><span class="i-code">0xe931</span></div>
        <div title="Code: 0xe932" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-new-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-new-circled</span><span class="i-code">0xe932</span></div>
        <div title="Code: 0xe933" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-1</span><span class="i-code">0xe933</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe934" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-circled</span><span class="i-code">0xe934</span></div>
        <div title="Code: 0xe935" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-close"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-close</span><span class="i-code">0xe935</span></div>
        <div title="Code: 0xe936" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-open</span><span class="i-code">0xe936</span></div>
        <div title="Code: 0xe937" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-1</span><span class="i-code">0xe937</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe938" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone</span><span class="i-code">0xe938</span></div>
        <div title="Code: 0xe939" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-circled</span><span class="i-code">0xe939</span></div>
        <div title="Code: 0xe93a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-warning"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-warning</span><span class="i-code">0xe93a</span></div>
        <div title="Code: 0xe93b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell</span><span class="i-code">0xe93b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe93c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-alt-1</span><span class="i-code">0xe93c</span></div>
        <div title="Code: 0xe93d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-2</span><span class="i-code">0xe93d</span></div>
        <div title="Code: 0xe93e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-retweet-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-retweet-1</span><span class="i-code">0xe93e</span></div>
        <div title="Code: 0xe93f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print</span><span class="i-code">0xe93f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe940" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit-alt</span><span class="i-code">0xe940</span></div>
        <div title="Code: 0xe941" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit-circled</span><span class="i-code">0xe941</span></div>
        <div title="Code: 0xe942" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit</span><span class="i-code">0xe942</span></div>
        <div title="Code: 0xe943" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-circled</span><span class="i-code">0xe943</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe944" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-1</span><span class="i-code">0xe944</span></div>
        <div title="Code: 0xe945" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export</span><span class="i-code">0xe945</span></div>
        <div title="Code: 0xe946" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-circled</span><span class="i-code">0xe946</span></div>
        <div title="Code: 0xe947" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote</span><span class="i-code">0xe947</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe948" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-share"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-share</span><span class="i-code">0xe948</span></div>
        <div title="Code: 0xe949" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload</span><span class="i-code">0xe949</span></div>
        <div title="Code: 0xe94a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-alt</span><span class="i-code">0xe94a</span></div>
        <div title="Code: 0xe94b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download</span><span class="i-code">0xe94b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe94c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down</span><span class="i-code">0xe94c</span></div>
        <div title="Code: 0xe94d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-1</span><span class="i-code">0xe94d</span></div>
        <div title="Code: 0xe94e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-circled</span><span class="i-code">0xe94e</span></div>
        <div title="Code: 0xe94f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-circled</span><span class="i-code">0xe94f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe950" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home</span><span class="i-code">0xe950</span></div>
        <div title="Code: 0xe951" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-circled</span><span class="i-code">0xe951</span></div>
        <div title="Code: 0xe952" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-website"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-website</span><span class="i-code">0xe952</span></div>
        <div title="Code: 0xe953" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-website-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-website-circled</span><span class="i-code">0xe953</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe954" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-2</span><span class="i-code">0xe954</span></div>
        <div title="Code: 0xe955" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-circled</span><span class="i-code">0xe955</span></div>
        <div title="Code: 0xe956" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-2</span><span class="i-code">0xe956</span></div>
        <div title="Code: 0xe957" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-circled</span><span class="i-code">0xe957</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe958" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-1</span><span class="i-code">0xe958</span></div>
        <div title="Code: 0xe959" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-alt</span><span class="i-code">0xe959</span></div>
        <div title="Code: 0xe95a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-1</span><span class="i-code">0xe95a</span></div>
        <div title="Code: 0xe95b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-off</span><span class="i-code">0xe95b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe95c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-2</span><span class="i-code">0xe95c</span></div>
        <div title="Code: 0xe95d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tags"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tags</span><span class="i-code">0xe95d</span></div>
        <div title="Code: 0xe95e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark</span><span class="i-code">0xe95e</span></div>
        <div title="Code: 0xe95f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark-empty</span><span class="i-code">0xe95f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe960" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag</span><span class="i-code">0xe960</span></div>
        <div title="Code: 0xe961" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-circled</span><span class="i-code">0xe961</span></div>
        <div title="Code: 0xe962" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help</span><span class="i-code">0xe962</span></div>
        <div title="Code: 0xe963" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-circled</span><span class="i-code">0xe963</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe964" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus</span><span class="i-code">0xe964</span></div>
        <div title="Code: 0xe965" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-circled</span><span class="i-code">0xe965</span></div>
        <div title="Code: 0xe966" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus</span><span class="i-code">0xe966</span></div>
        <div title="Code: 0xe967" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled2</span><span class="i-code">0xe967</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe968" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled</span><span class="i-code">0xe968</span></div>
        <div title="Code: 0xe969" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-1</span><span class="i-code">0xe969</span></div>
        <div title="Code: 0xe96a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circled2</span><span class="i-code">0xe96a</span></div>
        <div title="Code: 0xe96b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circled</span><span class="i-code">0xe96b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe96c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-1</span><span class="i-code">0xe96c</span></div>
        <div title="Code: 0xe96d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-view-mode"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-view-mode</span><span class="i-code">0xe96d</span></div>
        <div title="Code: 0xe96e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-1</span><span class="i-code">0xe96e</span></div>
        <div title="Code: 0xe96f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-1</span><span class="i-code">0xe96f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe970" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-large-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-large-1</span><span class="i-code">0xe970</span></div>
        <div title="Code: 0xe971" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-photo-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-photo-circled</span><span class="i-code">0xe971</span></div>
        <div title="Code: 0xe972" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-photo-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-photo-1</span><span class="i-code">0xe972</span></div>
        <div title="Code: 0xe973" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-1</span><span class="i-code">0xe973</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe974" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-1</span><span class="i-code">0xe974</span></div>
        <div title="Code: 0xe975" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-chat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-chat</span><span class="i-code">0xe975</span></div>
        <div title="Code: 0xe976" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-glass"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-glass</span><span class="i-code">0xe976</span></div>
        <div title="Code: 0xe977" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music-1</span><span class="i-code">0xe977</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe978" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-2</span><span class="i-code">0xe978</span></div>
        <div title="Code: 0xe979" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-circled</span><span class="i-code">0xe979</span></div>
        <div title="Code: 0xe97a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-2</span><span class="i-code">0xe97a</span></div>
        <div title="Code: 0xe97b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-circled</span><span class="i-code">0xe97b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe97c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-2</span><span class="i-code">0xe97c</span></div>
        <div title="Code: 0xe97d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-circled</span><span class="i-code">0xe97d</span></div>
        <div title="Code: 0xe97e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-empty-1</span><span class="i-code">0xe97e</span></div>
        <div title="Code: 0xe97f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-2</span><span class="i-code">0xe97f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe980" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-circled</span><span class="i-code">0xe980</span></div>
        <div title="Code: 0xe981" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-empty</span><span class="i-code">0xe981</span></div>
        <div title="Code: 0xe982" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-2</span><span class="i-code">0xe982</span></div>
        <div title="Code: 0xe983" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-group"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-group</span><span class="i-code">0xe983</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe984" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-group-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-group-circled</span><span class="i-code">0xe984</span></div>
        <div title="Code: 0xe985" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-torso"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-torso</span><span class="i-code">0xe985</span></div>
        <div title="Code: 0xe986" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-1</span><span class="i-code">0xe986</span></div>
        <div title="Code: 0xe987" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-circled</span><span class="i-code">0xe987</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe988" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-alt</span><span class="i-code">0xe988</span></div>
        <div title="Code: 0xe989" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-1</span><span class="i-code">0xe989</span></div>
        <div title="Code: 0xe98a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-friendfeed-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-friendfeed-rect-1</span><span class="i-code">0xe98a</span></div>
        <div title="Code: 0xe98b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-friendfeed-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-friendfeed-1</span><span class="i-code">0xe98b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe98c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-odnoklassniki-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-odnoklassniki-rect-1</span><span class="i-code">0xe98c</span></div>
        <div title="Code: 0xe98d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vkontakte-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vkontakte-rect-1</span><span class="i-code">0xe98d</span></div>
        <div title="Code: 0xe98e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-2</span><span class="i-code">0xe98e</span></div>
        <div title="Code: 0xe98f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-googleplus-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-googleplus-rect-1</span><span class="i-code">0xe98f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe990" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-rect-1</span><span class="i-code">0xe990</span></div>
        <div title="Code: 0xe991" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-rect-1</span><span class="i-code">0xe991</span></div>
        <div title="Code: 0xe992" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-bird-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-bird-1</span><span class="i-code">0xe992</span></div>
        <div title="Code: 0xe993" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-rect-1</span><span class="i-code">0xe993</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe994" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lkdto"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lkdto</span><span class="i-code">0xe994</span></div>
        <div title="Code: 0xe995" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hackernews"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hackernews</span><span class="i-code">0xe995</span></div>
        <div title="Code: 0xe996" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stackoverflow-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stackoverflow-1</span><span class="i-code">0xe996</span></div>
        <div title="Code: 0xe997" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-intensedebate"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-intensedebate</span><span class="i-code">0xe997</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe998" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eventbrite"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eventbrite</span><span class="i-code">0xe998</span></div>
        <div title="Code: 0xe999" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-scribd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-scribd</span><span class="i-code">0xe999</span></div>
        <div title="Code: 0xe99a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-posterous"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-posterous</span><span class="i-code">0xe99a</span></div>
        <div title="Code: 0xe99b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stripe"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stripe</span><span class="i-code">0xe99b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe99c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-opentable"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-opentable</span><span class="i-code">0xe99c</span></div>
        <div title="Code: 0xe99d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cart"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cart</span><span class="i-code">0xe99d</span></div>
        <div title="Code: 0xe99e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-1</span><span class="i-code">0xe99e</span></div>
        <div title="Code: 0xe99f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angellist"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angellist</span><span class="i-code">0xe99f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9a0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-2</span><span class="i-code">0xe9a0</span></div>
        <div title="Code: 0xe9a1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dwolla"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dwolla</span><span class="i-code">0xe9a1</span></div>
        <div title="Code: 0xe9a2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-appnet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-appnet</span><span class="i-code">0xe9a2</span></div>
        <div title="Code: 0xe9a3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-statusnet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-statusnet</span><span class="i-code">0xe9a3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9a4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-acrobat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-acrobat</span><span class="i-code">0xe9a4</span></div>
        <div title="Code: 0xe9a5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drupal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drupal</span><span class="i-code">0xe9a5</span></div>
        <div title="Code: 0xe9a6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-buffer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-buffer</span><span class="i-code">0xe9a6</span></div>
        <div title="Code: 0xe9a7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pocket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pocket</span><span class="i-code">0xe9a7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9a8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bitbucket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bitbucket</span><span class="i-code">0xe9a8</span></div>
        <div title="Code: 0xe9a9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lego"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lego</span><span class="i-code">0xe9a9</span></div>
        <div title="Code: 0xe9aa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-login"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-login</span><span class="i-code">0xe9aa</span></div>
        <div title="Code: 0xe9ab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yelp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yelp</span><span class="i-code">0xe9ab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9ac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wordpress-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wordpress-2</span><span class="i-code">0xe9ac</span></div>
        <div title="Code: 0xe9ad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eventasaurus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eventasaurus</span><span class="i-code">0xe9ad</span></div>
        <div title="Code: 0xe9ae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-2</span><span class="i-code">0xe9ae</span></div>
        <div title="Code: 0xe9af" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soundcloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soundcloud</span><span class="i-code">0xe9af</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9b0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quora"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quora</span><span class="i-code">0xe9b0</span></div>
        <div title="Code: 0xe9b1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-openid"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-openid</span><span class="i-code">0xe9b1</span></div>
        <div title="Code: 0xe9b2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinboard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinboard</span><span class="i-code">0xe9b2</span></div>
        <div title="Code: 0xe9b3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gmail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gmail</span><span class="i-code">0xe9b3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9b4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-1</span><span class="i-code">0xe9b4</span></div>
        <div title="Code: 0xe9b5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-songkick"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-songkick</span><span class="i-code">0xe9b5</span></div>
        <div title="Code: 0xe9b6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plurk"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plurk</span><span class="i-code">0xe9b6</span></div>
        <div title="Code: 0xe9b7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-itunes"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-itunes</span><span class="i-code">0xe9b7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9b8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-googleplay"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-googleplay</span><span class="i-code">0xe9b8</span></div>
        <div title="Code: 0xe9b9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled</span><span class="i-code">0xe9b9</span></div>
        <div title="Code: 0xe9ba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-2</span><span class="i-code">0xe9ba</span></div>
        <div title="Code: 0xe9bb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-2</span><span class="i-code">0xe9bb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9bc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ebay"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ebay</span><span class="i-code">0xe9bc</span></div>
        <div title="Code: 0xe9bd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dropbox"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dropbox</span><span class="i-code">0xe9bd</span></div>
        <div title="Code: 0xe9be" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloudapp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloudapp</span><span class="i-code">0xe9be</span></div>
        <div title="Code: 0xe9bf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-2</span><span class="i-code">0xe9bf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9c0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-meetup"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-meetup</span><span class="i-code">0xe9c0</span></div>
        <div title="Code: 0xe9c1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vk"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vk</span><span class="i-code">0xe9c1</span></div>
        <div title="Code: 0xe9c2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plancast"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plancast</span><span class="i-code">0xe9c2</span></div>
        <div title="Code: 0xe9c3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-disqus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-disqus</span><span class="i-code">0xe9c3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9c4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-2</span><span class="i-code">0xe9c4</span></div>
        <div title="Code: 0xe9c5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-3</span><span class="i-code">0xe9c5</span></div>
        <div title="Code: 0xe9c6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-2</span><span class="i-code">0xe9c6</span></div>
        <div title="Code: 0xe9c7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-2</span><span class="i-code">0xe9c7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9c8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-2</span><span class="i-code">0xe9c8</span></div>
        <div title="Code: 0xe9c9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windows"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windows</span><span class="i-code">0xe9c9</span></div>
        <div title="Code: 0xe9ca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-xing"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-xing</span><span class="i-code">0xe9ca</span></div>
        <div title="Code: 0xe9cb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yahoo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yahoo</span><span class="i-code">0xe9cb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9cc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chrome"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chrome</span><span class="i-code">0xe9cc</span></div>
        <div title="Code: 0xe9cd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-email"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-email</span><span class="i-code">0xe9cd</span></div>
        <div title="Code: 0xe9ce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-macstore"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-macstore</span><span class="i-code">0xe9ce</span></div>
        <div title="Code: 0xe9cf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-myspace"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-myspace</span><span class="i-code">0xe9cf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9d0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-podcast"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-podcast</span><span class="i-code">0xe9d0</span></div>
        <div title="Code: 0xe9d1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-amazon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-amazon</span><span class="i-code">0xe9d1</span></div>
        <div title="Code: 0xe9d2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-steam"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-steam</span><span class="i-code">0xe9d2</span></div>
        <div title="Code: 0xe9d3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-klout"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-klout</span><span class="i-code">0xe9d3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9d4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-weibo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-weibo</span><span class="i-code">0xe9d4</span></div>
        <div title="Code: 0xe9d5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instapaper"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instapaper</span><span class="i-code">0xe9d5</span></div>
        <div title="Code: 0xe9d6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-viadeo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-viadeo</span><span class="i-code">0xe9d6</span></div>
        <div title="Code: 0xe9d7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-google"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-google</span><span class="i-code">0xe9d7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9d8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-1</span><span class="i-code">0xe9d8</span></div>
        <div title="Code: 0xe9d9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-evernote"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-evernote</span><span class="i-code">0xe9d9</span></div>
        <div title="Code: 0xe9da" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-1</span><span class="i-code">0xe9da</span></div>
        <div title="Code: 0xe9db" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-1</span><span class="i-code">0xe9db</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9dc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blogger-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blogger-2</span><span class="i-code">0xe9dc</span></div>
        <div title="Code: 0xe9dd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-appstore"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-appstore</span><span class="i-code">0xe9dd</span></div>
        <div title="Code: 0xe9de" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gowalla"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gowalla</span><span class="i-code">0xe9de</span></div>
        <div title="Code: 0xe9df" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-guest"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-guest</span><span class="i-code">0xe9df</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9e0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reddit-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reddit-1</span><span class="i-code">0xe9e0</span></div>
        <div title="Code: 0xe9e1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spotify"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spotify</span><span class="i-code">0xe9e1</span></div>
        <div title="Code: 0xe9e2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-digg-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-digg-1</span><span class="i-code">0xe9e2</span></div>
        <div title="Code: 0xe9e3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forrst"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forrst</span><span class="i-code">0xe9e3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9e4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ninetyninedesigns"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ninetyninedesigns</span><span class="i-code">0xe9e4</span></div>
        <div title="Code: 0xe9e5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-grooveshark"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-grooveshark</span><span class="i-code">0xe9e5</span></div>
        <div title="Code: 0xe9e6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-call"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-call</span><span class="i-code">0xe9e6</span></div>
        <div title="Code: 0xe9e7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-duckduckgo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-duckduckgo</span><span class="i-code">0xe9e7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9e8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-aim"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-aim</span><span class="i-code">0xe9e8</span></div>
        <div title="Code: 0xe9e9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-delicious-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-delicious-1</span><span class="i-code">0xe9e9</span></div>
        <div title="Code: 0xe9ea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paypal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paypal</span><span class="i-code">0xe9ea</span></div>
        <div title="Code: 0xe9eb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flattr"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flattr</span><span class="i-code">0xe9eb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9ec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-android"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-android</span><span class="i-code">0xe9ec</span></div>
        <div title="Code: 0xe9ed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eventful"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eventful</span><span class="i-code">0xe9ed</span></div>
        <div title="Code: 0xe9ee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-smashmag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-smashmag</span><span class="i-code">0xe9ee</span></div>
        <div title="Code: 0xe9ef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus</span><span class="i-code">0xe9ef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9f0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wikipedia"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wikipedia</span><span class="i-code">0xe9f0</span></div>
        <div title="Code: 0xe9f1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lanyrd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lanyrd</span><span class="i-code">0xe9f1</span></div>
        <div title="Code: 0xe9f2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-2</span><span class="i-code">0xe9f2</span></div>
        <div title="Code: 0xe9f3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon-1</span><span class="i-code">0xe9f3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9f4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fivehundredpx"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fivehundredpx</span><span class="i-code">0xe9f4</span></div>
        <div title="Code: 0xe9f5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-1</span><span class="i-code">0xe9f5</span></div>
        <div title="Code: 0xe9f6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bitcoin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bitcoin</span><span class="i-code">0xe9f6</span></div>
        <div title="Code: 0xe9f7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-w3c-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-w3c-1</span><span class="i-code">0xe9f7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9f8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-foursquare-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-foursquare-1</span><span class="i-code">0xe9f8</span></div>
        <div title="Code: 0xe9f9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-html5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-html5</span><span class="i-code">0xe9f9</span></div>
        <div title="Code: 0xe9fa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ie"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ie</span><span class="i-code">0xe9fa</span></div>
        <div title="Code: 0xe9fb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-warehouse"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-warehouse</span><span class="i-code">0xe9fb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xe9fc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tree-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tree-2</span><span class="i-code">0xe9fc</span></div>
        <div title="Code: 0xe9fd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tree-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tree-1</span><span class="i-code">0xe9fd</span></div>
        <div title="Code: 0xe9fe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pitch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pitch</span><span class="i-code">0xe9fe</span></div>
        <div title="Code: 0xe9ff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-police"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-police</span><span class="i-code">0xe9ff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea00" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-post"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-post</span><span class="i-code">0xea00</span></div>
        <div title="Code: 0xea01" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-prison"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-prison</span><span class="i-code">0xea01</span></div>
        <div title="Code: 0xea02" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rail</span><span class="i-code">0xea02</span></div>
        <div title="Code: 0xea03" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-religious-christian"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-religious-christian</span><span class="i-code">0xea03</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea04" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-religious-islam"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-religious-islam</span><span class="i-code">0xea04</span></div>
        <div title="Code: 0xea05" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-religious-jewish"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-religious-jewish</span><span class="i-code">0xea05</span></div>
        <div title="Code: 0xea06" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-restaurant"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-restaurant</span><span class="i-code">0xea06</span></div>
        <div title="Code: 0xea07" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-roadblock"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-roadblock</span><span class="i-code">0xea07</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea08" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-school"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-school</span><span class="i-code">0xea08</span></div>
        <div title="Code: 0xea09" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shop-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shop-1</span><span class="i-code">0xea09</span></div>
        <div title="Code: 0xea0a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skiing"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skiing</span><span class="i-code">0xea0a</span></div>
        <div title="Code: 0xea0b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soccer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soccer</span><span class="i-code">0xea0b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea0c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-swimming"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-swimming</span><span class="i-code">0xea0c</span></div>
        <div title="Code: 0xea0d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tennis"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tennis</span><span class="i-code">0xea0d</span></div>
        <div title="Code: 0xea0e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-theatre"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-theatre</span><span class="i-code">0xea0e</span></div>
        <div title="Code: 0xea0f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-toilet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-toilet</span><span class="i-code">0xea0f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea10" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-town-hall"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-town-hall</span><span class="i-code">0xea10</span></div>
        <div title="Code: 0xea11" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-2</span><span class="i-code">0xea11</span></div>
        <div title="Code: 0xea12" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pharmacy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pharmacy</span><span class="i-code">0xea12</span></div>
        <div title="Code: 0xea13" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-museum"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-museum</span><span class="i-code">0xea13</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea14" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-monument"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-monument</span><span class="i-code">0xea14</span></div>
        <div title="Code: 0xea15" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minefield"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minefield</span><span class="i-code">0xea15</span></div>
        <div title="Code: 0xea16" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-london-underground"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-london-underground</span><span class="i-code">0xea16</span></div>
        <div title="Code: 0xea17" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lodging"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lodging</span><span class="i-code">0xea17</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea18" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-library"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-library</span><span class="i-code">0xea18</span></div>
        <div title="Code: 0xea19" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-industrial-building"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-industrial-building</span><span class="i-code">0xea19</span></div>
        <div title="Code: 0xea1a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hospital"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hospital</span><span class="i-code">0xea1a</span></div>
        <div title="Code: 0xea1b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heliport"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heliport</span><span class="i-code">0xea1b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea1c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-harbor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-harbor</span><span class="i-code">0xea1c</span></div>
        <div title="Code: 0xea1d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-grocery-store"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-grocery-store</span><span class="i-code">0xea1d</span></div>
        <div title="Code: 0xea1e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-golf"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-golf</span><span class="i-code">0xea1e</span></div>
        <div title="Code: 0xea1f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-giraffe"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-giraffe</span><span class="i-code">0xea1f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea20" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-garden"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-garden</span><span class="i-code">0xea20</span></div>
        <div title="Code: 0xea21" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fuel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fuel</span><span class="i-code">0xea21</span></div>
        <div title="Code: 0xea22" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-football"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-football</span><span class="i-code">0xea22</span></div>
        <div title="Code: 0xea23" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fire-station"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fire-station</span><span class="i-code">0xea23</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea24" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ferry"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ferry</span><span class="i-code">0xea24</span></div>
        <div title="Code: 0xea25" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-food"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-food</span><span class="i-code">0xea25</span></div>
        <div title="Code: 0xea26" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-aboveground-rail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-aboveground-rail</span><span class="i-code">0xea26</span></div>
        <div title="Code: 0xea27" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-airfield"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-airfield</span><span class="i-code">0xea27</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea28" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-airport"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-airport</span><span class="i-code">0xea28</span></div>
        <div title="Code: 0xea29" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-art-gallery"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-art-gallery</span><span class="i-code">0xea29</span></div>
        <div title="Code: 0xea2a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bar"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bar</span><span class="i-code">0xea2a</span></div>
        <div title="Code: 0xea2b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-baseball"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-baseball</span><span class="i-code">0xea2b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea2c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basketball"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basketball</span><span class="i-code">0xea2c</span></div>
        <div title="Code: 0xea2d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-beer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-beer</span><span class="i-code">0xea2d</span></div>
        <div title="Code: 0xea2e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-belowground-rail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-belowground-rail</span><span class="i-code">0xea2e</span></div>
        <div title="Code: 0xea2f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bicycle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bicycle</span><span class="i-code">0xea2f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea30" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bus</span><span class="i-code">0xea30</span></div>
        <div title="Code: 0xea31" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cafe"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cafe</span><span class="i-code">0xea31</span></div>
        <div title="Code: 0xea32" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-campsite"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-campsite</span><span class="i-code">0xea32</span></div>
        <div title="Code: 0xea33" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cemetery"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cemetery</span><span class="i-code">0xea33</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea34" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cinema"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cinema</span><span class="i-code">0xea34</span></div>
        <div title="Code: 0xea35" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-college"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-college</span><span class="i-code">0xea35</span></div>
        <div title="Code: 0xea36" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-commerical-building"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-commerical-building</span><span class="i-code">0xea36</span></div>
        <div title="Code: 0xea37" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card-1</span><span class="i-code">0xea37</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea38" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cricket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cricket</span><span class="i-code">0xea38</span></div>
        <div title="Code: 0xea39" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-embassy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-embassy</span><span class="i-code">0xea39</span></div>
        <div title="Code: 0xea3a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vector-pencil"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vector-pencil</span><span class="i-code">0xea3a</span></div>
        <div title="Code: 0xea3b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at</span><span class="i-code">0xea3b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea3c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-female-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-female-1</span><span class="i-code">0xea3c</span></div>
        <div title="Code: 0xea3d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-male-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-male-1</span><span class="i-code">0xea3d</span></div>
        <div title="Code: 0xea3e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-king"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-king</span><span class="i-code">0xea3e</span></div>
        <div title="Code: 0xea3f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-anchor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-anchor</span><span class="i-code">0xea3f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea40" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-3</span><span class="i-code">0xea40</span></div>
        <div title="Code: 0xea41" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash</span><span class="i-code">0xea41</span></div>
        <div title="Code: 0xea42" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-bold"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-bold</span><span class="i-code">0xea42</span></div>
        <div title="Code: 0xea43" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-bold"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-bold</span><span class="i-code">0xea43</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea44" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-fat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-fat</span><span class="i-code">0xea44</span></div>
        <div title="Code: 0xea45" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-fat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-fat</span><span class="i-code">0xea45</span></div>
        <div title="Code: 0xea46" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-fat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-fat</span><span class="i-code">0xea46</span></div>
        <div title="Code: 0xea47" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-fat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-fat</span><span class="i-code">0xea47</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea48" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-bold"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-bold</span><span class="i-code">0xea48</span></div>
        <div title="Code: 0xea49" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-bold"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-bold</span><span class="i-code">0xea49</span></div>
        <div title="Code: 0xea4a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-1</span><span class="i-code">0xea4a</span></div>
        <div title="Code: 0xea4b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-1</span><span class="i-code">0xea4b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea4c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-1</span><span class="i-code">0xea4c</span></div>
        <div title="Code: 0xea4d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-1</span><span class="i-code">0xea4d</span></div>
        <div title="Code: 0xea4e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass</span><span class="i-code">0xea4e</span></div>
        <div title="Code: 0xea4f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stopwatch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stopwatch</span><span class="i-code">0xea4f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea50" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-3</span><span class="i-code">0xea50</span></div>
        <div title="Code: 0xea51" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-2</span><span class="i-code">0xea51</span></div>
        <div title="Code: 0xea52" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-1</span><span class="i-code">0xea52</span></div>
        <div title="Code: 0xea53" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-alt</span><span class="i-code">0xea53</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea54" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-3</span><span class="i-code">0xea54</span></div>
        <div title="Code: 0xea55" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-1</span><span class="i-code">0xea55</span></div>
        <div title="Code: 0xea56" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-circled-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-circled-alt</span><span class="i-code">0xea56</span></div>
        <div title="Code: 0xea57" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-circled-1</span><span class="i-code">0xea57</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea58" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-1</span><span class="i-code">0xea58</span></div>
        <div title="Code: 0xea59" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-2</span><span class="i-code">0xea59</span></div>
        <div title="Code: 0xea5a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-2</span><span class="i-code">0xea5a</span></div>
        <div title="Code: 0xea5b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-3</span><span class="i-code">0xea5b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea5c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-3</span><span class="i-code">0xea5c</span></div>
        <div title="Code: 0xea5d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-3</span><span class="i-code">0xea5d</span></div>
        <div title="Code: 0xea5e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-empty-1</span><span class="i-code">0xea5e</span></div>
        <div title="Code: 0xea5f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clouds-flash"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clouds-flash</span><span class="i-code">0xea5f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea60" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clouds"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clouds</span><span class="i-code">0xea60</span></div>
        <div title="Code: 0xea61" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hail"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hail</span><span class="i-code">0xea61</span></div>
        <div title="Code: 0xea62" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow-heavy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow-heavy</span><span class="i-code">0xea62</span></div>
        <div title="Code: 0xea63" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow-alt</span><span class="i-code">0xea63</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea64" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow</span><span class="i-code">0xea64</span></div>
        <div title="Code: 0xea65" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windy-rain"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windy-rain</span><span class="i-code">0xea65</span></div>
        <div title="Code: 0xea66" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windy-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windy-inv</span><span class="i-code">0xea66</span></div>
        <div title="Code: 0xea67" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sunrise"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sunrise</span><span class="i-code">0xea67</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea68" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun</span><span class="i-code">0xea68</span></div>
        <div title="Code: 0xea69" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon</span><span class="i-code">0xea69</span></div>
        <div title="Code: 0xea6a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eclipse"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eclipse</span><span class="i-code">0xea6a</span></div>
        <div title="Code: 0xea6b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mist"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mist</span><span class="i-code">0xea6b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea6c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wind"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wind</span><span class="i-code">0xea6c</span></div>
        <div title="Code: 0xea6d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snowflake"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snowflake</span><span class="i-code">0xea6d</span></div>
        <div title="Code: 0xea6e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-sun"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-sun</span><span class="i-code">0xea6e</span></div>
        <div title="Code: 0xea6f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-moon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-moon</span><span class="i-code">0xea6f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea70" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fog-sun"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fog-sun</span><span class="i-code">0xea70</span></div>
        <div title="Code: 0xea71" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fog-moon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fog-moon</span><span class="i-code">0xea71</span></div>
        <div title="Code: 0xea72" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fog-cloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fog-cloud</span><span class="i-code">0xea72</span></div>
        <div title="Code: 0xea73" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fog"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fog</span><span class="i-code">0xea73</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea74" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-4</span><span class="i-code">0xea74</span></div>
        <div title="Code: 0xea75" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-flash"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-flash</span><span class="i-code">0xea75</span></div>
        <div title="Code: 0xea76" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-flash-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-flash-alt</span><span class="i-code">0xea76</span></div>
        <div title="Code: 0xea77" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drizzle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drizzle</span><span class="i-code">0xea77</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea78" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rain"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rain</span><span class="i-code">0xea78</span></div>
        <div title="Code: 0xea79" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windy</span><span class="i-code">0xea79</span></div>
        <div title="Code: 0xea7a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rain-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rain-inv</span><span class="i-code">0xea7a</span></div>
        <div title="Code: 0xea7b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drizzle-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drizzle-inv</span><span class="i-code">0xea7b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea7c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-flash-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-flash-inv</span><span class="i-code">0xea7c</span></div>
        <div title="Code: 0xea7d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-inv</span><span class="i-code">0xea7d</span></div>
        <div title="Code: 0xea7e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-moon-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-moon-inv</span><span class="i-code">0xea7e</span></div>
        <div title="Code: 0xea7f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-sun-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-sun-inv</span><span class="i-code">0xea7f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea80" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-inv</span><span class="i-code">0xea80</span></div>
        <div title="Code: 0xea81" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-inv</span><span class="i-code">0xea81</span></div>
        <div title="Code: 0xea82" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clouds-flash-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clouds-flash-alt</span><span class="i-code">0xea82</span></div>
        <div title="Code: 0xea83" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fahrenheit"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fahrenheit</span><span class="i-code">0xea83</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea84" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-celcius"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-celcius</span><span class="i-code">0xea84</span></div>
        <div title="Code: 0xea85" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-na"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-na</span><span class="i-code">0xea85</span></div>
        <div title="Code: 0xea86" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-1</span><span class="i-code">0xea86</span></div>
        <div title="Code: 0xea87" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-temperature"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-temperature</span><span class="i-code">0xea87</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea88" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clouds-flash-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clouds-flash-inv</span><span class="i-code">0xea88</span></div>
        <div title="Code: 0xea89" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clouds-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clouds-inv</span><span class="i-code">0xea89</span></div>
        <div title="Code: 0xea8a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hail-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hail-inv</span><span class="i-code">0xea8a</span></div>
        <div title="Code: 0xea8b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow-heavy-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow-heavy-inv</span><span class="i-code">0xea8b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea8c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow-inv</span><span class="i-code">0xea8c</span></div>
        <div title="Code: 0xea8d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windy-rain-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windy-rain-inv</span><span class="i-code">0xea8d</span></div>
        <div title="Code: 0xea8e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-3</span><span class="i-code">0xea8e</span></div>
        <div title="Code: 0xea8f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-rect</span><span class="i-code">0xea8f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea90" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-bird-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-bird-2</span><span class="i-code">0xea90</span></div>
        <div title="Code: 0xea91" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-4</span><span class="i-code">0xea91</span></div>
        <div title="Code: 0xea92" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-rect-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-rect-2</span><span class="i-code">0xea92</span></div>
        <div title="Code: 0xea93" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-4</span><span class="i-code">0xea93</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea94" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-money-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-money-1</span><span class="i-code">0xea94</span></div>
        <div title="Code: 0xea95" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-squares"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-squares</span><span class="i-code">0xea95</span></div>
        <div title="Code: 0xea96" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-semicolon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-semicolon</span><span class="i-code">0xea96</span></div>
        <div title="Code: 0xea97" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-colon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-colon</span><span class="i-code">0xea97</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea98" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at-1</span><span class="i-code">0xea98</span></div>
        <div title="Code: 0xea99" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dollar"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dollar</span><span class="i-code">0xea99</span></div>
        <div title="Code: 0xea9a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie</span><span class="i-code">0xea9a</span></div>
        <div title="Code: 0xea9b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-1</span><span class="i-code">0xea9b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xea9c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-1</span><span class="i-code">0xea9c</span></div>
        <div title="Code: 0xea9d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-3</span><span class="i-code">0xea9d</span></div>
        <div title="Code: 0xea9e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-easel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-easel</span><span class="i-code">0xea9e</span></div>
        <div title="Code: 0xea9f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-1</span><span class="i-code">0xea9f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaa0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-grid"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-grid</span><span class="i-code">0xeaa0</span></div>
        <div title="Code: 0xeaa1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cd-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cd-1</span><span class="i-code">0xeaa1</span></div>
        <div title="Code: 0xeaa2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ipod"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ipod</span><span class="i-code">0xeaa2</span></div>
        <div title="Code: 0xeaa3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tablet-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tablet-1</span><span class="i-code">0xeaa3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaa4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-alt</span><span class="i-code">0xeaa4</span></div>
        <div title="Code: 0xeaa5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-2</span><span class="i-code">0xeaa5</span></div>
        <div title="Code: 0xeaa6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-award"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-award</span><span class="i-code">0xeaa6</span></div>
        <div title="Code: 0xeaa7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal-2</span><span class="i-code">0xeaa7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaa8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-1</span><span class="i-code">0xeaa8</span></div>
        <div title="Code: 0xeaa9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-2</span><span class="i-code">0xeaa9</span></div>
        <div title="Code: 0xeaaa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-2</span><span class="i-code">0xeaaa</span></div>
        <div title="Code: 0xeaab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-dir"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-dir</span><span class="i-code">0xeaab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-dir-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-dir-1</span><span class="i-code">0xeaac</span></div>
        <div title="Code: 0xeaad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-dir"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-dir</span><span class="i-code">0xeaad</span></div>
        <div title="Code: 0xeaae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-dir-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-dir-1</span><span class="i-code">0xeaae</span></div>
        <div title="Code: 0xeaaf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup-1</span><span class="i-code">0xeaaf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeab0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out-2</span><span class="i-code">0xeab0</span></div>
        <div title="Code: 0xeab1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in-2</span><span class="i-code">0xeab1</span></div>
        <div title="Code: 0xeab2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small-1</span><span class="i-code">0xeab2</span></div>
        <div title="Code: 0xeab3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-2</span><span class="i-code">0xeab3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeab4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-2</span><span class="i-code">0xeab4</span></div>
        <div title="Code: 0xeab5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-alt</span><span class="i-code">0xeab5</span></div>
        <div title="Code: 0xeab6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-4</span><span class="i-code">0xeab6</span></div>
        <div title="Code: 0xeab7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bullhorn"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bullhorn</span><span class="i-code">0xeab7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeab8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-up-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-up-1</span><span class="i-code">0xeab8</span></div>
        <div title="Code: 0xeab9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-down-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-down-1</span><span class="i-code">0xeab9</span></div>
        <div title="Code: 0xeaba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-off-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-off-1</span><span class="i-code">0xeaba</span></div>
        <div title="Code: 0xeabb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-alt</span><span class="i-code">0xeabb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeabc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-4</span><span class="i-code">0xeabc</span></div>
        <div title="Code: 0xeabd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-alt</span><span class="i-code">0xeabd</span></div>
        <div title="Code: 0xeabe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-1</span><span class="i-code">0xeabe</span></div>
        <div title="Code: 0xeabf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-1</span><span class="i-code">0xeabf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeac0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-3</span><span class="i-code">0xeac0</span></div>
        <div title="Code: 0xeac1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-3</span><span class="i-code">0xeac1</span></div>
        <div title="Code: 0xeac2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-3</span><span class="i-code">0xeac2</span></div>
        <div title="Code: 0xeac3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-2</span><span class="i-code">0xeac3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeac4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down-1</span><span class="i-code">0xeac4</span></div>
        <div title="Code: 0xeac5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-2</span><span class="i-code">0xeac5</span></div>
        <div title="Code: 0xeac6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-2</span><span class="i-code">0xeac6</span></div>
        <div title="Code: 0xeac7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-3</span><span class="i-code">0xeac7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeac8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-alt</span><span class="i-code">0xeac8</span></div>
        <div title="Code: 0xeac9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit-1</span><span class="i-code">0xeac9</span></div>
        <div title="Code: 0xeaca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-2</span><span class="i-code">0xeaca</span></div>
        <div title="Code: 0xeacb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-3</span><span class="i-code">0xeacb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeacc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-2</span><span class="i-code">0xeacc</span></div>
        <div title="Code: 0xeacd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-2</span><span class="i-code">0xeacd</span></div>
        <div title="Code: 0xeace" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info</span><span class="i-code">0xeace</span></div>
        <div title="Code: 0xeacf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-question"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-question</span><span class="i-code">0xeacf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xead0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-4</span><span class="i-code">0xead0</span></div>
        <div title="Code: 0xead1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-4</span><span class="i-code">0xead1</span></div>
        <div title="Code: 0xead2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-4</span><span class="i-code">0xead2</span></div>
        <div title="Code: 0xead3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-article"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-article</span><span class="i-code">0xead3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xead4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-article-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-article-alt</span><span class="i-code">0xead4</span></div>
        <div title="Code: 0xead5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-4</span><span class="i-code">0xead5</span></div>
        <div title="Code: 0xead6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-4</span><span class="i-code">0xead6</span></div>
        <div title="Code: 0xead7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-4</span><span class="i-code">0xead7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xead8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-4</span><span class="i-code">0xead8</span></div>
        <div title="Code: 0xead9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-4</span><span class="i-code">0xead9</span></div>
        <div title="Code: 0xeada" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-woman"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-woman</span><span class="i-code">0xeada</span></div>
        <div title="Code: 0xeadb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-pair"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-pair</span><span class="i-code">0xeadb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeadc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-alt-1</span><span class="i-code">0xeadc</span></div>
        <div title="Code: 0xeadd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-3</span><span class="i-code">0xeadd</span></div>
        <div title="Code: 0xeade" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-alt</span><span class="i-code">0xeade</span></div>
        <div title="Code: 0xeadf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-3</span><span class="i-code">0xeadf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeae0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-2</span><span class="i-code">0xeae0</span></div>
        <div title="Code: 0xeae1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-3</span><span class="i-code">0xeae1</span></div>
        <div title="Code: 0xeae2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-3</span><span class="i-code">0xeae2</span></div>
        <div title="Code: 0xeae3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-3</span><span class="i-code">0xeae3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeae4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circle-1</span><span class="i-code">0xeae4</span></div>
        <div title="Code: 0xeae5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-2</span><span class="i-code">0xeae5</span></div>
        <div title="Code: 0xeae6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-2</span><span class="i-code">0xeae6</span></div>
        <div title="Code: 0xeae7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-4</span><span class="i-code">0xeae7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeae8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-3</span><span class="i-code">0xeae8</span></div>
        <div title="Code: 0xeae9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dial"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dial</span><span class="i-code">0xeae9</span></div>
        <div title="Code: 0xeaea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pilcrow"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pilcrow</span><span class="i-code">0xeaea</span></div>
        <div title="Code: 0xeaeb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at-2</span><span class="i-code">0xeaeb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hash-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hash-1</span><span class="i-code">0xeaec</span></div>
        <div title="Code: 0xeaed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-inv</span><span class="i-code">0xeaed</span></div>
        <div title="Code: 0xeaee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-2</span><span class="i-code">0xeaee</span></div>
        <div title="Code: 0xeaef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-alt</span><span class="i-code">0xeaef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaf0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-1</span><span class="i-code">0xeaf0</span></div>
        <div title="Code: 0xeaf1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-2</span><span class="i-code">0xeaf1</span></div>
        <div title="Code: 0xeaf2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-umbrella"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-umbrella</span><span class="i-code">0xeaf2</span></div>
        <div title="Code: 0xeaf3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-inv-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-inv-1</span><span class="i-code">0xeaf3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaf4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-3</span><span class="i-code">0xeaf4</span></div>
        <div title="Code: 0xeaf5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cd-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cd-2</span><span class="i-code">0xeaf5</span></div>
        <div title="Code: 0xeaf6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-equalizer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-equalizer</span><span class="i-code">0xeaf6</span></div>
        <div title="Code: 0xeaf7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cursor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cursor</span><span class="i-code">0xeaf7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeaf8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-aperture"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-aperture</span><span class="i-code">0xeaf8</span></div>
        <div title="Code: 0xeaf9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-aperture-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-aperture-alt</span><span class="i-code">0xeaf9</span></div>
        <div title="Code: 0xeafa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-steering-wheel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-steering-wheel</span><span class="i-code">0xeafa</span></div>
        <div title="Code: 0xeafb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-2</span><span class="i-code">0xeafb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeafc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-alt</span><span class="i-code">0xeafc</span></div>
        <div title="Code: 0xeafd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-brush"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-brush</span><span class="i-code">0xeafd</span></div>
        <div title="Code: 0xeafe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-brush-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-brush-alt</span><span class="i-code">0xeafe</span></div>
        <div title="Code: 0xeaff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eyedropper"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eyedropper</span><span class="i-code">0xeaff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb00" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-layers"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-layers</span><span class="i-code">0xeb00</span></div>
        <div title="Code: 0xeb01" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-layers-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-layers-alt</span><span class="i-code">0xeb01</span></div>
        <div title="Code: 0xeb02" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-1</span><span class="i-code">0xeb02</span></div>
        <div title="Code: 0xeb03" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-inv-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-inv-1</span><span class="i-code">0xeb03</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb04" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-5</span><span class="i-code">0xeb04</span></div>
        <div title="Code: 0xeb05" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rain-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rain-1</span><span class="i-code">0xeb05</span></div>
        <div title="Code: 0xeb06" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash-1</span><span class="i-code">0xeb06</span></div>
        <div title="Code: 0xeb07" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-1</span><span class="i-code">0xeb07</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb08" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat-charge"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat-charge</span><span class="i-code">0xeb08</span></div>
        <div title="Code: 0xeb09" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat-full"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat-full</span><span class="i-code">0xeb09</span></div>
        <div title="Code: 0xeb0a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat-half"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat-half</span><span class="i-code">0xeb0a</span></div>
        <div title="Code: 0xeb0b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat-empty</span><span class="i-code">0xeb0b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb0c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-nested"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-nested</span><span class="i-code">0xeb0c</span></div>
        <div title="Code: 0xeb0d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-2</span><span class="i-code">0xeb0d</span></div>
        <div title="Code: 0xeb0e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-award-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-award-empty</span><span class="i-code">0xeb0e</span></div>
        <div title="Code: 0xeb0f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-award-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-award-1</span><span class="i-code">0xeb0f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb10" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal-3</span><span class="i-code">0xeb10</span></div>
        <div title="Code: 0xeb11" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-2</span><span class="i-code">0xeb11</span></div>
        <div title="Code: 0xeb12" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-1</span><span class="i-code">0xeb12</span></div>
        <div title="Code: 0xeb13" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-end-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-end-1</span><span class="i-code">0xeb13</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb14" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-start-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-start-1</span><span class="i-code">0xeb14</span></div>
        <div title="Code: 0xeb15" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-2</span><span class="i-code">0xeb15</span></div>
        <div title="Code: 0xeb16" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-3</span><span class="i-code">0xeb16</span></div>
        <div title="Code: 0xeb17" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-circle2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-circle2</span><span class="i-code">0xeb17</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb18" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-2</span><span class="i-code">0xeb18</span></div>
        <div title="Code: 0xeb19" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrow-curved"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrow-curved</span><span class="i-code">0xeb19</span></div>
        <div title="Code: 0xeb1a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-split"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-split</span><span class="i-code">0xeb1a</span></div>
        <div title="Code: 0xeb1b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-exchange"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-exchange</span><span class="i-code">0xeb1b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb1c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-2</span><span class="i-code">0xeb1c</span></div>
        <div title="Code: 0xeb1d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-3</span><span class="i-code">0xeb1d</span></div>
        <div title="Code: 0xeb1e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-alt-1</span><span class="i-code">0xeb1e</span></div>
        <div title="Code: 0xeb1f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small-2</span><span class="i-code">0xeb1f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb20" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small-alt</span><span class="i-code">0xeb20</span></div>
        <div title="Code: 0xeb21" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-vertical-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-vertical-1</span><span class="i-code">0xeb21</span></div>
        <div title="Code: 0xeb22" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-horizontal-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-horizontal-1</span><span class="i-code">0xeb22</span></div>
        <div title="Code: 0xeb23" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-move-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-move-1</span><span class="i-code">0xeb23</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb24" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup-2</span><span class="i-code">0xeb24</span></div>
        <div title="Code: 0xeb25" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-3</span><span class="i-code">0xeb25</span></div>
        <div title="Code: 0xeb26" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-2</span><span class="i-code">0xeb26</span></div>
        <div title="Code: 0xeb27" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-2</span><span class="i-code">0xeb27</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb28" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-3</span><span class="i-code">0xeb28</span></div>
        <div title="Code: 0xeb29" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circle-1</span><span class="i-code">0xeb29</span></div>
        <div title="Code: 0xeb2a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circle-1</span><span class="i-code">0xeb2a</span></div>
        <div title="Code: 0xeb2b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circle-1</span><span class="i-code">0xeb2b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb2c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circle-1</span><span class="i-code">0xeb2c</span></div>
        <div title="Code: 0xeb2d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-2</span><span class="i-code">0xeb2d</span></div>
        <div title="Code: 0xeb2e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop</span><span class="i-code">0xeb2e</span></div>
        <div title="Code: 0xeb2f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-alt</span><span class="i-code">0xeb2f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb30" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lamp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lamp</span><span class="i-code">0xeb30</span></div>
        <div title="Code: 0xeb31" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-5</span><span class="i-code">0xeb31</span></div>
        <div title="Code: 0xeb32" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-headphones-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-headphones-1</span><span class="i-code">0xeb32</span></div>
        <div title="Code: 0xeb33" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-up-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-up-2</span><span class="i-code">0xeb33</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb34" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-off-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-off-2</span><span class="i-code">0xeb34</span></div>
        <div title="Code: 0xeb35" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-2</span><span class="i-code">0xeb35</span></div>
        <div title="Code: 0xeb36" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-alt-1</span><span class="i-code">0xeb36</span></div>
        <div title="Code: 0xeb37" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-inv</span><span class="i-code">0xeb37</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb38" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-5</span><span class="i-code">0xeb38</span></div>
        <div title="Code: 0xeb39" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-share-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-share-1</span><span class="i-code">0xeb39</span></div>
        <div title="Code: 0xeb3a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-2</span><span class="i-code">0xeb3a</span></div>
        <div title="Code: 0xeb3b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-4</span><span class="i-code">0xeb3b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb3c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-alt-1</span><span class="i-code">0xeb3c</span></div>
        <div title="Code: 0xeb3d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-4</span><span class="i-code">0xeb3d</span></div>
        <div title="Code: 0xeb3e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box-1</span><span class="i-code">0xeb3e</span></div>
        <div title="Code: 0xeb3f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-empty-1</span><span class="i-code">0xeb3f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb40" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-3</span><span class="i-code">0xeb40</span></div>
        <div title="Code: 0xeb41" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-open"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-open</span><span class="i-code">0xeb41</span></div>
        <div title="Code: 0xeb42" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-article-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-article-alt-1</span><span class="i-code">0xeb42</span></div>
        <div title="Code: 0xeb43" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-article-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-article-1</span><span class="i-code">0xeb43</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb44" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-alt-1</span><span class="i-code">0xeb44</span></div>
        <div title="Code: 0xeb45" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-undo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-undo</span><span class="i-code">0xeb45</span></div>
        <div title="Code: 0xeb46" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-4</span><span class="i-code">0xeb46</span></div>
        <div title="Code: 0xeb47" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-inv</span><span class="i-code">0xeb47</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb48" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-alt-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-alt-2</span><span class="i-code">0xeb48</span></div>
        <div title="Code: 0xeb49" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-inv-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-inv-alt</span><span class="i-code">0xeb49</span></div>
        <div title="Code: 0xeb4a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-alt2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-alt2</span><span class="i-code">0xeb4a</span></div>
        <div title="Code: 0xeb4b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-inv-alt2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-inv-alt2</span><span class="i-code">0xeb4b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb4c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-3</span><span class="i-code">0xeb4c</span></div>
        <div title="Code: 0xeb4d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-inv</span><span class="i-code">0xeb4d</span></div>
        <div title="Code: 0xeb4e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-5</span><span class="i-code">0xeb4e</span></div>
        <div title="Code: 0xeb4f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-inv</span><span class="i-code">0xeb4f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb50" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-alt</span><span class="i-code">0xeb50</span></div>
        <div title="Code: 0xeb51" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-2</span><span class="i-code">0xeb51</span></div>
        <div title="Code: 0xeb52" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-5</span><span class="i-code">0xeb52</span></div>
        <div title="Code: 0xeb53" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-empty</span><span class="i-code">0xeb53</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb54" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-5</span><span class="i-code">0xeb54</span></div>
        <div title="Code: 0xeb55" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-inv</span><span class="i-code">0xeb55</span></div>
        <div title="Code: 0xeb56" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-alt</span><span class="i-code">0xeb56</span></div>
        <div title="Code: 0xeb57" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-inv-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-inv-alt</span><span class="i-code">0xeb57</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb58" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-neg"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-neg</span><span class="i-code">0xeb58</span></div>
        <div title="Code: 0xeb59" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-4</span><span class="i-code">0xeb59</span></div>
        <div title="Code: 0xeb5a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-right-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-right-alt</span><span class="i-code">0xeb5a</span></div>
        <div title="Code: 0xeb5b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-left-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-left-alt</span><span class="i-code">0xeb5b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb5c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-right</span><span class="i-code">0xeb5c</span></div>
        <div title="Code: 0xeb5d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-left</span><span class="i-code">0xeb5d</span></div>
        <div title="Code: 0xeb5e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud-1</span><span class="i-code">0xeb5e</span></div>
        <div title="Code: 0xeb5f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-cloud-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-cloud-1</span><span class="i-code">0xeb5f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb60" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-2</span><span class="i-code">0xeb60</span></div>
        <div title="Code: 0xeb61" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-3</span><span class="i-code">0xeb61</span></div>
        <div title="Code: 0xeb62" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-empty</span><span class="i-code">0xeb62</span></div>
        <div title="Code: 0xeb63" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-4</span><span class="i-code">0xeb63</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb64" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-4</span><span class="i-code">0xeb64</span></div>
        <div title="Code: 0xeb65" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pin</span><span class="i-code">0xeb65</span></div>
        <div title="Code: 0xeb66" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-empty</span><span class="i-code">0xeb66</span></div>
        <div title="Code: 0xeb67" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-4</span><span class="i-code">0xeb67</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb68" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-empty</span><span class="i-code">0xeb68</span></div>
        <div title="Code: 0xeb69" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-5</span><span class="i-code">0xeb69</span></div>
        <div title="Code: 0xeb6a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-4</span><span class="i-code">0xeb6a</span></div>
        <div title="Code: 0xeb6b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-2</span><span class="i-code">0xeb6b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb6c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-5</span><span class="i-code">0xeb6c</span></div>
        <div title="Code: 0xeb6d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-5</span><span class="i-code">0xeb6d</span></div>
        <div title="Code: 0xeb6e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-5</span><span class="i-code">0xeb6e</span></div>
        <div title="Code: 0xeb6f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-empty-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-empty-2</span><span class="i-code">0xeb6f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb70" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-5</span><span class="i-code">0xeb70</span></div>
        <div title="Code: 0xeb71" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-5</span><span class="i-code">0xeb71</span></div>
        <div title="Code: 0xeb72" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-2</span><span class="i-code">0xeb72</span></div>
        <div title="Code: 0xeb73" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-2</span><span class="i-code">0xeb73</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb74" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-4</span><span class="i-code">0xeb74</span></div>
        <div title="Code: 0xeb75" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-4</span><span class="i-code">0xeb75</span></div>
        <div title="Code: 0xeb76" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circle-1</span><span class="i-code">0xeb76</span></div>
        <div title="Code: 0xeb77" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-4</span><span class="i-code">0xeb77</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb78" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circle-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circle-2</span><span class="i-code">0xeb78</span></div>
        <div title="Code: 0xeb79" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-3</span><span class="i-code">0xeb79</span></div>
        <div title="Code: 0xeb7a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-circle-1</span><span class="i-code">0xeb7a</span></div>
        <div title="Code: 0xeb7b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-1</span><span class="i-code">0xeb7b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb7c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-circle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-circle-1</span><span class="i-code">0xeb7c</span></div>
        <div title="Code: 0xeb7d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-1</span><span class="i-code">0xeb7d</span></div>
        <div title="Code: 0xeb7e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-1</span><span class="i-code">0xeb7e</span></div>
        <div title="Code: 0xeb7f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-3</span><span class="i-code">0xeb7f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb80" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-3</span><span class="i-code">0xeb80</span></div>
        <div title="Code: 0xeb81" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-circled</span><span class="i-code">0xeb81</span></div>
        <div title="Code: 0xeb82" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-5</span><span class="i-code">0xeb82</span></div>
        <div title="Code: 0xeb83" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-circled-1</span><span class="i-code">0xeb83</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb84" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumbler"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumbler</span><span class="i-code">0xeb84</span></div>
        <div title="Code: 0xeb85" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumbler-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumbler-circled</span><span class="i-code">0xeb85</span></div>
        <div title="Code: 0xeb86" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-4</span><span class="i-code">0xeb86</span></div>
        <div title="Code: 0xeb87" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-outline</span><span class="i-code">0xeb87</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb88" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-2</span><span class="i-code">0xeb88</span></div>
        <div title="Code: 0xeb89" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-circled</span><span class="i-code">0xeb89</span></div>
        <div title="Code: 0xeb8a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-4</span><span class="i-code">0xeb8a</span></div>
        <div title="Code: 0xeb8b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-2</span><span class="i-code">0xeb8b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb8c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-circled</span><span class="i-code">0xeb8c</span></div>
        <div title="Code: 0xeb8d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-4</span><span class="i-code">0xeb8d</span></div>
        <div title="Code: 0xeb8e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-2</span><span class="i-code">0xeb8e</span></div>
        <div title="Code: 0xeb8f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-2</span><span class="i-code">0xeb8f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb90" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-circled</span><span class="i-code">0xeb90</span></div>
        <div title="Code: 0xeb91" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-5</span><span class="i-code">0xeb91</span></div>
        <div title="Code: 0xeb92" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-circled-1</span><span class="i-code">0xeb92</span></div>
        <div title="Code: 0xeb93" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-3</span><span class="i-code">0xeb93</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb94" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-circled-1</span><span class="i-code">0xeb94</span></div>
        <div title="Code: 0xeb95" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-numeric"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-numeric</span><span class="i-code">0xeb95</span></div>
        <div title="Code: 0xeb96" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-numeric-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-numeric-outline</span><span class="i-code">0xeb96</span></div>
        <div title="Code: 0xeb97" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-alphabet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-alphabet</span><span class="i-code">0xeb97</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb98" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-alphabet-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-alphabet-outline</span><span class="i-code">0xeb98</span></div>
        <div title="Code: 0xeb99" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-looped-square-interest"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-looped-square-interest</span><span class="i-code">0xeb99</span></div>
        <div title="Code: 0xeb9a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-looped-square-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-looped-square-outline</span><span class="i-code">0xeb9a</span></div>
        <div title="Code: 0xeb9b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-certificate-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-certificate-outline</span><span class="i-code">0xeb9b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeb9c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-certificate-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-certificate-1</span><span class="i-code">0xeb9c</span></div>
        <div title="Code: 0xeb9d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-scissors-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-scissors-outline</span><span class="i-code">0xeb9d</span></div>
        <div title="Code: 0xeb9e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-scissors"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-scissors</span><span class="i-code">0xeb9e</span></div>
        <div title="Code: 0xeb9f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flask"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flask</span><span class="i-code">0xeb9f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeba0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wine"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wine</span><span class="i-code">0xeba0</span></div>
        <div title="Code: 0xeba1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-coffee"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-coffee</span><span class="i-code">0xeba1</span></div>
        <div title="Code: 0xeba2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-beer-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-beer-1</span><span class="i-code">0xeba2</span></div>
        <div title="Code: 0xeba3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-anchor-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-anchor-outline</span><span class="i-code">0xeba3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeba4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-anchor-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-anchor-1</span><span class="i-code">0xeba4</span></div>
        <div title="Code: 0xeba5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-puzzle-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-puzzle-outline</span><span class="i-code">0xeba5</span></div>
        <div title="Code: 0xeba6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-puzzle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-puzzle</span><span class="i-code">0xeba6</span></div>
        <div title="Code: 0xeba7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tree"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tree</span><span class="i-code">0xeba7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeba8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calculator"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calculator</span><span class="i-code">0xeba8</span></div>
        <div title="Code: 0xeba9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-infinity-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-infinity-outline</span><span class="i-code">0xeba9</span></div>
        <div title="Code: 0xebaa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-infinity"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-infinity</span><span class="i-code">0xebaa</span></div>
        <div title="Code: 0xebab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-circled-1</span><span class="i-code">0xebab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pi-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pi-outline</span><span class="i-code">0xebac</span></div>
        <div title="Code: 0xebad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pi"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pi</span><span class="i-code">0xebad</span></div>
        <div title="Code: 0xebae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at-3</span><span class="i-code">0xebae</span></div>
        <div title="Code: 0xebaf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at-circled</span><span class="i-code">0xebaf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebb0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-cross"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-cross</span><span class="i-code">0xebb0</span></div>
        <div title="Code: 0xebb1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-parallel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-parallel</span><span class="i-code">0xebb1</span></div>
        <div title="Code: 0xebb2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-merge"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-merge</span><span class="i-code">0xebb2</span></div>
        <div title="Code: 0xebb3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-split"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-split</span><span class="i-code">0xebb3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebb4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-3</span><span class="i-code">0xebb4</span></div>
        <div title="Code: 0xebb5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-outline</span><span class="i-code">0xebb5</span></div>
        <div title="Code: 0xebb6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-database-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-database-1</span><span class="i-code">0xebb6</span></div>
        <div title="Code: 0xebb7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clipboard-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clipboard-1</span><span class="i-code">0xebb7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebb8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card-2</span><span class="i-code">0xebb8</span></div>
        <div title="Code: 0xebb9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ticket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ticket</span><span class="i-code">0xebb9</span></div>
        <div title="Code: 0xebba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-2</span><span class="i-code">0xebba</span></div>
        <div title="Code: 0xebbb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-outline</span><span class="i-code">0xebbb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebbc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-3</span><span class="i-code">0xebbc</span></div>
        <div title="Code: 0xebbd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-outline</span><span class="i-code">0xebbd</span></div>
        <div title="Code: 0xebbe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-alt</span><span class="i-code">0xebbe</span></div>
        <div title="Code: 0xebbf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-alt-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-alt-outline</span><span class="i-code">0xebbf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebc0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-2</span><span class="i-code">0xebc0</span></div>
        <div title="Code: 0xebc1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-outline</span><span class="i-code">0xebc1</span></div>
        <div title="Code: 0xebc2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-temperatire"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-temperatire</span><span class="i-code">0xebc2</span></div>
        <div title="Code: 0xebc3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gift-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gift-1</span><span class="i-code">0xebc3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebc4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-waves-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-waves-outline</span><span class="i-code">0xebc4</span></div>
        <div title="Code: 0xebc5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-waves"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-waves</span><span class="i-code">0xebc5</span></div>
        <div title="Code: 0xebc6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rain-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rain-2</span><span class="i-code">0xebc6</span></div>
        <div title="Code: 0xebc7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-sun-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-sun-1</span><span class="i-code">0xebc7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebc8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drizzle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drizzle-1</span><span class="i-code">0xebc8</span></div>
        <div title="Code: 0xebc9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snow-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snow-1</span><span class="i-code">0xebc9</span></div>
        <div title="Code: 0xebca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-flash-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-flash-1</span><span class="i-code">0xebca</span></div>
        <div title="Code: 0xebcb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-wind"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-wind</span><span class="i-code">0xebcb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebcc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wind-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wind-1</span><span class="i-code">0xebcc</span></div>
        <div title="Code: 0xebcd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plane-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plane-outline</span><span class="i-code">0xebcd</span></div>
        <div title="Code: 0xebce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plane"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plane</span><span class="i-code">0xebce</span></div>
        <div title="Code: 0xebcf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-leaf-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-leaf-1</span><span class="i-code">0xebcf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebd0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lifebuoy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lifebuoy</span><span class="i-code">0xebd0</span></div>
        <div title="Code: 0xebd1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-briefcase-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-briefcase-1</span><span class="i-code">0xebd1</span></div>
        <div title="Code: 0xebd2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-brush-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-brush-1</span><span class="i-code">0xebd2</span></div>
        <div title="Code: 0xebd3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pipette"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pipette</span><span class="i-code">0xebd3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebd4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-power-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-power-outline</span><span class="i-code">0xebd4</span></div>
        <div title="Code: 0xebd5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-power"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-power</span><span class="i-code">0xebd5</span></div>
        <div title="Code: 0xebd6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-outline</span><span class="i-code">0xebd6</span></div>
        <div title="Code: 0xebd7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-1</span><span class="i-code">0xebd7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebd8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-2</span><span class="i-code">0xebd8</span></div>
        <div title="Code: 0xebd9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash-2</span><span class="i-code">0xebd9</span></div>
        <div title="Code: 0xebda" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash-outline</span><span class="i-code">0xebda</span></div>
        <div title="Code: 0xebdb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-6</span><span class="i-code">0xebdb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebdc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-filled</span><span class="i-code">0xebdc</span></div>
        <div title="Code: 0xebdd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-2</span><span class="i-code">0xebdd</span></div>
        <div title="Code: 0xebde" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-alt-1</span><span class="i-code">0xebde</span></div>
        <div title="Code: 0xebdf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-alt-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-alt-outline</span><span class="i-code">0xebdf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebe0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-4</span><span class="i-code">0xebe0</span></div>
        <div title="Code: 0xebe1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-outline</span><span class="i-code">0xebe1</span></div>
        <div title="Code: 0xebe2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-contrast"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-contrast</span><span class="i-code">0xebe2</span></div>
        <div title="Code: 0xebe3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-4</span><span class="i-code">0xebe3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebe4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tablet-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tablet-2</span><span class="i-code">0xebe4</span></div>
        <div title="Code: 0xebe5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-laptop-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-laptop-1</span><span class="i-code">0xebe5</span></div>
        <div title="Code: 0xebe6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-desktop-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-desktop-2</span><span class="i-code">0xebe6</span></div>
        <div title="Code: 0xebe7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wifi"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wifi</span><span class="i-code">0xebe7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebe8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wifi-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wifi-outline</span><span class="i-code">0xebe8</span></div>
        <div title="Code: 0xebe9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-3</span><span class="i-code">0xebe9</span></div>
        <div title="Code: 0xebea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-outline</span><span class="i-code">0xebea</span></div>
        <div title="Code: 0xebeb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plug"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plug</span><span class="i-code">0xebeb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-3</span><span class="i-code">0xebec</span></div>
        <div title="Code: 0xebed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-outline</span><span class="i-code">0xebed</span></div>
        <div title="Code: 0xebee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-4</span><span class="i-code">0xebee</span></div>
        <div title="Code: 0xebef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-outline</span><span class="i-code">0xebef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebf0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-3</span><span class="i-code">0xebf0</span></div>
        <div title="Code: 0xebf1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-fw-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-fw-outline</span><span class="i-code">0xebf1</span></div>
        <div title="Code: 0xebf2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-fw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-fw</span><span class="i-code">0xebf2</span></div>
        <div title="Code: 0xebf3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rewind-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rewind-outline</span><span class="i-code">0xebf3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebf4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rewind"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rewind</span><span class="i-code">0xebf4</span></div>
        <div title="Code: 0xebf5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-record-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-record-outline</span><span class="i-code">0xebf5</span></div>
        <div title="Code: 0xebf6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-record-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-record-1</span><span class="i-code">0xebf6</span></div>
        <div title="Code: 0xebf7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-outline</span><span class="i-code">0xebf7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebf8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-2</span><span class="i-code">0xebf8</span></div>
        <div title="Code: 0xebf9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-alt-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-alt-outline</span><span class="i-code">0xebf9</span></div>
        <div title="Code: 0xebfa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-alt</span><span class="i-code">0xebfa</span></div>
        <div title="Code: 0xebfb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat1</span><span class="i-code">0xebfb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xebfc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat2</span><span class="i-code">0xebfc</span></div>
        <div title="Code: 0xebfd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat3</span><span class="i-code">0xebfd</span></div>
        <div title="Code: 0xebfe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat4</span><span class="i-code">0xebfe</span></div>
        <div title="Code: 0xebff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bat-charge-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bat-charge-1</span><span class="i-code">0xebff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec00" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-outline</span><span class="i-code">0xec00</span></div>
        <div title="Code: 0xec01" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shuffle-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shuffle-2</span><span class="i-code">0xec01</span></div>
        <div title="Code: 0xec02" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-alt-1</span><span class="i-code">0xec02</span></div>
        <div title="Code: 0xec03" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-alt-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-alt-outline</span><span class="i-code">0xec03</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec04" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-1</span><span class="i-code">0xec04</span></div>
        <div title="Code: 0xec05" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-outline</span><span class="i-code">0xec05</span></div>
        <div title="Code: 0xec06" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-cw-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-cw-2</span><span class="i-code">0xec06</span></div>
        <div title="Code: 0xec07" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-cw-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-cw-outline</span><span class="i-code">0xec07</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec08" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-3</span><span class="i-code">0xec08</span></div>
        <div title="Code: 0xec09" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-outline</span><span class="i-code">0xec09</span></div>
        <div title="Code: 0xec0a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-small"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-small</span><span class="i-code">0xec0a</span></div>
        <div title="Code: 0xec0b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-small"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-small</span><span class="i-code">0xec0b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec0c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-small"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-small</span><span class="i-code">0xec0c</span></div>
        <div title="Code: 0xec0d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-small"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-small</span><span class="i-code">0xec0d</span></div>
        <div title="Code: 0xec0e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-outline</span><span class="i-code">0xec0e</span></div>
        <div title="Code: 0xec0f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-outline</span><span class="i-code">0xec0f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec10" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-outline</span><span class="i-code">0xec10</span></div>
        <div title="Code: 0xec11" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-outline</span><span class="i-code">0xec11</span></div>
        <div title="Code: 0xec12" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-4</span><span class="i-code">0xec12</span></div>
        <div title="Code: 0xec13" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-3</span><span class="i-code">0xec13</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec14" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-outline</span><span class="i-code">0xec14</span></div>
        <div title="Code: 0xec15" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-3</span><span class="i-code">0xec15</span></div>
        <div title="Code: 0xec16" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-outline</span><span class="i-code">0xec16</span></div>
        <div title="Code: 0xec17" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-4</span><span class="i-code">0xec17</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec18" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-normal-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-normal-outline</span><span class="i-code">0xec18</span></div>
        <div title="Code: 0xec19" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-normal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-normal</span><span class="i-code">0xec19</span></div>
        <div title="Code: 0xec1a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-move-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-move-outline</span><span class="i-code">0xec1a</span></div>
        <div title="Code: 0xec1b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-move-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-move-2</span><span class="i-code">0xec1b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec1c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup-3</span><span class="i-code">0xec1c</span></div>
        <div title="Code: 0xec1d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in-outline</span><span class="i-code">0xec1d</span></div>
        <div title="Code: 0xec1e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in-3</span><span class="i-code">0xec1e</span></div>
        <div title="Code: 0xec1f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out-outline</span><span class="i-code">0xec1f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec20" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out-3</span><span class="i-code">0xec20</span></div>
        <div title="Code: 0xec21" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup-4</span><span class="i-code">0xec21</span></div>
        <div title="Code: 0xec22" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-outline</span><span class="i-code">0xec22</span></div>
        <div title="Code: 0xec23" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-3</span><span class="i-code">0xec23</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec24" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-outline</span><span class="i-code">0xec24</span></div>
        <div title="Code: 0xec25" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-3</span><span class="i-code">0xec25</span></div>
        <div title="Code: 0xec26" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-4</span><span class="i-code">0xec26</span></div>
        <div title="Code: 0xec27" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-3</span><span class="i-code">0xec27</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec28" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lightbulb-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lightbulb-2</span><span class="i-code">0xec28</span></div>
        <div title="Code: 0xec29" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stopwatch-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stopwatch-1</span><span class="i-code">0xec29</span></div>
        <div title="Code: 0xec2a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wristwatch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wristwatch</span><span class="i-code">0xec2a</span></div>
        <div title="Code: 0xec2b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-6</span><span class="i-code">0xec2b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec2c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-headphones-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-headphones-2</span><span class="i-code">0xec2c</span></div>
        <div title="Code: 0xec2d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-high"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-high</span><span class="i-code">0xec2d</span></div>
        <div title="Code: 0xec2e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-middle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-middle</span><span class="i-code">0xec2e</span></div>
        <div title="Code: 0xec2f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-low"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-low</span><span class="i-code">0xec2f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec30" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-off-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-off-3</span><span class="i-code">0xec30</span></div>
        <div title="Code: 0xec31" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-3</span><span class="i-code">0xec31</span></div>
        <div title="Code: 0xec32" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-outline</span><span class="i-code">0xec32</span></div>
        <div title="Code: 0xec33" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-6</span><span class="i-code">0xec33</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec34" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-outlilne"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-outlilne</span><span class="i-code">0xec34</span></div>
        <div title="Code: 0xec35" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-2</span><span class="i-code">0xec35</span></div>
        <div title="Code: 0xec36" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-3</span><span class="i-code">0xec36</span></div>
        <div title="Code: 0xec37" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-outline</span><span class="i-code">0xec37</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec38" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-5</span><span class="i-code">0xec38</span></div>
        <div title="Code: 0xec39" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-outline</span><span class="i-code">0xec39</span></div>
        <div title="Code: 0xec3a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-menu-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-menu-1</span><span class="i-code">0xec3a</span></div>
        <div title="Code: 0xec3b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-menu-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-menu-outline</span><span class="i-code">0xec3b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec3c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-6</span><span class="i-code">0xec3c</span></div>
        <div title="Code: 0xec3d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map</span><span class="i-code">0xec3d</span></div>
        <div title="Code: 0xec3e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-direction-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-direction-outline</span><span class="i-code">0xec3e</span></div>
        <div title="Code: 0xec3f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-direction"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-direction</span><span class="i-code">0xec3f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec40" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-3</span><span class="i-code">0xec40</span></div>
        <div title="Code: 0xec41" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-6</span><span class="i-code">0xec41</span></div>
        <div title="Code: 0xec42" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-6</span><span class="i-code">0xec42</span></div>
        <div title="Code: 0xec43" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-text"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-text</span><span class="i-code">0xec43</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec44" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-add"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-add</span><span class="i-code">0xec44</span></div>
        <div title="Code: 0xec45" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-remove"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-remove</span><span class="i-code">0xec45</span></div>
        <div title="Code: 0xec46" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-news"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-news</span><span class="i-code">0xec46</span></div>
        <div title="Code: 0xec47" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-4</span><span class="i-code">0xec47</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec48" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-add"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-add</span><span class="i-code">0xec48</span></div>
        <div title="Code: 0xec49" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-delete"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-delete</span><span class="i-code">0xec49</span></div>
        <div title="Code: 0xec4a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-archive-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-archive-1</span><span class="i-code">0xec4a</span></div>
        <div title="Code: 0xec4b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box-2</span><span class="i-code">0xec4b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec4c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-outline</span><span class="i-code">0xec4c</span></div>
        <div title="Code: 0xec4d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-5</span><span class="i-code">0xec4d</span></div>
        <div title="Code: 0xec4e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-outline</span><span class="i-code">0xec4e</span></div>
        <div title="Code: 0xec4f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-1</span><span class="i-code">0xec4f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec50" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-outline</span><span class="i-code">0xec50</span></div>
        <div title="Code: 0xec51" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-address"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-address</span><span class="i-code">0xec51</span></div>
        <div title="Code: 0xec52" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vcard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vcard</span><span class="i-code">0xec52</span></div>
        <div title="Code: 0xec53" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-contacts"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-contacts</span><span class="i-code">0xec53</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec54" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-warning-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-warning-1</span><span class="i-code">0xec54</span></div>
        <div title="Code: 0xec55" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-warning-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-warning-empty</span><span class="i-code">0xec55</span></div>
        <div title="Code: 0xec56" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-filled</span><span class="i-code">0xec56</span></div>
        <div title="Code: 0xec57" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-3</span><span class="i-code">0xec57</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec58" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-3</span><span class="i-code">0xec58</span></div>
        <div title="Code: 0xec59" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-alt</span><span class="i-code">0xec59</span></div>
        <div title="Code: 0xec5a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-4</span><span class="i-code">0xec5a</span></div>
        <div title="Code: 0xec5b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-5</span><span class="i-code">0xec5b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec5c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-4</span><span class="i-code">0xec5c</span></div>
        <div title="Code: 0xec5d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit-2</span><span class="i-code">0xec5d</span></div>
        <div title="Code: 0xec5e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-feather"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-feather</span><span class="i-code">0xec5e</span></div>
        <div title="Code: 0xec5f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pen"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pen</span><span class="i-code">0xec5f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec60" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-5</span><span class="i-code">0xec60</span></div>
        <div title="Code: 0xec61" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-3</span><span class="i-code">0xec61</span></div>
        <div title="Code: 0xec62" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-outline</span><span class="i-code">0xec62</span></div>
        <div title="Code: 0xec63" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-code-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-code-1</span><span class="i-code">0xec63</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec64" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-outline</span><span class="i-code">0xec64</span></div>
        <div title="Code: 0xec65" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-5</span><span class="i-code">0xec65</span></div>
        <div title="Code: 0xec66" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-5</span><span class="i-code">0xec66</span></div>
        <div title="Code: 0xec67" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tags-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tags-1</span><span class="i-code">0xec67</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec68" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark-1</span><span class="i-code">0xec68</span></div>
        <div title="Code: 0xec69" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-1</span><span class="i-code">0xec69</span></div>
        <div title="Code: 0xec6a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-filled</span><span class="i-code">0xec6a</span></div>
        <div title="Code: 0xec6b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-3</span><span class="i-code">0xec6b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec6c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down-2</span><span class="i-code">0xec6c</span></div>
        <div title="Code: 0xec6d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-outline</span><span class="i-code">0xec6d</span></div>
        <div title="Code: 0xec6e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-4</span><span class="i-code">0xec6e</span></div>
        <div title="Code: 0xec6f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-outline</span><span class="i-code">0xec6f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec70" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-3</span><span class="i-code">0xec70</span></div>
        <div title="Code: 0xec71" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud-outline</span><span class="i-code">0xec71</span></div>
        <div title="Code: 0xec72" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud-2</span><span class="i-code">0xec72</span></div>
        <div title="Code: 0xec73" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-outline</span><span class="i-code">0xec73</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec74" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-2</span><span class="i-code">0xec74</span></div>
        <div title="Code: 0xec75" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-outline</span><span class="i-code">0xec75</span></div>
        <div title="Code: 0xec76" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-2</span><span class="i-code">0xec76</span></div>
        <div title="Code: 0xec77" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-code-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-code-outline</span><span class="i-code">0xec77</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec78" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pin-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pin-1</span><span class="i-code">0xec78</span></div>
        <div title="Code: 0xec79" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pin-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pin-outline</span><span class="i-code">0xec79</span></div>
        <div title="Code: 0xec7a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-filled</span><span class="i-code">0xec7a</span></div>
        <div title="Code: 0xec7b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-5</span><span class="i-code">0xec7b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec7c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-filled</span><span class="i-code">0xec7c</span></div>
        <div title="Code: 0xec7d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-6</span><span class="i-code">0xec7d</span></div>
        <div title="Code: 0xec7e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-5</span><span class="i-code">0xec7e</span></div>
        <div title="Code: 0xec7f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-outline</span><span class="i-code">0xec7f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec80" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-3</span><span class="i-code">0xec80</span></div>
        <div title="Code: 0xec81" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-outline</span><span class="i-code">0xec81</span></div>
        <div title="Code: 0xec82" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-4</span><span class="i-code">0xec82</span></div>
        <div title="Code: 0xec83" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-outline</span><span class="i-code">0xec83</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec84" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-2</span><span class="i-code">0xec84</span></div>
        <div title="Code: 0xec85" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-outline</span><span class="i-code">0xec85</span></div>
        <div title="Code: 0xec86" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eq"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eq</span><span class="i-code">0xec86</span></div>
        <div title="Code: 0xec87" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eq-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eq-outline</span><span class="i-code">0xec87</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec88" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-divide"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-divide</span><span class="i-code">0xec88</span></div>
        <div title="Code: 0xec89" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-divide-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-divide-outline</span><span class="i-code">0xec89</span></div>
        <div title="Code: 0xec8a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-2</span><span class="i-code">0xec8a</span></div>
        <div title="Code: 0xec8b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-outline</span><span class="i-code">0xec8b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec8c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-4</span><span class="i-code">0xec8c</span></div>
        <div title="Code: 0xec8d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-outline</span><span class="i-code">0xec8d</span></div>
        <div title="Code: 0xec8e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled-2</span><span class="i-code">0xec8e</span></div>
        <div title="Code: 0xec8f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled-outline</span><span class="i-code">0xec8f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec90" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-alt-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-alt-filled</span><span class="i-code">0xec90</span></div>
        <div title="Code: 0xec91" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-alt</span><span class="i-code">0xec91</span></div>
        <div title="Code: 0xec92" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-5</span><span class="i-code">0xec92</span></div>
        <div title="Code: 0xec93" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-outline</span><span class="i-code">0xec93</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec94" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-5</span><span class="i-code">0xec94</span></div>
        <div title="Code: 0xec95" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-outline</span><span class="i-code">0xec95</span></div>
        <div title="Code: 0xec96" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-4</span><span class="i-code">0xec96</span></div>
        <div title="Code: 0xec97" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-outline</span><span class="i-code">0xec97</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec98" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-large-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-large-2</span><span class="i-code">0xec98</span></div>
        <div title="Code: 0xec99" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-large-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-large-outline</span><span class="i-code">0xec99</span></div>
        <div title="Code: 0xec9a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-3</span><span class="i-code">0xec9a</span></div>
        <div title="Code: 0xec9b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-outline</span><span class="i-code">0xec9b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xec9c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-5</span><span class="i-code">0xec9c</span></div>
        <div title="Code: 0xec9d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-outline</span><span class="i-code">0xec9d</span></div>
        <div title="Code: 0xec9e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-3</span><span class="i-code">0xec9e</span></div>
        <div title="Code: 0xec9f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-outline</span><span class="i-code">0xec9f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeca0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music-outline</span><span class="i-code">0xeca0</span></div>
        <div title="Code: 0xeca1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music-2</span><span class="i-code">0xeca1</span></div>
        <div title="Code: 0xeca2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-outline</span><span class="i-code">0xeca2</span></div>
        <div title="Code: 0xeca3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-6</span><span class="i-code">0xeca3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeca4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-6</span><span class="i-code">0xeca4</span></div>
        <div title="Code: 0xeca5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-6</span><span class="i-code">0xeca5</span></div>
        <div title="Code: 0xeca6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-filled</span><span class="i-code">0xeca6</span></div>
        <div title="Code: 0xeca7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-6</span><span class="i-code">0xeca7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeca8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-filled</span><span class="i-code">0xeca8</span></div>
        <div title="Code: 0xeca9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-outline</span><span class="i-code">0xeca9</span></div>
        <div title="Code: 0xecaa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-6</span><span class="i-code">0xecaa</span></div>
        <div title="Code: 0xecab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-users-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-users-outline</span><span class="i-code">0xecab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-users-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-users-1</span><span class="i-code">0xecac</span></div>
        <div title="Code: 0xecad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-add-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-add-outline</span><span class="i-code">0xecad</span></div>
        <div title="Code: 0xecae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-add"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-add</span><span class="i-code">0xecae</span></div>
        <div title="Code: 0xecaf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-delete-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-delete-outline</span><span class="i-code">0xecaf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecb0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-delete"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-delete</span><span class="i-code">0xecb0</span></div>
        <div title="Code: 0xecb1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-3</span><span class="i-code">0xecb1</span></div>
        <div title="Code: 0xecb2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-outline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-outline</span><span class="i-code">0xecb2</span></div>
        <div title="Code: 0xecb3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-4</span><span class="i-code">0xecb3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecb4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rdio"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rdio</span><span class="i-code">0xecb4</span></div>
        <div title="Code: 0xecb5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spotify-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spotify-1</span><span class="i-code">0xecb5</span></div>
        <div title="Code: 0xecb6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spotify-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spotify-circled</span><span class="i-code">0xecb6</span></div>
        <div title="Code: 0xecb7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rdio-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rdio-circled</span><span class="i-code">0xecb7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecb8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-qq"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-qq</span><span class="i-code">0xecb8</span></div>
        <div title="Code: 0xecb9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-circled-1</span><span class="i-code">0xecb9</span></div>
        <div title="Code: 0xecba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-3</span><span class="i-code">0xecba</span></div>
        <div title="Code: 0xecbb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon-circled</span><span class="i-code">0xecbb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecbc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon-2</span><span class="i-code">0xecbc</span></div>
        <div title="Code: 0xecbd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-circled-2</span><span class="i-code">0xecbd</span></div>
        <div title="Code: 0xecbe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-4</span><span class="i-code">0xecbe</span></div>
        <div title="Code: 0xecbf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-circled-2</span><span class="i-code">0xecbf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecc0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-5</span><span class="i-code">0xecc0</span></div>
        <div title="Code: 0xecc1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-circled</span><span class="i-code">0xecc1</span></div>
        <div title="Code: 0xecc2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-3</span><span class="i-code">0xecc2</span></div>
        <div title="Code: 0xecc3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-circled-1</span><span class="i-code">0xecc3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecc4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-3</span><span class="i-code">0xecc4</span></div>
        <div title="Code: 0xecc5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-2</span><span class="i-code">0xecc5</span></div>
        <div title="Code: 0xecc6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-squared</span><span class="i-code">0xecc6</span></div>
        <div title="Code: 0xecc7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-circled-2</span><span class="i-code">0xecc7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecc8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-6</span><span class="i-code">0xecc8</span></div>
        <div title="Code: 0xecc9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-circled-2</span><span class="i-code">0xecc9</span></div>
        <div title="Code: 0xecca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-6</span><span class="i-code">0xecca</span></div>
        <div title="Code: 0xeccb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-circled-1</span><span class="i-code">0xeccb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeccc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-parallel-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-parallel-1</span><span class="i-code">0xeccc</span></div>
        <div title="Code: 0xeccd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rocket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rocket</span><span class="i-code">0xeccd</span></div>
        <div title="Code: 0xecce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gauge-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gauge-1</span><span class="i-code">0xecce</span></div>
        <div title="Code: 0xeccf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-traffic-cone"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-traffic-cone</span><span class="i-code">0xeccf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecd0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-2</span><span class="i-code">0xecd0</span></div>
        <div title="Code: 0xecd1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-by"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-by</span><span class="i-code">0xecd1</span></div>
        <div title="Code: 0xecd2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-nc"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-nc</span><span class="i-code">0xecd2</span></div>
        <div title="Code: 0xecd3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-nc-eu"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-nc-eu</span><span class="i-code">0xecd3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecd4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-circled-1</span><span class="i-code">0xecd4</span></div>
        <div title="Code: 0xecd5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-nc-jp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-nc-jp</span><span class="i-code">0xecd5</span></div>
        <div title="Code: 0xecd6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-sa"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-sa</span><span class="i-code">0xecd6</span></div>
        <div title="Code: 0xecd7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-nd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-nd</span><span class="i-code">0xecd7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecd8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-pd"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-pd</span><span class="i-code">0xecd8</span></div>
        <div title="Code: 0xecd9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-zero"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-zero</span><span class="i-code">0xecd9</span></div>
        <div title="Code: 0xecda" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-share"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-share</span><span class="i-code">0xecda</span></div>
        <div title="Code: 0xecdb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-remix"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-remix</span><span class="i-code">0xecdb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecdc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-5</span><span class="i-code">0xecdc</span></div>
        <div title="Code: 0xecdd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-3</span><span class="i-code">0xecdd</span></div>
        <div title="Code: 0xecde" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-3</span><span class="i-code">0xecde</span></div>
        <div title="Code: 0xecdf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-circled-1</span><span class="i-code">0xecdf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xece0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-4</span><span class="i-code">0xece0</span></div>
        <div title="Code: 0xece1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-line"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-line</span><span class="i-code">0xece1</span></div>
        <div title="Code: 0xece2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-tree"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-tree</span><span class="i-code">0xece2</span></div>
        <div title="Code: 0xece3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-branch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-branch</span><span class="i-code">0xece3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xece4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flow-cascade"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flow-cascade</span><span class="i-code">0xece4</span></div>
        <div title="Code: 0xece5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-4</span><span class="i-code">0xece5</span></div>
        <div title="Code: 0xece6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thermometer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thermometer</span><span class="i-code">0xece6</span></div>
        <div title="Code: 0xece7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bucket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bucket</span><span class="i-code">0xece7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xece8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drive"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drive</span><span class="i-code">0xece8</span></div>
        <div title="Code: 0xece9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-database-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-database-2</span><span class="i-code">0xece9</span></div>
        <div title="Code: 0xecea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-megaphone-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-megaphone-2</span><span class="i-code">0xecea</span></div>
        <div title="Code: 0xeceb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clipboard-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clipboard-2</span><span class="i-code">0xeceb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-floppy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-floppy</span><span class="i-code">0xecec</span></div>
        <div title="Code: 0xeced" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card-3</span><span class="i-code">0xeced</span></div>
        <div title="Code: 0xecee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-air"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-air</span><span class="i-code">0xecee</span></div>
        <div title="Code: 0xecef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-droplet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-droplet</span><span class="i-code">0xecef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecf0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-water"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-water</span><span class="i-code">0xecf0</span></div>
        <div title="Code: 0xecf1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ticket-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ticket-1</span><span class="i-code">0xecf1</span></div>
        <div title="Code: 0xecf2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-language"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-language</span><span class="i-code">0xecf2</span></div>
        <div title="Code: 0xecf3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-graduation-cap-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-graduation-cap-1</span><span class="i-code">0xecf3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecf4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tape"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tape</span><span class="i-code">0xecf4</span></div>
        <div title="Code: 0xecf5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash-3</span><span class="i-code">0xecf5</span></div>
        <div title="Code: 0xecf6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-3</span><span class="i-code">0xecf6</span></div>
        <div title="Code: 0xecf7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flight-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flight-1</span><span class="i-code">0xecf7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecf8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-2</span><span class="i-code">0xecf8</span></div>
        <div title="Code: 0xecf9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-leaf-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-leaf-2</span><span class="i-code">0xecf9</span></div>
        <div title="Code: 0xecfa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lifebuoy-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lifebuoy-1</span><span class="i-code">0xecfa</span></div>
        <div title="Code: 0xecfb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mouse"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mouse</span><span class="i-code">0xecfb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xecfc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-briefcase-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-briefcase-2</span><span class="i-code">0xecfc</span></div>
        <div title="Code: 0xecfd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-suitcase"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-suitcase</span><span class="i-code">0xecfd</span></div>
        <div title="Code: 0xecfe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dot"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dot</span><span class="i-code">0xecfe</span></div>
        <div title="Code: 0xecff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dot-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dot-2</span><span class="i-code">0xecff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed00" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dot-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dot-3</span><span class="i-code">0xed00</span></div>
        <div title="Code: 0xed01" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-brush-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-brush-2</span><span class="i-code">0xed01</span></div>
        <div title="Code: 0xed02" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-magnet-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-magnet-1</span><span class="i-code">0xed02</span></div>
        <div title="Code: 0xed03" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-infinity-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-infinity-1</span><span class="i-code">0xed03</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed04" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-erase"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-erase</span><span class="i-code">0xed04</span></div>
        <div title="Code: 0xed05" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-3</span><span class="i-code">0xed05</span></div>
        <div title="Code: 0xed06" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-line"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-line</span><span class="i-code">0xed06</span></div>
        <div title="Code: 0xed07" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-4</span><span class="i-code">0xed07</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed08" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-area"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-area</span><span class="i-code">0xed08</span></div>
        <div title="Code: 0xed09" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-thunder"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-thunder</span><span class="i-code">0xed09</span></div>
        <div title="Code: 0xed0a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-7</span><span class="i-code">0xed0a</span></div>
        <div title="Code: 0xed0b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-5</span><span class="i-code">0xed0b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed0c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-install"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-install</span><span class="i-code">0xed0c</span></div>
        <div title="Code: 0xed0d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-3</span><span class="i-code">0xed0d</span></div>
        <div title="Code: 0xed0e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cd-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cd-3</span><span class="i-code">0xed0e</span></div>
        <div title="Code: 0xed0f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-network-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-network-1</span><span class="i-code">0xed0f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed10" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-5</span><span class="i-code">0xed10</span></div>
        <div title="Code: 0xed11" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-monitor-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-monitor-1</span><span class="i-code">0xed11</span></div>
        <div title="Code: 0xed12" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-back-in-time"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-back-in-time</span><span class="i-code">0xed12</span></div>
        <div title="Code: 0xed13" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery</span><span class="i-code">0xed13</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed14" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trophy-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trophy-1</span><span class="i-code">0xed14</span></div>
        <div title="Code: 0xed15" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal-4</span><span class="i-code">0xed15</span></div>
        <div title="Code: 0xed16" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-add"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-add</span><span class="i-code">0xed16</span></div>
        <div title="Code: 0xed17" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-3</span><span class="i-code">0xed17</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed18" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-palette"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-palette</span><span class="i-code">0xed18</span></div>
        <div title="Code: 0xed19" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-4</span><span class="i-code">0xed19</span></div>
        <div title="Code: 0xed1a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-8</span><span class="i-code">0xed1a</span></div>
        <div title="Code: 0xed1b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-9"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-9</span><span class="i-code">0xed1b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed1c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-10"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-10</span><span class="i-code">0xed1c</span></div>
        <div title="Code: 0xed1d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-thin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-thin</span><span class="i-code">0xed1d</span></div>
        <div title="Code: 0xed1e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-thin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-thin</span><span class="i-code">0xed1e</span></div>
        <div title="Code: 0xed1f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ccw-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ccw-1</span><span class="i-code">0xed1f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed20" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-thin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-thin</span><span class="i-code">0xed20</span></div>
        <div title="Code: 0xed21" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-4</span><span class="i-code">0xed21</span></div>
        <div title="Code: 0xed22" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-ccw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-ccw</span><span class="i-code">0xed22</span></div>
        <div title="Code: 0xed23" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-level-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-level-down</span><span class="i-code">0xed23</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed24" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-level-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-level-up</span><span class="i-code">0xed24</span></div>
        <div title="Code: 0xed25" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shuffle-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shuffle-3</span><span class="i-code">0xed25</span></div>
        <div title="Code: 0xed26" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-loop-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-loop-2</span><span class="i-code">0xed26</span></div>
        <div title="Code: 0xed27" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-switch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-switch</span><span class="i-code">0xed27</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed28" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-4</span><span class="i-code">0xed28</span></div>
        <div title="Code: 0xed29" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-5</span><span class="i-code">0xed29</span></div>
        <div title="Code: 0xed2a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-4</span><span class="i-code">0xed2a</span></div>
        <div title="Code: 0xed2b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-record-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-record-2</span><span class="i-code">0xed2b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed2c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-end-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-end-2</span><span class="i-code">0xed2c</span></div>
        <div title="Code: 0xed2d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-start-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-start-2</span><span class="i-code">0xed2d</span></div>
        <div title="Code: 0xed2e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-forward-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-forward-2</span><span class="i-code">0xed2e</span></div>
        <div title="Code: 0xed2f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-backward-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-backward-2</span><span class="i-code">0xed2f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed30" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-progress-11"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-progress-11</span><span class="i-code">0xed30</span></div>
        <div title="Code: 0xed31" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-thin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-thin</span><span class="i-code">0xed31</span></div>
        <div title="Code: 0xed32" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-bold-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-bold-1</span><span class="i-code">0xed32</span></div>
        <div title="Code: 0xed33" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-bold-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-bold-1</span><span class="i-code">0xed33</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed34" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-bold-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-bold-1</span><span class="i-code">0xed34</span></div>
        <div title="Code: 0xed35" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-bold-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-bold-1</span><span class="i-code">0xed35</span></div>
        <div title="Code: 0xed36" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-dir-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-dir-1</span><span class="i-code">0xed36</span></div>
        <div title="Code: 0xed37" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-dir-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-dir-2</span><span class="i-code">0xed37</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed38" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-dir-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-dir-1</span><span class="i-code">0xed38</span></div>
        <div title="Code: 0xed39" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-dir-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-dir-2</span><span class="i-code">0xed39</span></div>
        <div title="Code: 0xed3a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-5</span><span class="i-code">0xed3a</span></div>
        <div title="Code: 0xed3b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-4</span><span class="i-code">0xed3b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed3c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-4</span><span class="i-code">0xed3c</span></div>
        <div title="Code: 0xed3d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-5</span><span class="i-code">0xed3d</span></div>
        <div title="Code: 0xed3e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open-big</span><span class="i-code">0xed3e</span></div>
        <div title="Code: 0xed3f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-big</span><span class="i-code">0xed3f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed40" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-big</span><span class="i-code">0xed40</span></div>
        <div title="Code: 0xed41" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open-big</span><span class="i-code">0xed41</span></div>
        <div title="Code: 0xed42" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open-mini"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open-mini</span><span class="i-code">0xed42</span></div>
        <div title="Code: 0xed43" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-mini"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-mini</span><span class="i-code">0xed43</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed44" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-mini"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-mini</span><span class="i-code">0xed44</span></div>
        <div title="Code: 0xed45" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open-mini"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open-mini</span><span class="i-code">0xed45</span></div>
        <div title="Code: 0xed46" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open-2</span><span class="i-code">0xed46</span></div>
        <div title="Code: 0xed47" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-4</span><span class="i-code">0xed47</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed48" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-4</span><span class="i-code">0xed48</span></div>
        <div title="Code: 0xed49" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open-2</span><span class="i-code">0xed49</span></div>
        <div title="Code: 0xed4a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circled-1</span><span class="i-code">0xed4a</span></div>
        <div title="Code: 0xed4b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circled-1</span><span class="i-code">0xed4b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed4c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circled-1</span><span class="i-code">0xed4c</span></div>
        <div title="Code: 0xed4d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circled-1</span><span class="i-code">0xed4d</span></div>
        <div title="Code: 0xed4e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrow-combo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrow-combo</span><span class="i-code">0xed4e</span></div>
        <div title="Code: 0xed4f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-window"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-window</span><span class="i-code">0xed4f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed50" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-publish"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-publish</span><span class="i-code">0xed50</span></div>
        <div title="Code: 0xed51" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-popup-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-popup-5</span><span class="i-code">0xed51</span></div>
        <div title="Code: 0xed52" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small-3</span><span class="i-code">0xed52</span></div>
        <div title="Code: 0xed53" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-5</span><span class="i-code">0xed53</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed54" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-4</span><span class="i-code">0xed54</span></div>
        <div title="Code: 0xed55" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-adjust-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-adjust-1</span><span class="i-code">0xed55</span></div>
        <div title="Code: 0xed56" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-light-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-light-up</span><span class="i-code">0xed56</span></div>
        <div title="Code: 0xed57" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-light-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-light-down</span><span class="i-code">0xed57</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed58" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lamp-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lamp-1</span><span class="i-code">0xed58</span></div>
        <div title="Code: 0xed59" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-5</span><span class="i-code">0xed59</span></div>
        <div title="Code: 0xed5a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-archive-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-archive-2</span><span class="i-code">0xed5a</span></div>
        <div title="Code: 0xed5b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box-3</span><span class="i-code">0xed5b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed5c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-6</span><span class="i-code">0xed5c</span></div>
        <div title="Code: 0xed5d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-2</span><span class="i-code">0xed5d</span></div>
        <div title="Code: 0xed5e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-6</span><span class="i-code">0xed5e</span></div>
        <div title="Code: 0xed5f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tools"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tools</span><span class="i-code">0xed5f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed60" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-share-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-share-2</span><span class="i-code">0xed60</span></div>
        <div title="Code: 0xed61" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shareable"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shareable</span><span class="i-code">0xed61</span></div>
        <div title="Code: 0xed62" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-3</span><span class="i-code">0xed62</span></div>
        <div title="Code: 0xed63" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bag</span><span class="i-code">0xed63</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed64" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-7</span><span class="i-code">0xed64</span></div>
        <div title="Code: 0xed65" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-login-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-login-2</span><span class="i-code">0xed65</span></div>
        <div title="Code: 0xed66" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-logout-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-logout-2</span><span class="i-code">0xed66</span></div>
        <div title="Code: 0xed67" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-4</span><span class="i-code">0xed67</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed68" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mute"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mute</span><span class="i-code">0xed68</span></div>
        <div title="Code: 0xed69" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sound-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sound-1</span><span class="i-code">0xed69</span></div>
        <div title="Code: 0xed6a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-1</span><span class="i-code">0xed6a</span></div>
        <div title="Code: 0xed6b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-7</span><span class="i-code">0xed6b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed6c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-1</span><span class="i-code">0xed6c</span></div>
        <div title="Code: 0xed6d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-5</span><span class="i-code">0xed6d</span></div>
        <div title="Code: 0xed6e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-4</span><span class="i-code">0xed6e</span></div>
        <div title="Code: 0xed6f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-4</span><span class="i-code">0xed6f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed70" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-alert"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-alert</span><span class="i-code">0xed70</span></div>
        <div title="Code: 0xed71" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vcard-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vcard-1</span><span class="i-code">0xed71</span></div>
        <div title="Code: 0xed72" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-address-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-address-1</span><span class="i-code">0xed72</span></div>
        <div title="Code: 0xed73" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-7</span><span class="i-code">0xed73</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed74" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map-1</span><span class="i-code">0xed74</span></div>
        <div title="Code: 0xed75" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-direction-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-direction-1</span><span class="i-code">0xed75</span></div>
        <div title="Code: 0xed76" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-4</span><span class="i-code">0xed76</span></div>
        <div title="Code: 0xed77" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cup-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cup-1</span><span class="i-code">0xed77</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed78" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-7</span><span class="i-code">0xed78</span></div>
        <div title="Code: 0xed79" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-7</span><span class="i-code">0xed79</span></div>
        <div title="Code: 0xed7a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-docs"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-docs</span><span class="i-code">0xed7a</span></div>
        <div title="Code: 0xed7b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-landscape"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-landscape</span><span class="i-code">0xed7b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed7c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-text-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-text-1</span><span class="i-code">0xed7c</span></div>
        <div title="Code: 0xed7d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-text-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-text-inv</span><span class="i-code">0xed7d</span></div>
        <div title="Code: 0xed7e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-newspaper-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-newspaper-1</span><span class="i-code">0xed7e</span></div>
        <div title="Code: 0xed7f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-open-1</span><span class="i-code">0xed7f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed80" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-3</span><span class="i-code">0xed80</span></div>
        <div title="Code: 0xed81" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-6</span><span class="i-code">0xed81</span></div>
        <div title="Code: 0xed82" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-keyboard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-keyboard</span><span class="i-code">0xed82</span></div>
        <div title="Code: 0xed83" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-retweet-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-retweet-3</span><span class="i-code">0xed83</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed84" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-5</span><span class="i-code">0xed84</span></div>
        <div title="Code: 0xed85" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-feather-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-feather-1</span><span class="i-code">0xed85</span></div>
        <div title="Code: 0xed86" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-6</span><span class="i-code">0xed86</span></div>
        <div title="Code: 0xed87" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-4</span><span class="i-code">0xed87</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed88" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-code-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-code-2</span><span class="i-code">0xed88</span></div>
        <div title="Code: 0xed89" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-1</span><span class="i-code">0xed89</span></div>
        <div title="Code: 0xed8a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-3</span><span class="i-code">0xed8a</span></div>
        <div title="Code: 0xed8b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-all-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-all-1</span><span class="i-code">0xed8b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed8c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-3</span><span class="i-code">0xed8c</span></div>
        <div title="Code: 0xed8d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud-3</span><span class="i-code">0xed8d</span></div>
        <div title="Code: 0xed8e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-4</span><span class="i-code">0xed8e</span></div>
        <div title="Code: 0xed8f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-5</span><span class="i-code">0xed8f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed90" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down-3</span><span class="i-code">0xed90</span></div>
        <div title="Code: 0xed91" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-4</span><span class="i-code">0xed91</span></div>
        <div title="Code: 0xed92" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-2</span><span class="i-code">0xed92</span></div>
        <div title="Code: 0xed93" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmarks"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmarks</span><span class="i-code">0xed93</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed94" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark-2</span><span class="i-code">0xed94</span></div>
        <div title="Code: 0xed95" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled-3</span><span class="i-code">0xed95</span></div>
        <div title="Code: 0xed96" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-squared</span><span class="i-code">0xed96</span></div>
        <div title="Code: 0xed97" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-5</span><span class="i-code">0xed97</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed98" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-circled-1</span><span class="i-code">0xed98</span></div>
        <div title="Code: 0xed99" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-squared</span><span class="i-code">0xed99</span></div>
        <div title="Code: 0xed9a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-3</span><span class="i-code">0xed9a</span></div>
        <div title="Code: 0xed9b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-circled-1</span><span class="i-code">0xed9b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xed9c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-squared</span><span class="i-code">0xed9c</span></div>
        <div title="Code: 0xed9d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-2</span><span class="i-code">0xed9d</span></div>
        <div title="Code: 0xed9e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-circled-2</span><span class="i-code">0xed9e</span></div>
        <div title="Code: 0xed9f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-3</span><span class="i-code">0xed9f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeda0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-circled-2</span><span class="i-code">0xeda0</span></div>
        <div title="Code: 0xeda1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-back"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-back</span><span class="i-code">0xeda1</span></div>
        <div title="Code: 0xeda2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-5</span><span class="i-code">0xeda2</span></div>
        <div title="Code: 0xeda3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-4</span><span class="i-code">0xeda3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeda4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-6</span><span class="i-code">0xeda4</span></div>
        <div title="Code: 0xeda5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-7</span><span class="i-code">0xeda5</span></div>
        <div title="Code: 0xeda6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-6</span><span class="i-code">0xeda6</span></div>
        <div title="Code: 0xeda7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-6</span><span class="i-code">0xeda7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeda8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-6</span><span class="i-code">0xeda8</span></div>
        <div title="Code: 0xeda9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-6</span><span class="i-code">0xeda9</span></div>
        <div title="Code: 0xedaa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-2</span><span class="i-code">0xedaa</span></div>
        <div title="Code: 0xedab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-menu-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-menu-2</span><span class="i-code">0xedab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-layout"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-layout</span><span class="i-code">0xedac</span></div>
        <div title="Code: 0xedad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-6</span><span class="i-code">0xedad</span></div>
        <div title="Code: 0xedae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-4</span><span class="i-code">0xedae</span></div>
        <div title="Code: 0xedaf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-4</span><span class="i-code">0xedaf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedb0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-add-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-add-1</span><span class="i-code">0xedb0</span></div>
        <div title="Code: 0xedb1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-users-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-users-2</span><span class="i-code">0xedb1</span></div>
        <div title="Code: 0xedb2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-7</span><span class="i-code">0xedb2</span></div>
        <div title="Code: 0xedb3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-empty-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-empty-2</span><span class="i-code">0xedb3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedb4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-7</span><span class="i-code">0xedb4</span></div>
        <div title="Code: 0xedb5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-empty-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-empty-3</span><span class="i-code">0xedb5</span></div>
        <div title="Code: 0xedb6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-7</span><span class="i-code">0xedb6</span></div>
        <div title="Code: 0xedb7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-7</span><span class="i-code">0xedb7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedb8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flashlight"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flashlight</span><span class="i-code">0xedb8</span></div>
        <div title="Code: 0xedb9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-7</span><span class="i-code">0xedb9</span></div>
        <div title="Code: 0xedba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music-3</span><span class="i-code">0xedba</span></div>
        <div title="Code: 0xedbb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-note-beamed"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-note-beamed</span><span class="i-code">0xedbb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedbc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-note-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-note-1</span><span class="i-code">0xedbc</span></div>
        <div title="Code: 0xedbd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-squared</span><span class="i-code">0xedbd</span></div>
        <div title="Code: 0xedbe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lemon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lemon</span><span class="i-code">0xedbe</span></div>
        <div title="Code: 0xedbf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-squared</span><span class="i-code">0xedbf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedc0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-squared</span><span class="i-code">0xedc0</span></div>
        <div title="Code: 0xedc1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-squared-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-squared-1</span><span class="i-code">0xedc1</span></div>
        <div title="Code: 0xedc2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hammer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hammer</span><span class="i-code">0xedc2</span></div>
        <div title="Code: 0xedc3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card-4</span><span class="i-code">0xedc3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedc4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-floppy-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-floppy-1</span><span class="i-code">0xedc4</span></div>
        <div title="Code: 0xedc5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-megaphone-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-megaphone-3</span><span class="i-code">0xedc5</span></div>
        <div title="Code: 0xedc6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-key-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-key-5</span><span class="i-code">0xedc6</span></div>
        <div title="Code: 0xedc7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-truck-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-truck-1</span><span class="i-code">0xedc7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedc8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar-5</span><span class="i-code">0xedc8</span></div>
        <div title="Code: 0xedc9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-magnet-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-magnet-2</span><span class="i-code">0xedc9</span></div>
        <div title="Code: 0xedca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fire-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fire-3</span><span class="i-code">0xedca</span></div>
        <div title="Code: 0xedcb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gift-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gift-2</span><span class="i-code">0xedcb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedcc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-asterisk-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-asterisk-1</span><span class="i-code">0xedcc</span></div>
        <div title="Code: 0xedcd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-3</span><span class="i-code">0xedcd</span></div>
        <div title="Code: 0xedce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tint-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tint-1</span><span class="i-code">0xedce</span></div>
        <div title="Code: 0xedcf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-adjust-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-adjust-2</span><span class="i-code">0xedcf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedd0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-book-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-book-4</span><span class="i-code">0xedd0</span></div>
        <div title="Code: 0xedd1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-scissors-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-scissors-1</span><span class="i-code">0xedd1</span></div>
        <div title="Code: 0xedd2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-briefcase-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-briefcase-3</span><span class="i-code">0xedd2</span></div>
        <div title="Code: 0xedd3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-off-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-off-1</span><span class="i-code">0xedd3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedd4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-road-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-road-1</span><span class="i-code">0xedd4</span></div>
        <div title="Code: 0xedd5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-alt</span><span class="i-code">0xedd5</span></div>
        <div title="Code: 0xedd6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-qrcode-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-qrcode-1</span><span class="i-code">0xedd6</span></div>
        <div title="Code: 0xedd7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-barcode-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-barcode-1</span><span class="i-code">0xedd7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedd8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-right-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-right-2</span><span class="i-code">0xedd8</span></div>
        <div title="Code: 0xedd9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-indent-left-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-indent-left-2</span><span class="i-code">0xedd9</span></div>
        <div title="Code: 0xedda" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-4</span><span class="i-code">0xedda</span></div>
        <div title="Code: 0xeddb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-justify-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-justify-1</span><span class="i-code">0xeddb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xeddc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-right-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-right-1</span><span class="i-code">0xeddc</span></div>
        <div title="Code: 0xeddd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-center-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-center-1</span><span class="i-code">0xeddd</span></div>
        <div title="Code: 0xedde" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-align-left-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-align-left-1</span><span class="i-code">0xedde</span></div>
        <div title="Code: 0xeddf" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-text-width-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-text-width-1</span><span class="i-code">0xeddf</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xede0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-text-height-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-text-height-1</span><span class="i-code">0xede0</span></div>
        <div title="Code: 0xede1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-italic-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-italic-1</span><span class="i-code">0xede1</span></div>
        <div title="Code: 0xede2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bold-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bold-1</span><span class="i-code">0xede2</span></div>
        <div title="Code: 0xede3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-font-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-font-2</span><span class="i-code">0xede3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xede4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-leaf-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-leaf-3</span><span class="i-code">0xede4</span></div>
        <div title="Code: 0xede5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-start-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-start-alt</span><span class="i-code">0xede5</span></div>
        <div title="Code: 0xede6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-fw-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-fw-1</span><span class="i-code">0xede6</span></div>
        <div title="Code: 0xede7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-bw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-bw</span><span class="i-code">0xede7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xede8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eject-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eject-3</span><span class="i-code">0xede8</span></div>
        <div title="Code: 0xede9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-target-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-target-5</span><span class="i-code">0xede9</span></div>
        <div title="Code: 0xedea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-signal-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-signal-5</span><span class="i-code">0xedea</span></div>
        <div title="Code: 0xedeb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-award-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-award-2</span><span class="i-code">0xedeb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-4</span><span class="i-code">0xedec</span></div>
        <div title="Code: 0xeded" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-6</span><span class="i-code">0xeded</span></div>
        <div title="Code: 0xedee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cloud-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cloud-8</span><span class="i-code">0xedee</span></div>
        <div title="Code: 0xedef" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flash-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flash-4</span><span class="i-code">0xedef</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedf0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-umbrella-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-umbrella-1</span><span class="i-code">0xedf0</span></div>
        <div title="Code: 0xedf1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flight-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flight-2</span><span class="i-code">0xedf1</span></div>
        <div title="Code: 0xedf2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-start-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-start-3</span><span class="i-code">0xedf2</span></div>
        <div title="Code: 0xedf3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-end-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-end-alt</span><span class="i-code">0xedf3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedf4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-end-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-end-3</span><span class="i-code">0xedf4</span></div>
        <div title="Code: 0xedf5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-5</span><span class="i-code">0xedf5</span></div>
        <div title="Code: 0xedf6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-6</span><span class="i-code">0xedf6</span></div>
        <div title="Code: 0xedf7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-circled2-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-circled2-1</span><span class="i-code">0xedf7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedf8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-5</span><span class="i-code">0xedf8</span></div>
        <div title="Code: 0xedf9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shuffle-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shuffle-4</span><span class="i-code">0xedf9</span></div>
        <div title="Code: 0xedfa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-arrows-cw-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-arrows-cw-3</span><span class="i-code">0xedfa</span></div>
        <div title="Code: 0xedfb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ccw-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ccw-2</span><span class="i-code">0xedfb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xedfc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cw-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cw-5</span><span class="i-code">0xedfc</span></div>
        <div title="Code: 0xedfd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-big</span><span class="i-code">0xedfd</span></div>
        <div title="Code: 0xedfe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-big</span><span class="i-code">0xedfe</span></div>
        <div title="Code: 0xedff" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-big</span><span class="i-code">0xedff</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee00" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-big"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-big</span><span class="i-code">0xee00</span></div>
        <div title="Code: 0xee01" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-hand-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-hand-1</span><span class="i-code">0xee01</span></div>
        <div title="Code: 0xee02" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-hand-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-hand-1</span><span class="i-code">0xee02</span></div>
        <div title="Code: 0xee03" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-hand-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-hand-1</span><span class="i-code">0xee03</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee04" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-hand-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-hand-1</span><span class="i-code">0xee04</span></div>
        <div title="Code: 0xee05" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open-3</span><span class="i-code">0xee05</span></div>
        <div title="Code: 0xee06" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-5</span><span class="i-code">0xee06</span></div>
        <div title="Code: 0xee07" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-5</span><span class="i-code">0xee07</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee08" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open-3</span><span class="i-code">0xee08</span></div>
        <div title="Code: 0xee09" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-dir-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-dir-3</span><span class="i-code">0xee09</span></div>
        <div title="Code: 0xee0a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-dir-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-dir-2</span><span class="i-code">0xee0a</span></div>
        <div title="Code: 0xee0b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-dir-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-dir-2</span><span class="i-code">0xee0b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee0c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-dir-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-dir-3</span><span class="i-code">0xee0c</span></div>
        <div title="Code: 0xee0d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circled2</span><span class="i-code">0xee0d</span></div>
        <div title="Code: 0xee0e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circled2</span><span class="i-code">0xee0e</span></div>
        <div title="Code: 0xee0f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-login-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-login-3</span><span class="i-code">0xee0f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee10" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-logout-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-logout-3</span><span class="i-code">0xee10</span></div>
        <div title="Code: 0xee11" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-off-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-off-4</span><span class="i-code">0xee11</span></div>
        <div title="Code: 0xee12" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-down-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-down-2</span><span class="i-code">0xee12</span></div>
        <div title="Code: 0xee13" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-up-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-up-3</span><span class="i-code">0xee13</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee14" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-headphones-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-headphones-3</span><span class="i-code">0xee14</span></div>
        <div title="Code: 0xee15" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clock-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clock-8</span><span class="i-code">0xee15</span></div>
        <div title="Code: 0xee16" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-block-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-block-5</span><span class="i-code">0xee16</span></div>
        <div title="Code: 0xee17" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-6</span><span class="i-code">0xee17</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee18" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-small-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-small-4</span><span class="i-code">0xee18</span></div>
        <div title="Code: 0xee19" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-vertical-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-vertical-2</span><span class="i-code">0xee19</span></div>
        <div title="Code: 0xee1a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-horizontal-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-horizontal-2</span><span class="i-code">0xee1a</span></div>
        <div title="Code: 0xee1b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-move-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-move-3</span><span class="i-code">0xee1b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee1c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in-4</span><span class="i-code">0xee1c</span></div>
        <div title="Code: 0xee1d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out-4</span><span class="i-code">0xee1d</span></div>
        <div title="Code: 0xee1e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-8</span><span class="i-code">0xee1e</span></div>
        <div title="Code: 0xee1f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-basket-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-basket-4</span><span class="i-code">0xee1f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee20" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wrench-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wrench-4</span><span class="i-code">0xee20</span></div>
        <div title="Code: 0xee21" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-alt</span><span class="i-code">0xee21</span></div>
        <div title="Code: 0xee22" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cog-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cog-7</span><span class="i-code">0xee22</span></div>
        <div title="Code: 0xee23" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-3</span><span class="i-code">0xee23</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee24" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-open-2</span><span class="i-code">0xee24</span></div>
        <div title="Code: 0xee25" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-6</span><span class="i-code">0xee25</span></div>
        <div title="Code: 0xee26" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-5</span><span class="i-code">0xee26</span></div>
        <div title="Code: 0xee27" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-circled</span><span class="i-code">0xee27</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee28" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-8</span><span class="i-code">0xee28</span></div>
        <div title="Code: 0xee29" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-empty-1</span><span class="i-code">0xee29</span></div>
        <div title="Code: 0xee2a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-8</span><span class="i-code">0xee2a</span></div>
        <div title="Code: 0xee2b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-5</span><span class="i-code">0xee2b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee2c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-6</span><span class="i-code">0xee2c</span></div>
        <div title="Code: 0xee2d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-7</span><span class="i-code">0xee2d</span></div>
        <div title="Code: 0xee2e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-retweet-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-retweet-4</span><span class="i-code">0xee2e</span></div>
        <div title="Code: 0xee2f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-6</span><span class="i-code">0xee2f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee30" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edit-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edit-3</span><span class="i-code">0xee30</span></div>
        <div title="Code: 0xee31" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-7</span><span class="i-code">0xee31</span></div>
        <div title="Code: 0xee32" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-5</span><span class="i-code">0xee32</span></div>
        <div title="Code: 0xee33" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tags-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tags-2</span><span class="i-code">0xee33</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee34" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark-3</span><span class="i-code">0xee34</span></div>
        <div title="Code: 0xee35" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-3</span><span class="i-code">0xee35</span></div>
        <div title="Code: 0xee36" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-5</span><span class="i-code">0xee36</span></div>
        <div title="Code: 0xee37" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down-4</span><span class="i-code">0xee37</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee38" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-6</span><span class="i-code">0xee38</span></div>
        <div title="Code: 0xee39" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-5</span><span class="i-code">0xee39</span></div>
        <div title="Code: 0xee3a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forward-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forward-4</span><span class="i-code">0xee3a</span></div>
        <div title="Code: 0xee3b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tag-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tag-7</span><span class="i-code">0xee3b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee3c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-off-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-off-1</span><span class="i-code">0xee3c</span></div>
        <div title="Code: 0xee3d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-7</span><span class="i-code">0xee3d</span></div>
        <div title="Code: 0xee3e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pin-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pin-2</span><span class="i-code">0xee3e</span></div>
        <div title="Code: 0xee3f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-7</span><span class="i-code">0xee3f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee40" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-8</span><span class="i-code">0xee40</span></div>
        <div title="Code: 0xee41" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-7</span><span class="i-code">0xee41</span></div>
        <div title="Code: 0xee42" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-5</span><span class="i-code">0xee42</span></div>
        <div title="Code: 0xee43" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-home-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-home-6</span><span class="i-code">0xee43</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee44" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-circled-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-circled-3</span><span class="i-code">0xee44</span></div>
        <div title="Code: 0xee45" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-circled-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-circled-3</span><span class="i-code">0xee45</span></div>
        <div title="Code: 0xee46" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-circled-2</span><span class="i-code">0xee46</span></div>
        <div title="Code: 0xee47" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-video-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-video-5</span><span class="i-code">0xee47</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee48" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-5</span><span class="i-code">0xee48</span></div>
        <div title="Code: 0xee49" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picture-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picture-5</span><span class="i-code">0xee49</span></div>
        <div title="Code: 0xee4a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-7</span><span class="i-code">0xee4a</span></div>
        <div title="Code: 0xee4b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-alt</span><span class="i-code">0xee4b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee4c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-large-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-large-3</span><span class="i-code">0xee4c</span></div>
        <div title="Code: 0xee4d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-4</span><span class="i-code">0xee4d</span></div>
        <div title="Code: 0xee4e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-5</span><span class="i-code">0xee4e</span></div>
        <div title="Code: 0xee4f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-6</span><span class="i-code">0xee4f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee50" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circled-2</span><span class="i-code">0xee50</span></div>
        <div title="Code: 0xee51" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circled2-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circled2-1</span><span class="i-code">0xee51</span></div>
        <div title="Code: 0xee52" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-7</span><span class="i-code">0xee52</span></div>
        <div title="Code: 0xee53" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled-4</span><span class="i-code">0xee53</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee54" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled2-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled2-1</span><span class="i-code">0xee54</span></div>
        <div title="Code: 0xee55" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-6</span><span class="i-code">0xee55</span></div>
        <div title="Code: 0xee56" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-circled-2</span><span class="i-code">0xee56</span></div>
        <div title="Code: 0xee57" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-4</span><span class="i-code">0xee57</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee58" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-users-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-users-3</span><span class="i-code">0xee58</span></div>
        <div title="Code: 0xee59" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-8</span><span class="i-code">0xee59</span></div>
        <div title="Code: 0xee5a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-half-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-half-1</span><span class="i-code">0xee5a</span></div>
        <div title="Code: 0xee5b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-empty-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-empty-3</span><span class="i-code">0xee5b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee5c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-8</span><span class="i-code">0xee5c</span></div>
        <div title="Code: 0xee5d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-empty-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-empty-4</span><span class="i-code">0xee5d</span></div>
        <div title="Code: 0xee5e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-8</span><span class="i-code">0xee5e</span></div>
        <div title="Code: 0xee5f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-8</span><span class="i-code">0xee5f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee60" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-8</span><span class="i-code">0xee60</span></div>
        <div title="Code: 0xee61" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-music-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-music-4</span><span class="i-code">0xee61</span></div>
        <div title="Code: 0xee62" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-glass-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-glass-1</span><span class="i-code">0xee62</span></div>
        <div title="Code: 0xee63" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin1 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin1</span><span class="i-code">0xee63</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee64" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin2 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin2</span><span class="i-code">0xee64</span></div>
        <div title="Code: 0xee65" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin4 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin4</span><span class="i-code">0xee65</span></div>
        <div title="Code: 0xee66" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin5 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin5</span><span class="i-code">0xee66</span></div>
        <div title="Code: 0xee67" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin3 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin3</span><span class="i-code">0xee67</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee68" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spin6 animate-spin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spin6</span><span class="i-code">0xee68</span></div>
        <div title="Code: 0xee69" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-firefox-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-firefox-1</span><span class="i-code">0xee69</span></div>
        <div title="Code: 0xee6a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chrome-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chrome-2</span><span class="i-code">0xee6a</span></div>
        <div title="Code: 0xee6b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-opera-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-opera-1</span><span class="i-code">0xee6b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee6c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ie-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ie-1</span><span class="i-code">0xee6c</span></div>
        <div title="Code: 0xee6d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-crown"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-crown</span><span class="i-code">0xee6d</span></div>
        <div title="Code: 0xee6e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-crown-plus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-crown-plus</span><span class="i-code">0xee6e</span></div>
        <div title="Code: 0xee6f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-crown-minus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-crown-minus</span><span class="i-code">0xee6f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee70" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-marquee"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-marquee</span><span class="i-code">0xee70</span></div>
        <div title="Code: 0xee71" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-happy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-happy</span><span class="i-code">0xee71</span></div>
        <div title="Code: 0xee72" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-wink"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-wink</span><span class="i-code">0xee72</span></div>
        <div title="Code: 0xee73" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-wink2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-wink2</span><span class="i-code">0xee73</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee74" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-unhappy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-unhappy</span><span class="i-code">0xee74</span></div>
        <div title="Code: 0xee75" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-sleep"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-sleep</span><span class="i-code">0xee75</span></div>
        <div title="Code: 0xee76" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-thumbsup"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-thumbsup</span><span class="i-code">0xee76</span></div>
        <div title="Code: 0xee77" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-devil"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-devil</span><span class="i-code">0xee77</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee78" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-surprised"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-surprised</span><span class="i-code">0xee78</span></div>
        <div title="Code: 0xee79" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-tongue"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-tongue</span><span class="i-code">0xee79</span></div>
        <div title="Code: 0xee7a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-coffee"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-coffee</span><span class="i-code">0xee7a</span></div>
        <div title="Code: 0xee7b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-sunglasses"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-sunglasses</span><span class="i-code">0xee7b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee7c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-displeased"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-displeased</span><span class="i-code">0xee7c</span></div>
        <div title="Code: 0xee7d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-beer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-beer</span><span class="i-code">0xee7d</span></div>
        <div title="Code: 0xee7e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-grin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-grin</span><span class="i-code">0xee7e</span></div>
        <div title="Code: 0xee7f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-angry"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-angry</span><span class="i-code">0xee7f</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee80" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-saint"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-saint</span><span class="i-code">0xee80</span></div>
        <div title="Code: 0xee81" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-cry"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-cry</span><span class="i-code">0xee81</span></div>
        <div title="Code: 0xee82" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-shoot"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-shoot</span><span class="i-code">0xee82</span></div>
        <div title="Code: 0xee83" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-squint"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-squint</span><span class="i-code">0xee83</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xee84" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-emo-laugh"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-emo-laugh</span><span class="i-code">0xee84</span></div>
        <div title="Code: 0xf004" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-open-1</span><span class="i-code">0xf004</span></div>
        <div title="Code: 0xf005" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-open-1</span><span class="i-code">0xf005</span></div>
        <div title="Code: 0xf006" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-open-2</span><span class="i-code">0xf006</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf007" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-open-2</span><span class="i-code">0xf007</span></div>
        <div title="Code: 0xf008" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-menu"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-menu</span><span class="i-code">0xf008</span></div>
        <div title="Code: 0xf009" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-list-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-list-2</span><span class="i-code">0xf009</span></div>
        <div title="Code: 0xf00a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-thumb"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-thumb</span><span class="i-code">0xf00a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf00b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-th-thumb-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-th-thumb-empty</span><span class="i-code">0xf00b</span></div>
        <div title="Code: 0xf00c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-coverflow"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-coverflow</span><span class="i-code">0xf00c</span></div>
        <div title="Code: 0xf00d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-coverflow-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-coverflow-empty</span><span class="i-code">0xf00d</span></div>
        <div title="Code: 0xf00e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-1</span><span class="i-code">0xf00e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf00f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-1</span><span class="i-code">0xf00f</span></div>
        <div title="Code: 0xf010" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-end"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-end</span><span class="i-code">0xf010</span></div>
        <div title="Code: 0xf011" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-to-start"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-to-start</span><span class="i-code">0xf011</span></div>
        <div title="Code: 0xf012" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-forward-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-forward-1</span><span class="i-code">0xf012</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf013" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fast-backward-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fast-backward-1</span><span class="i-code">0xf013</span></div>
        <div title="Code: 0xf014" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud</span><span class="i-code">0xf014</span></div>
        <div title="Code: 0xf015" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-cloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-cloud</span><span class="i-code">0xf015</span></div>
        <div title="Code: 0xf016" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-data-science"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-data-science</span><span class="i-code">0xf016</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf017" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-data-science-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-data-science-inv</span><span class="i-code">0xf017</span></div>
        <div title="Code: 0xf018" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-2</span><span class="i-code">0xf018</span></div>
        <div title="Code: 0xf019" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-globe-inv"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-globe-inv</span><span class="i-code">0xf019</span></div>
        <div title="Code: 0xf01a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-math"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-math</span><span class="i-code">0xf01a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf01b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-math-circled-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-math-circled-empty</span><span class="i-code">0xf01b</span></div>
        <div title="Code: 0xf01c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-math-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-math-circled</span><span class="i-code">0xf01c</span></div>
        <div title="Code: 0xf01d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-1</span><span class="i-code">0xf01d</span></div>
        <div title="Code: 0xf01e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-alt2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-alt2</span><span class="i-code">0xf01e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf01f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-alt</span><span class="i-code">0xf01f</span></div>
        <div title="Code: 0xf020" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-color-adjust"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-color-adjust</span><span class="i-code">0xf020</span></div>
        <div title="Code: 0xf022" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-half"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-half</span><span class="i-code">0xf022</span></div>
        <div title="Code: 0xf024" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-half_empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-half_empty</span><span class="i-code">0xf024</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf025" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ccw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ccw</span><span class="i-code">0xf025</span></div>
        <div title="Code: 0xf028" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heart-broken"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heart-broken</span><span class="i-code">0xf028</span></div>
        <div title="Code: 0xf029" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hash"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hash</span><span class="i-code">0xf029</span></div>
        <div title="Code: 0xf02a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-1</span><span class="i-code">0xf02a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf02b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-retweet-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-retweet-2</span><span class="i-code">0xf02b</span></div>
        <div title="Code: 0xf02c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-login-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-login-1</span><span class="i-code">0xf02c</span></div>
        <div title="Code: 0xf02d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-logout-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-logout-1</span><span class="i-code">0xf02d</span></div>
        <div title="Code: 0xf02e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-1</span><span class="i-code">0xf02e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf02f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-1</span><span class="i-code">0xf02f</span></div>
        <div title="Code: 0xf031" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-location-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-location-3</span><span class="i-code">0xf031</span></div>
        <div title="Code: 0xf032" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-monitor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-monitor</span><span class="i-code">0xf032</span></div>
        <div title="Code: 0xf033" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tablet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tablet</span><span class="i-code">0xf033</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf034" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-1</span><span class="i-code">0xf034</span></div>
        <div title="Code: 0xf035" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-connected-object"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-connected-object</span><span class="i-code">0xf035</span></div>
        <div title="Code: 0xf039" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-isight"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-isight</span><span class="i-code">0xf039</span></div>
        <div title="Code: 0xf03a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-videocam-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-videocam-2</span><span class="i-code">0xf03a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf03b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shuffle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shuffle-1</span><span class="i-code">0xf03b</span></div>
        <div title="Code: 0xf03d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-1</span><span class="i-code">0xf03d</span></div>
        <div title="Code: 0xf03f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-1</span><span class="i-code">0xf03f</span></div>
        <div title="Code: 0xf040" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-movie"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-movie</span><span class="i-code">0xf040</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf044" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ruler"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ruler</span><span class="i-code">0xf044</span></div>
        <div title="Code: 0xf045" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vector"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vector</span><span class="i-code">0xf045</span></div>
        <div title="Code: 0xf047" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-off</span><span class="i-code">0xf047</span></div>
        <div title="Code: 0xf048" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-1</span><span class="i-code">0xf048</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf04a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-3</span><span class="i-code">0xf04a</span></div>
        <div title="Code: 0xf04f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-circled</span><span class="i-code">0xf04f</span></div>
        <div title="Code: 0xf050" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-2</span><span class="i-code">0xf050</span></div>
        <div title="Code: 0xf051" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-circled</span><span class="i-code">0xf051</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf052" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-3</span><span class="i-code">0xf052</span></div>
        <div title="Code: 0xf053" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-alt</span><span class="i-code">0xf053</span></div>
        <div title="Code: 0xf054" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-1</span><span class="i-code">0xf054</span></div>
        <div title="Code: 0xf055" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-3</span><span class="i-code">0xf055</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf056" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-alt2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-alt2</span><span class="i-code">0xf056</span></div>
        <div title="Code: 0xf057" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-circled</span><span class="i-code">0xf057</span></div>
        <div title="Code: 0xf058" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-3</span><span class="i-code">0xf058</span></div>
        <div title="Code: 0xf059" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-circled</span><span class="i-code">0xf059</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf05a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-1</span><span class="i-code">0xf05a</span></div>
        <div title="Code: 0xf05b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-circled</span><span class="i-code">0xf05b</span></div>
        <div title="Code: 0xf05c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-3</span><span class="i-code">0xf05c</span></div>
        <div title="Code: 0xf05d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-3</span><span class="i-code">0xf05d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf05e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-circled</span><span class="i-code">0xf05e</span></div>
        <div title="Code: 0xf05f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mfg-logo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mfg-logo</span><span class="i-code">0xf05f</span></div>
        <div title="Code: 0xf060" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mfg-logo-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mfg-logo-circled</span><span class="i-code">0xf060</span></div>
        <div title="Code: 0xf061" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-3</span><span class="i-code">0xf061</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf062" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-male"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-male</span><span class="i-code">0xf062</span></div>
        <div title="Code: 0xf063" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-female"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-female</span><span class="i-code">0xf063</span></div>
        <div title="Code: 0xf064" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-users"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-users</span><span class="i-code">0xf064</span></div>
        <div title="Code: 0xf067" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-2</span><span class="i-code">0xf067</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf068" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-open-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-open-1</span><span class="i-code">0xf068</span></div>
        <div title="Code: 0xf069" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-empty</span><span class="i-code">0xf069</span></div>
        <div title="Code: 0xf06a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attach-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attach-3</span><span class="i-code">0xf06a</span></div>
        <div title="Code: 0xf06d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-circled-1</span><span class="i-code">0xf06d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf06e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cancel-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cancel-circled-1</span><span class="i-code">0xf06e</span></div>
        <div title="Code: 0xf070" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-inbox-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-inbox-2</span><span class="i-code">0xf070</span></div>
        <div title="Code: 0xf074" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trophy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trophy</span><span class="i-code">0xf074</span></div>
        <div title="Code: 0xf075" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-alt-1</span><span class="i-code">0xf075</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf07b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-1</span><span class="i-code">0xf07b</span></div>
        <div title="Code: 0xf07e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-in-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-in-1</span><span class="i-code">0xf07e</span></div>
        <div title="Code: 0xf07f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-zoom-out-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-zoom-out-1</span><span class="i-code">0xf07f</span></div>
        <div title="Code: 0xf080" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-1</span><span class="i-code">0xf080</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf081" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-1</span><span class="i-code">0xf081</span></div>
        <div title="Code: 0xf082" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eye-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eye-2</span><span class="i-code">0xf082</span></div>
        <div title="Code: 0xf083" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-3</span><span class="i-code">0xf083</span></div>
        <div title="Code: 0xf084" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hdd-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hdd-1</span><span class="i-code">0xf084</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf085" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-circled-1</span><span class="i-code">0xf085</span></div>
        <div title="Code: 0xf086" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-circled-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-circled-alt</span><span class="i-code">0xf086</span></div>
        <div title="Code: 0xf087" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-print-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-print-2</span><span class="i-code">0xf087</span></div>
        <div title="Code: 0xf088" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fontsize-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fontsize-1</span><span class="i-code">0xf088</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf089" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soundcloud-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soundcloud-1</span><span class="i-code">0xf089</span></div>
        <div title="Code: 0xf08a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soundcloud-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soundcloud-circled</span><span class="i-code">0xf08a</span></div>
        <div title="Code: 0xf08e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-ext"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-ext</span><span class="i-code">0xf08e</span></div>
        <div title="Code: 0xf096" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-check-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-check-empty-1</span><span class="i-code">0xf096</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf097" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bookmark-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bookmark-empty-1</span><span class="i-code">0xf097</span></div>
        <div title="Code: 0xf098" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-phone-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-phone-squared</span><span class="i-code">0xf098</span></div>
        <div title="Code: 0xf099" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-7</span><span class="i-code">0xf099</span></div>
        <div title="Code: 0xf09a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-7</span><span class="i-code">0xf09a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf09b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-circled-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-circled-4</span><span class="i-code">0xf09b</span></div>
        <div title="Code: 0xf09e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-7"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-7</span><span class="i-code">0xf09e</span></div>
        <div title="Code: 0xf0a0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hdd-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hdd-2</span><span class="i-code">0xf0a0</span></div>
        <div title="Code: 0xf0a3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-certificate-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-certificate-2</span><span class="i-code">0xf0a3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0a8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circled-2</span><span class="i-code">0xf0a8</span></div>
        <div title="Code: 0xf0a9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circled-2</span><span class="i-code">0xf0a9</span></div>
        <div title="Code: 0xf0aa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-circled-2</span><span class="i-code">0xf0aa</span></div>
        <div title="Code: 0xf0ab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-circled-2</span><span class="i-code">0xf0ab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0ae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tasks-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tasks-1</span><span class="i-code">0xf0ae</span></div>
        <div title="Code: 0xf0b0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-filter-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-filter-1</span><span class="i-code">0xf0b0</span></div>
        <div title="Code: 0xf0b2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-resize-full-alt-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-resize-full-alt-2</span><span class="i-code">0xf0b2</span></div>
        <div title="Code: 0xf0c3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-beaker-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-beaker-1</span><span class="i-code">0xf0c3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0c5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-docs-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-docs-1</span><span class="i-code">0xf0c5</span></div>
        <div title="Code: 0xf0c8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blank"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blank</span><span class="i-code">0xf0c8</span></div>
        <div title="Code: 0xf0c9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-menu-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-menu-3</span><span class="i-code">0xf0c9</span></div>
        <div title="Code: 0xf0ca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-bullet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-bullet</span><span class="i-code">0xf0ca</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0cb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-list-numbered-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-list-numbered-1</span><span class="i-code">0xf0cb</span></div>
        <div title="Code: 0xf0cc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-strike"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-strike</span><span class="i-code">0xf0cc</span></div>
        <div title="Code: 0xf0cd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-underline"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-underline</span><span class="i-code">0xf0cd</span></div>
        <div title="Code: 0xf0ce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-table"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-table</span><span class="i-code">0xf0ce</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0d0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-magic"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-magic</span><span class="i-code">0xf0d0</span></div>
        <div title="Code: 0xf0d2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-circled-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-circled-2</span><span class="i-code">0xf0d2</span></div>
        <div title="Code: 0xf0d3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-squared</span><span class="i-code">0xf0d3</span></div>
        <div title="Code: 0xf0d4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-squared</span><span class="i-code">0xf0d4</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0d5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gplus-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gplus-3</span><span class="i-code">0xf0d5</span></div>
        <div title="Code: 0xf0d6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-money-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-money-2</span><span class="i-code">0xf0d6</span></div>
        <div title="Code: 0xf0db" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-columns"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-columns</span><span class="i-code">0xf0db</span></div>
        <div title="Code: 0xf0dc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort</span><span class="i-code">0xf0dc</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0dd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-down</span><span class="i-code">0xf0dd</span></div>
        <div title="Code: 0xf0de" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-up</span><span class="i-code">0xf0de</span></div>
        <div title="Code: 0xf0e0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-alt</span><span class="i-code">0xf0e0</span></div>
        <div title="Code: 0xf0e1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-6</span><span class="i-code">0xf0e1</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0e4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gauge-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gauge-2</span><span class="i-code">0xf0e4</span></div>
        <div title="Code: 0xf0e5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-empty</span><span class="i-code">0xf0e5</span></div>
        <div title="Code: 0xf0e6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chat-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chat-empty</span><span class="i-code">0xf0e6</span></div>
        <div title="Code: 0xf0e8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sitemap"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sitemap</span><span class="i-code">0xf0e8</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0ea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paste"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paste</span><span class="i-code">0xf0ea</span></div>
        <div title="Code: 0xf0eb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lightbulb-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lightbulb-3</span><span class="i-code">0xf0eb</span></div>
        <div title="Code: 0xf0ec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-exchange-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-exchange-1</span><span class="i-code">0xf0ec</span></div>
        <div title="Code: 0xf0ed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-download-cloud-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-download-cloud-2</span><span class="i-code">0xf0ed</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0ee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-upload-cloud-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-upload-cloud-4</span><span class="i-code">0xf0ee</span></div>
        <div title="Code: 0xf0f0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-md"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-md</span><span class="i-code">0xf0f0</span></div>
        <div title="Code: 0xf0f1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stethoscope"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stethoscope</span><span class="i-code">0xf0f1</span></div>
        <div title="Code: 0xf0f2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-suitcase-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-suitcase-1</span><span class="i-code">0xf0f2</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0f3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-alt</span><span class="i-code">0xf0f3</span></div>
        <div title="Code: 0xf0f4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-coffee-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-coffee-1</span><span class="i-code">0xf0f4</span></div>
        <div title="Code: 0xf0f5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-food-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-food-1</span><span class="i-code">0xf0f5</span></div>
        <div title="Code: 0xf0f6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-text-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-text-2</span><span class="i-code">0xf0f6</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0f7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-building"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-building</span><span class="i-code">0xf0f7</span></div>
        <div title="Code: 0xf0f8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hospital-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hospital-1</span><span class="i-code">0xf0f8</span></div>
        <div title="Code: 0xf0f9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ambulance"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ambulance</span><span class="i-code">0xf0f9</span></div>
        <div title="Code: 0xf0fa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-medkit"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-medkit</span><span class="i-code">0xf0fa</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf0fb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fighter-jet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fighter-jet</span><span class="i-code">0xf0fb</span></div>
        <div title="Code: 0xf0fc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-beer-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-beer-2</span><span class="i-code">0xf0fc</span></div>
        <div title="Code: 0xf0fd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-h-sigh"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-h-sigh</span><span class="i-code">0xf0fd</span></div>
        <div title="Code: 0xf0fe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-squared-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-squared-1</span><span class="i-code">0xf0fe</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf100" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-double-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-double-left</span><span class="i-code">0xf100</span></div>
        <div title="Code: 0xf101" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-double-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-double-right</span><span class="i-code">0xf101</span></div>
        <div title="Code: 0xf102" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-double-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-double-up</span><span class="i-code">0xf102</span></div>
        <div title="Code: 0xf103" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-double-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-double-down</span><span class="i-code">0xf103</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf104" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-left</span><span class="i-code">0xf104</span></div>
        <div title="Code: 0xf105" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-right</span><span class="i-code">0xf105</span></div>
        <div title="Code: 0xf106" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-up</span><span class="i-code">0xf106</span></div>
        <div title="Code: 0xf107" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-down</span><span class="i-code">0xf107</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf108" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-desktop-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-desktop-3</span><span class="i-code">0xf108</span></div>
        <div title="Code: 0xf109" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-laptop-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-laptop-2</span><span class="i-code">0xf109</span></div>
        <div title="Code: 0xf10a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tablet-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tablet-3</span><span class="i-code">0xf10a</span></div>
        <div title="Code: 0xf10b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mobile-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mobile-6</span><span class="i-code">0xf10b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf10c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-circle-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-circle-empty</span><span class="i-code">0xf10c</span></div>
        <div title="Code: 0xf10d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-left-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-left-1</span><span class="i-code">0xf10d</span></div>
        <div title="Code: 0xf10e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-quote-right-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-quote-right-1</span><span class="i-code">0xf10e</span></div>
        <div title="Code: 0xf110" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spinner"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spinner</span><span class="i-code">0xf110</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf111" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-circle</span><span class="i-code">0xf111</span></div>
        <div title="Code: 0xf112" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-4</span><span class="i-code">0xf112</span></div>
        <div title="Code: 0xf113" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-6</span><span class="i-code">0xf113</span></div>
        <div title="Code: 0xf114" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-empty-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-empty-2</span><span class="i-code">0xf114</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf115" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-open-empty-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-open-empty-1</span><span class="i-code">0xf115</span></div>
        <div title="Code: 0xf118" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-smile"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-smile</span><span class="i-code">0xf118</span></div>
        <div title="Code: 0xf119" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-frown"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-frown</span><span class="i-code">0xf119</span></div>
        <div title="Code: 0xf11a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-meh"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-meh</span><span class="i-code">0xf11a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf11b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gamepad"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gamepad</span><span class="i-code">0xf11b</span></div>
        <div title="Code: 0xf11c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-keyboard-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-keyboard-1</span><span class="i-code">0xf11c</span></div>
        <div title="Code: 0xf11d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-empty</span><span class="i-code">0xf11d</span></div>
        <div title="Code: 0xf11e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flag-checkered"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flag-checkered</span><span class="i-code">0xf11e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf120" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-terminal-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-terminal-1</span><span class="i-code">0xf120</span></div>
        <div title="Code: 0xf121" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-code-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-code-3</span><span class="i-code">0xf121</span></div>
        <div title="Code: 0xf122" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reply-all-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reply-all-2</span><span class="i-code">0xf122</span></div>
        <div title="Code: 0xf123" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-star-half-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-star-half-alt</span><span class="i-code">0xf123</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf124" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-direction-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-direction-2</span><span class="i-code">0xf124</span></div>
        <div title="Code: 0xf125" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-crop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-crop</span><span class="i-code">0xf125</span></div>
        <div title="Code: 0xf126" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fork"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fork</span><span class="i-code">0xf126</span></div>
        <div title="Code: 0xf127" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-unlink"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-unlink</span><span class="i-code">0xf127</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf128" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-help-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-help-3</span><span class="i-code">0xf128</span></div>
        <div title="Code: 0xf129" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-info-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-info-4</span><span class="i-code">0xf129</span></div>
        <div title="Code: 0xf12a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-attention-alt-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-attention-alt-1</span><span class="i-code">0xf12a</span></div>
        <div title="Code: 0xf12b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-superscript"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-superscript</span><span class="i-code">0xf12b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf12c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-subscript"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-subscript</span><span class="i-code">0xf12c</span></div>
        <div title="Code: 0xf12d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eraser"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eraser</span><span class="i-code">0xf12d</span></div>
        <div title="Code: 0xf12e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-puzzle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-puzzle-1</span><span class="i-code">0xf12e</span></div>
        <div title="Code: 0xf130" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mic-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mic-5</span><span class="i-code">0xf130</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf131" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mute-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mute-1</span><span class="i-code">0xf131</span></div>
        <div title="Code: 0xf132" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shield"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shield</span><span class="i-code">0xf132</span></div>
        <div title="Code: 0xf133" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-empty</span><span class="i-code">0xf133</span></div>
        <div title="Code: 0xf134" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-extinguisher"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-extinguisher</span><span class="i-code">0xf134</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf135" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rocket-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rocket-1</span><span class="i-code">0xf135</span></div>
        <div title="Code: 0xf136" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-maxcdn"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-maxcdn</span><span class="i-code">0xf136</span></div>
        <div title="Code: 0xf137" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-circled-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-circled-left</span><span class="i-code">0xf137</span></div>
        <div title="Code: 0xf138" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-circled-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-circled-right</span><span class="i-code">0xf138</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf139" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-circled-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-circled-up</span><span class="i-code">0xf139</span></div>
        <div title="Code: 0xf13a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angle-circled-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angle-circled-down</span><span class="i-code">0xf13a</span></div>
        <div title="Code: 0xf13b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-html5-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-html5-1</span><span class="i-code">0xf13b</span></div>
        <div title="Code: 0xf13c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-css3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-css3</span><span class="i-code">0xf13c</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf13d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-anchor-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-anchor-2</span><span class="i-code">0xf13d</span></div>
        <div title="Code: 0xf13e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-alt-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-alt-2</span><span class="i-code">0xf13e</span></div>
        <div title="Code: 0xf140" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bullseye"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bullseye</span><span class="i-code">0xf140</span></div>
        <div title="Code: 0xf141" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ellipsis"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ellipsis</span><span class="i-code">0xf141</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf142" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ellipsis-vert"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ellipsis-vert</span><span class="i-code">0xf142</span></div>
        <div title="Code: 0xf143" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rss-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rss-squared</span><span class="i-code">0xf143</span></div>
        <div title="Code: 0xf144" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-play-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-play-circled-1</span><span class="i-code">0xf144</span></div>
        <div title="Code: 0xf145" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ticket-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ticket-2</span><span class="i-code">0xf145</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf146" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-squared-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-squared-1</span><span class="i-code">0xf146</span></div>
        <div title="Code: 0xf147" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-minus-squared-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-minus-squared-alt</span><span class="i-code">0xf147</span></div>
        <div title="Code: 0xf148" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-level-up-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-level-up-1</span><span class="i-code">0xf148</span></div>
        <div title="Code: 0xf149" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-level-down-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-level-down-1</span><span class="i-code">0xf149</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf14a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ok-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ok-squared</span><span class="i-code">0xf14a</span></div>
        <div title="Code: 0xf14b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pencil-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pencil-squared</span><span class="i-code">0xf14b</span></div>
        <div title="Code: 0xf14c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-link-ext-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-link-ext-alt</span><span class="i-code">0xf14c</span></div>
        <div title="Code: 0xf14d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-export-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-export-alt</span><span class="i-code">0xf14d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf14e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-compass-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-compass-5</span><span class="i-code">0xf14e</span></div>
        <div title="Code: 0xf150" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-expand"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-expand</span><span class="i-code">0xf150</span></div>
        <div title="Code: 0xf151" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-collapse"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-collapse</span><span class="i-code">0xf151</span></div>
        <div title="Code: 0xf152" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-expand-right"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-expand-right</span><span class="i-code">0xf152</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf153" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-euro"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-euro</span><span class="i-code">0xf153</span></div>
        <div title="Code: 0xf154" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pound"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pound</span><span class="i-code">0xf154</span></div>
        <div title="Code: 0xf155" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dollar-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dollar-1</span><span class="i-code">0xf155</span></div>
        <div title="Code: 0xf156" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rupee"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rupee</span><span class="i-code">0xf156</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf157" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yen"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yen</span><span class="i-code">0xf157</span></div>
        <div title="Code: 0xf158" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rouble"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rouble</span><span class="i-code">0xf158</span></div>
        <div title="Code: 0xf159" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-won"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-won</span><span class="i-code">0xf159</span></div>
        <div title="Code: 0xf15a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bitcoin-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bitcoin-1</span><span class="i-code">0xf15a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf15b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-inv-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-inv-1</span><span class="i-code">0xf15b</span></div>
        <div title="Code: 0xf15c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-doc-text-inv-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-doc-text-inv-1</span><span class="i-code">0xf15c</span></div>
        <div title="Code: 0xf15d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-name-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-name-up</span><span class="i-code">0xf15d</span></div>
        <div title="Code: 0xf15e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-name-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-name-down</span><span class="i-code">0xf15e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf160" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-alt-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-alt-up</span><span class="i-code">0xf160</span></div>
        <div title="Code: 0xf161" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-alt-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-alt-down</span><span class="i-code">0xf161</span></div>
        <div title="Code: 0xf162" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-number-up"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-number-up</span><span class="i-code">0xf162</span></div>
        <div title="Code: 0xf163" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sort-number-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sort-number-down</span><span class="i-code">0xf163</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf164" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-up-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-up-alt</span><span class="i-code">0xf164</span></div>
        <div title="Code: 0xf165" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-thumbs-down-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-thumbs-down-alt</span><span class="i-code">0xf165</span></div>
        <div title="Code: 0xf166" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-squared</span><span class="i-code">0xf166</span></div>
        <div title="Code: 0xf167" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-4</span><span class="i-code">0xf167</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf168" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-xing-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-xing-1</span><span class="i-code">0xf168</span></div>
        <div title="Code: 0xf169" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-xing-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-xing-squared</span><span class="i-code">0xf169</span></div>
        <div title="Code: 0xf16a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube-play"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube-play</span><span class="i-code">0xf16a</span></div>
        <div title="Code: 0xf16b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dropbox-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dropbox-2</span><span class="i-code">0xf16b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf16c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stackoverflow-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stackoverflow-2</span><span class="i-code">0xf16c</span></div>
        <div title="Code: 0xf16d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-5</span><span class="i-code">0xf16d</span></div>
        <div title="Code: 0xf16e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flickr-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flickr-4</span><span class="i-code">0xf16e</span></div>
        <div title="Code: 0xf170" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-adn"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-adn</span><span class="i-code">0xf170</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf171" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bitbucket-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bitbucket-1</span><span class="i-code">0xf171</span></div>
        <div title="Code: 0xf172" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bitbucket-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bitbucket-squared</span><span class="i-code">0xf172</span></div>
        <div title="Code: 0xf173" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-4</span><span class="i-code">0xf173</span></div>
        <div title="Code: 0xf174" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-squared</span><span class="i-code">0xf174</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf175" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-down-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-down-6</span><span class="i-code">0xf175</span></div>
        <div title="Code: 0xf176" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-up-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-up-6</span><span class="i-code">0xf176</span></div>
        <div title="Code: 0xf177" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-5</span><span class="i-code">0xf177</span></div>
        <div title="Code: 0xf178" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-5</span><span class="i-code">0xf178</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf179" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-apple"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-apple</span><span class="i-code">0xf179</span></div>
        <div title="Code: 0xf17a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-windows-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-windows-1</span><span class="i-code">0xf17a</span></div>
        <div title="Code: 0xf17b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-android-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-android-1</span><span class="i-code">0xf17b</span></div>
        <div title="Code: 0xf17c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linux"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linux</span><span class="i-code">0xf17c</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf17d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dribbble-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dribbble-5</span><span class="i-code">0xf17d</span></div>
        <div title="Code: 0xf17e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-6"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-6</span><span class="i-code">0xf17e</span></div>
        <div title="Code: 0xf180" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-foursquare-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-foursquare-2</span><span class="i-code">0xf180</span></div>
        <div title="Code: 0xf181" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trello"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trello</span><span class="i-code">0xf181</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf182" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-female-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-female-2</span><span class="i-code">0xf182</span></div>
        <div title="Code: 0xf183" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-male-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-male-2</span><span class="i-code">0xf183</span></div>
        <div title="Code: 0xf184" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gittip"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gittip</span><span class="i-code">0xf184</span></div>
        <div title="Code: 0xf185" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sun-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sun-3</span><span class="i-code">0xf185</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf186" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-moon-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-moon-4</span><span class="i-code">0xf186</span></div>
        <div title="Code: 0xf187" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box-4</span><span class="i-code">0xf187</span></div>
        <div title="Code: 0xf188" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bug"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bug</span><span class="i-code">0xf188</span></div>
        <div title="Code: 0xf189" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vkontakte-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vkontakte-2</span><span class="i-code">0xf189</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf18a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-weibo-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-weibo-1</span><span class="i-code">0xf18a</span></div>
        <div title="Code: 0xf18b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-renren-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-renren-1</span><span class="i-code">0xf18b</span></div>
        <div title="Code: 0xf18c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pagelines"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pagelines</span><span class="i-code">0xf18c</span></div>
        <div title="Code: 0xf18d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stackexchange"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stackexchange</span><span class="i-code">0xf18d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf18e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-right-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-right-circled2</span><span class="i-code">0xf18e</span></div>
        <div title="Code: 0xf190" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-left-circled2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-left-circled2</span><span class="i-code">0xf190</span></div>
        <div title="Code: 0xf191" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-collapse-left"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-collapse-left</span><span class="i-code">0xf191</span></div>
        <div title="Code: 0xf192" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dot-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dot-circled</span><span class="i-code">0xf192</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf193" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wheelchair"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wheelchair</span><span class="i-code">0xf193</span></div>
        <div title="Code: 0xf194" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-squared</span><span class="i-code">0xf194</span></div>
        <div title="Code: 0xf195" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-try"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-try</span><span class="i-code">0xf195</span></div>
        <div title="Code: 0xf196" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plus-squared-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plus-squared-alt</span><span class="i-code">0xf196</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf197" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-space-shuttle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-space-shuttle</span><span class="i-code">0xf197</span></div>
        <div title="Code: 0xf198" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-slack"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-slack</span><span class="i-code">0xf198</span></div>
        <div title="Code: 0xf199" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mail-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mail-squared</span><span class="i-code">0xf199</span></div>
        <div title="Code: 0xf19a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wordpress-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wordpress-3</span><span class="i-code">0xf19a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf19b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-openid-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-openid-1</span><span class="i-code">0xf19b</span></div>
        <div title="Code: 0xf19c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bank"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bank</span><span class="i-code">0xf19c</span></div>
        <div title="Code: 0xf19d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-graduation-cap-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-graduation-cap-2</span><span class="i-code">0xf19d</span></div>
        <div title="Code: 0xf19e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yahoo-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yahoo-1</span><span class="i-code">0xf19e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1a0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-google-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-google-1</span><span class="i-code">0xf1a0</span></div>
        <div title="Code: 0xf1a1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reddit-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reddit-2</span><span class="i-code">0xf1a1</span></div>
        <div title="Code: 0xf1a2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reddit-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reddit-squared</span><span class="i-code">0xf1a2</span></div>
        <div title="Code: 0xf1a3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon-circled-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon-circled-1</span><span class="i-code">0xf1a3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1a4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stumbleupon-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stumbleupon-3</span><span class="i-code">0xf1a4</span></div>
        <div title="Code: 0xf1a5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-delicious-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-delicious-2</span><span class="i-code">0xf1a5</span></div>
        <div title="Code: 0xf1a6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-digg-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-digg-2</span><span class="i-code">0xf1a6</span></div>
        <div title="Code: 0xf1a7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pied-piper-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pied-piper-squared</span><span class="i-code">0xf1a7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1a8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pied-piper-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pied-piper-alt</span><span class="i-code">0xf1a8</span></div>
        <div title="Code: 0xf1a9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-drupal-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-drupal-1</span><span class="i-code">0xf1a9</span></div>
        <div title="Code: 0xf1aa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-joomla"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-joomla</span><span class="i-code">0xf1aa</span></div>
        <div title="Code: 0xf1ab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-language-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-language-1</span><span class="i-code">0xf1ab</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1ac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fax"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fax</span><span class="i-code">0xf1ac</span></div>
        <div title="Code: 0xf1ad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-building-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-building-filled</span><span class="i-code">0xf1ad</span></div>
        <div title="Code: 0xf1ae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-child-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-child-1</span><span class="i-code">0xf1ae</span></div>
        <div title="Code: 0xf1b0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paw"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paw</span><span class="i-code">0xf1b0</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1b1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spoon"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spoon</span><span class="i-code">0xf1b1</span></div>
        <div title="Code: 0xf1b2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cube"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cube</span><span class="i-code">0xf1b2</span></div>
        <div title="Code: 0xf1b3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cubes"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cubes</span><span class="i-code">0xf1b3</span></div>
        <div title="Code: 0xf1b4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-behance-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-behance-2</span><span class="i-code">0xf1b4</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1b5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-behance-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-behance-squared</span><span class="i-code">0xf1b5</span></div>
        <div title="Code: 0xf1b6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-steam-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-steam-1</span><span class="i-code">0xf1b6</span></div>
        <div title="Code: 0xf1b7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-steam-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-steam-squared</span><span class="i-code">0xf1b7</span></div>
        <div title="Code: 0xf1b8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-recycle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-recycle</span><span class="i-code">0xf1b8</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1b9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cab"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cab</span><span class="i-code">0xf1b9</span></div>
        <div title="Code: 0xf1ba" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-taxi"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-taxi</span><span class="i-code">0xf1ba</span></div>
        <div title="Code: 0xf1bb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tree-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tree-3</span><span class="i-code">0xf1bb</span></div>
        <div title="Code: 0xf1bc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spotify-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spotify-2</span><span class="i-code">0xf1bc</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1bd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-deviantart-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-deviantart-2</span><span class="i-code">0xf1bd</span></div>
        <div title="Code: 0xf1be" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soundcloud-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soundcloud-3</span><span class="i-code">0xf1be</span></div>
        <div title="Code: 0xf1c0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-database-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-database-3</span><span class="i-code">0xf1c0</span></div>
        <div title="Code: 0xf1c1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-pdf"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-pdf</span><span class="i-code">0xf1c1</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1c2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-word"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-word</span><span class="i-code">0xf1c2</span></div>
        <div title="Code: 0xf1c3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-excel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-excel</span><span class="i-code">0xf1c3</span></div>
        <div title="Code: 0xf1c4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-powerpoint"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-powerpoint</span><span class="i-code">0xf1c4</span></div>
        <div title="Code: 0xf1c5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-image"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-image</span><span class="i-code">0xf1c5</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1c6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-archive"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-archive</span><span class="i-code">0xf1c6</span></div>
        <div title="Code: 0xf1c7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-audio"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-audio</span><span class="i-code">0xf1c7</span></div>
        <div title="Code: 0xf1c8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-video"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-video</span><span class="i-code">0xf1c8</span></div>
        <div title="Code: 0xf1c9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-file-code"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-file-code</span><span class="i-code">0xf1c9</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1ca" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vine"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vine</span><span class="i-code">0xf1ca</span></div>
        <div title="Code: 0xf1cb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-codeopen"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-codeopen</span><span class="i-code">0xf1cb</span></div>
        <div title="Code: 0xf1cc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-jsfiddle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-jsfiddle</span><span class="i-code">0xf1cc</span></div>
        <div title="Code: 0xf1cd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lifebuoy-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lifebuoy-2</span><span class="i-code">0xf1cd</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1ce" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-circle-notch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-circle-notch</span><span class="i-code">0xf1ce</span></div>
        <div title="Code: 0xf1d0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-rebel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-rebel</span><span class="i-code">0xf1d0</span></div>
        <div title="Code: 0xf1d1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-empire"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-empire</span><span class="i-code">0xf1d1</span></div>
        <div title="Code: 0xf1d2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-git-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-git-squared</span><span class="i-code">0xf1d2</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1d3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-git"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-git</span><span class="i-code">0xf1d3</span></div>
        <div title="Code: 0xf1d4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hacker-news"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hacker-news</span><span class="i-code">0xf1d4</span></div>
        <div title="Code: 0xf1d5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tencent-weibo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tencent-weibo</span><span class="i-code">0xf1d5</span></div>
        <div title="Code: 0xf1d6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-qq-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-qq-1</span><span class="i-code">0xf1d6</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1d7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wechat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wechat</span><span class="i-code">0xf1d7</span></div>
        <div title="Code: 0xf1d8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-3</span><span class="i-code">0xf1d8</span></div>
        <div title="Code: 0xf1d9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paper-plane-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paper-plane-empty</span><span class="i-code">0xf1d9</span></div>
        <div title="Code: 0xf1da" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-history"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-history</span><span class="i-code">0xf1da</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1db" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-circle-thin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-circle-thin</span><span class="i-code">0xf1db</span></div>
        <div title="Code: 0xf1dc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-header"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-header</span><span class="i-code">0xf1dc</span></div>
        <div title="Code: 0xf1dd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paragraph"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paragraph</span><span class="i-code">0xf1dd</span></div>
        <div title="Code: 0xf1de" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sliders"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sliders</span><span class="i-code">0xf1de</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1e0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-share-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-share-3</span><span class="i-code">0xf1e0</span></div>
        <div title="Code: 0xf1e1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-share-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-share-squared</span><span class="i-code">0xf1e1</span></div>
        <div title="Code: 0xf1e2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bomb"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bomb</span><span class="i-code">0xf1e2</span></div>
        <div title="Code: 0xf1e3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soccer-ball"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soccer-ball</span><span class="i-code">0xf1e3</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1e4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tty</span><span class="i-code">0xf1e4</span></div>
        <div title="Code: 0xf1e5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-binoculars"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-binoculars</span><span class="i-code">0xf1e5</span></div>
        <div title="Code: 0xf1e6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-plug-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-plug-1</span><span class="i-code">0xf1e6</span></div>
        <div title="Code: 0xf1e7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-slideshare-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-slideshare-1</span><span class="i-code">0xf1e7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1e8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitch"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitch</span><span class="i-code">0xf1e8</span></div>
        <div title="Code: 0xf1e9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yelp-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yelp-1</span><span class="i-code">0xf1e9</span></div>
        <div title="Code: 0xf1ea" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-newspaper-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-newspaper-2</span><span class="i-code">0xf1ea</span></div>
        <div title="Code: 0xf1eb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wifi-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wifi-1</span><span class="i-code">0xf1eb</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1ec" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calc"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calc</span><span class="i-code">0xf1ec</span></div>
        <div title="Code: 0xf1ed" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paypal-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paypal-2</span><span class="i-code">0xf1ed</span></div>
        <div title="Code: 0xf1ee" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gwallet"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gwallet</span><span class="i-code">0xf1ee</span></div>
        <div title="Code: 0xf1f0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-visa"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-visa</span><span class="i-code">0xf1f0</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1f1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-mastercard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-mastercard</span><span class="i-code">0xf1f1</span></div>
        <div title="Code: 0xf1f2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-discover"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-discover</span><span class="i-code">0xf1f2</span></div>
        <div title="Code: 0xf1f3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-amex"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-amex</span><span class="i-code">0xf1f3</span></div>
        <div title="Code: 0xf1f4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-paypal"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-paypal</span><span class="i-code">0xf1f4</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1f5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-stripe"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-stripe</span><span class="i-code">0xf1f5</span></div>
        <div title="Code: 0xf1f6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-off</span><span class="i-code">0xf1f6</span></div>
        <div title="Code: 0xf1f7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bell-off-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bell-off-empty</span><span class="i-code">0xf1f7</span></div>
        <div title="Code: 0xf1f8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trash-8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trash-8</span><span class="i-code">0xf1f8</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1f9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-copyright"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-copyright</span><span class="i-code">0xf1f9</span></div>
        <div title="Code: 0xf1fa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-at-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-at-4</span><span class="i-code">0xf1fa</span></div>
        <div title="Code: 0xf1fb" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-eyedropper-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-eyedropper-1</span><span class="i-code">0xf1fb</span></div>
        <div title="Code: 0xf1fc" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-brush-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-brush-3</span><span class="i-code">0xf1fc</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf1fd" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-birthday"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-birthday</span><span class="i-code">0xf1fd</span></div>
        <div title="Code: 0xf1fe" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-area-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-area-1</span><span class="i-code">0xf1fe</span></div>
        <div title="Code: 0xf200" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-pie-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-pie-4</span><span class="i-code">0xf200</span></div>
        <div title="Code: 0xf201" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-line-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-line-1</span><span class="i-code">0xf201</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf202" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-4</span><span class="i-code">0xf202</span></div>
        <div title="Code: 0xf203" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-squared"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-squared</span><span class="i-code">0xf203</span></div>
        <div title="Code: 0xf204" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-toggle-off"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-toggle-off</span><span class="i-code">0xf204</span></div>
        <div title="Code: 0xf205" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-toggle-on"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-toggle-on</span><span class="i-code">0xf205</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf206" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bicycle-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bicycle-1</span><span class="i-code">0xf206</span></div>
        <div title="Code: 0xf207" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bus-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bus-1</span><span class="i-code">0xf207</span></div>
        <div title="Code: 0xf208" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ioxhost"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ioxhost</span><span class="i-code">0xf208</span></div>
        <div title="Code: 0xf209" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-angellist-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-angellist-1</span><span class="i-code">0xf209</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf20a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-3</span><span class="i-code">0xf20a</span></div>
        <div title="Code: 0xf20b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shekel"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shekel</span><span class="i-code">0xf20b</span></div>
        <div title="Code: 0xf20c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-meanpath"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-meanpath</span><span class="i-code">0xf20c</span></div>
        <div title="Code: 0xf20d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-buysellads"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-buysellads</span><span class="i-code">0xf20d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf20e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-connectdevelop"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-connectdevelop</span><span class="i-code">0xf20e</span></div>
        <div title="Code: 0xf210" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dashcube"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dashcube</span><span class="i-code">0xf210</span></div>
        <div title="Code: 0xf211" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-forumbee"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-forumbee</span><span class="i-code">0xf211</span></div>
        <div title="Code: 0xf212" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-leanpub"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-leanpub</span><span class="i-code">0xf212</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf213" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sellsy"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sellsy</span><span class="i-code">0xf213</span></div>
        <div title="Code: 0xf214" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shirtsinbulk"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shirtsinbulk</span><span class="i-code">0xf214</span></div>
        <div title="Code: 0xf215" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-simplybuilt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-simplybuilt</span><span class="i-code">0xf215</span></div>
        <div title="Code: 0xf216" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skyatlas"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skyatlas</span><span class="i-code">0xf216</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf217" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cart-plus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cart-plus</span><span class="i-code">0xf217</span></div>
        <div title="Code: 0xf218" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cart-arrow-down"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cart-arrow-down</span><span class="i-code">0xf218</span></div>
        <div title="Code: 0xf219" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-diamond-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-diamond-1</span><span class="i-code">0xf219</span></div>
        <div title="Code: 0xf21a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-ship"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-ship</span><span class="i-code">0xf21a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf21b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-secret"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-secret</span><span class="i-code">0xf21b</span></div>
        <div title="Code: 0xf21c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-motorcycle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-motorcycle</span><span class="i-code">0xf21c</span></div>
        <div title="Code: 0xf21d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-street-view"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-street-view</span><span class="i-code">0xf21d</span></div>
        <div title="Code: 0xf21e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-heartbeat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-heartbeat</span><span class="i-code">0xf21e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf221" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-venus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-venus</span><span class="i-code">0xf221</span></div>
        <div title="Code: 0xf222" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mars"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mars</span><span class="i-code">0xf222</span></div>
        <div title="Code: 0xf223" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mercury"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mercury</span><span class="i-code">0xf223</span></div>
        <div title="Code: 0xf228" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-venus-mars"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-venus-mars</span><span class="i-code">0xf228</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf229" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mars-stroke"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mars-stroke</span><span class="i-code">0xf229</span></div>
        <div title="Code: 0xf22a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mars-stroke-v"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mars-stroke-v</span><span class="i-code">0xf22a</span></div>
        <div title="Code: 0xf22b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mars-stroke-h"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mars-stroke-h</span><span class="i-code">0xf22b</span></div>
        <div title="Code: 0xf22c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-neuter"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-neuter</span><span class="i-code">0xf22c</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf22d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-genderless"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-genderless</span><span class="i-code">0xf22d</span></div>
        <div title="Code: 0xf230" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-official"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-official</span><span class="i-code">0xf230</span></div>
        <div title="Code: 0xf231" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pinterest-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pinterest-4</span><span class="i-code">0xf231</span></div>
        <div title="Code: 0xf232" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-whatsapp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-whatsapp</span><span class="i-code">0xf232</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf233" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-server"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-server</span><span class="i-code">0xf233</span></div>
        <div title="Code: 0xf234" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-plus"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-plus</span><span class="i-code">0xf234</span></div>
        <div title="Code: 0xf235" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-user-times"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-user-times</span><span class="i-code">0xf235</span></div>
        <div title="Code: 0xf236" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bed"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bed</span><span class="i-code">0xf236</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf237" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-viacoin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-viacoin</span><span class="i-code">0xf237</span></div>
        <div title="Code: 0xf238" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-train"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-train</span><span class="i-code">0xf238</span></div>
        <div title="Code: 0xf239" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-subway"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-subway</span><span class="i-code">0xf239</span></div>
        <div title="Code: 0xf23a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-medium"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-medium</span><span class="i-code">0xf23a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf23b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-y-combinator"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-y-combinator</span><span class="i-code">0xf23b</span></div>
        <div title="Code: 0xf23c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-optin-monster"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-optin-monster</span><span class="i-code">0xf23c</span></div>
        <div title="Code: 0xf23d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-opencart"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-opencart</span><span class="i-code">0xf23d</span></div>
        <div title="Code: 0xf23e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-expeditedssl"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-expeditedssl</span><span class="i-code">0xf23e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf240" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery-4</span><span class="i-code">0xf240</span></div>
        <div title="Code: 0xf241" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery-3</span><span class="i-code">0xf241</span></div>
        <div title="Code: 0xf242" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery-2</span><span class="i-code">0xf242</span></div>
        <div title="Code: 0xf243" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery-1</span><span class="i-code">0xf243</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf244" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-battery-0"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-battery-0</span><span class="i-code">0xf244</span></div>
        <div title="Code: 0xf245" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mouse-pointer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mouse-pointer</span><span class="i-code">0xf245</span></div>
        <div title="Code: 0xf246" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-i-cursor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-i-cursor</span><span class="i-code">0xf246</span></div>
        <div title="Code: 0xf247" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-object-group"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-object-group</span><span class="i-code">0xf247</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf248" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-object-ungroup"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-object-ungroup</span><span class="i-code">0xf248</span></div>
        <div title="Code: 0xf249" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sticky-note"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sticky-note</span><span class="i-code">0xf249</span></div>
        <div title="Code: 0xf24a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sticky-note-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sticky-note-o</span><span class="i-code">0xf24a</span></div>
        <div title="Code: 0xf24b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-jcb"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-jcb</span><span class="i-code">0xf24b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf24c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-cc-diners-club"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-cc-diners-club</span><span class="i-code">0xf24c</span></div>
        <div title="Code: 0xf24d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-clone"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-clone</span><span class="i-code">0xf24d</span></div>
        <div title="Code: 0xf24e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-balance-scale"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-balance-scale</span><span class="i-code">0xf24e</span></div>
        <div title="Code: 0xf250" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-o</span><span class="i-code">0xf250</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf251" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-5</span><span class="i-code">0xf251</span></div>
        <div title="Code: 0xf252" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-4</span><span class="i-code">0xf252</span></div>
        <div title="Code: 0xf253" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-3</span><span class="i-code">0xf253</span></div>
        <div title="Code: 0xf254" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hourglass-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hourglass-2</span><span class="i-code">0xf254</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf255" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-grab-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-grab-o</span><span class="i-code">0xf255</span></div>
        <div title="Code: 0xf256" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-paper-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-paper-o</span><span class="i-code">0xf256</span></div>
        <div title="Code: 0xf257" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-scissors-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-scissors-o</span><span class="i-code">0xf257</span></div>
        <div title="Code: 0xf258" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-lizard-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-lizard-o</span><span class="i-code">0xf258</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf259" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-spock-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-spock-o</span><span class="i-code">0xf259</span></div>
        <div title="Code: 0xf25a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-pointer-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-pointer-o</span><span class="i-code">0xf25a</span></div>
        <div title="Code: 0xf25b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hand-peace-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hand-peace-o</span><span class="i-code">0xf25b</span></div>
        <div title="Code: 0xf25c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-trademark"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-trademark</span><span class="i-code">0xf25c</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf25d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-registered"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-registered</span><span class="i-code">0xf25d</span></div>
        <div title="Code: 0xf25e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-creative-commons"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-creative-commons</span><span class="i-code">0xf25e</span></div>
        <div title="Code: 0xf260" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gg"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gg</span><span class="i-code">0xf260</span></div>
        <div title="Code: 0xf261" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gg-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gg-circle</span><span class="i-code">0xf261</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf262" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tripadvisor"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tripadvisor</span><span class="i-code">0xf262</span></div>
        <div title="Code: 0xf263" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-odnoklassniki-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-odnoklassniki-1</span><span class="i-code">0xf263</span></div>
        <div title="Code: 0xf264" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-odnoklassniki-square"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-odnoklassniki-square</span><span class="i-code">0xf264</span></div>
        <div title="Code: 0xf265" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-get-pocket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-get-pocket</span><span class="i-code">0xf265</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf266" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wikipedia-w"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wikipedia-w</span><span class="i-code">0xf266</span></div>
        <div title="Code: 0xf267" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-safari"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-safari</span><span class="i-code">0xf267</span></div>
        <div title="Code: 0xf268" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chrome-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chrome-1</span><span class="i-code">0xf268</span></div>
        <div title="Code: 0xf269" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-firefox"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-firefox</span><span class="i-code">0xf269</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf26a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-opera"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-opera</span><span class="i-code">0xf26a</span></div>
        <div title="Code: 0xf26b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-internet-explorer"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-internet-explorer</span><span class="i-code">0xf26b</span></div>
        <div title="Code: 0xf26c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-television"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-television</span><span class="i-code">0xf26c</span></div>
        <div title="Code: 0xf26d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-contao"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-contao</span><span class="i-code">0xf26d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf26e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-500px"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-500px</span><span class="i-code">0xf26e</span></div>
        <div title="Code: 0xf270" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-amazon-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-amazon-1</span><span class="i-code">0xf270</span></div>
        <div title="Code: 0xf271" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-plus-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-plus-o</span><span class="i-code">0xf271</span></div>
        <div title="Code: 0xf272" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-minus-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-minus-o</span><span class="i-code">0xf272</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf273" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-times-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-times-o</span><span class="i-code">0xf273</span></div>
        <div title="Code: 0xf274" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-check-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-check-o</span><span class="i-code">0xf274</span></div>
        <div title="Code: 0xf275" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-industry"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-industry</span><span class="i-code">0xf275</span></div>
        <div title="Code: 0xf276" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map-pin"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map-pin</span><span class="i-code">0xf276</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf277" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map-signs"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map-signs</span><span class="i-code">0xf277</span></div>
        <div title="Code: 0xf278" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map-o</span><span class="i-code">0xf278</span></div>
        <div title="Code: 0xf279" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-map-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-map-2</span><span class="i-code">0xf279</span></div>
        <div title="Code: 0xf27a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-commenting"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-commenting</span><span class="i-code">0xf27a</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf27b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-commenting-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-commenting-o</span><span class="i-code">0xf27b</span></div>
        <div title="Code: 0xf27c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-houzz-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-houzz-1</span><span class="i-code">0xf27c</span></div>
        <div title="Code: 0xf27d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-5</span><span class="i-code">0xf27d</span></div>
        <div title="Code: 0xf27e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-black-tie"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-black-tie</span><span class="i-code">0xf27e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf280" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fonticons"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fonticons</span><span class="i-code">0xf280</span></div>
        <div title="Code: 0xf281" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-reddit-alien"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-reddit-alien</span><span class="i-code">0xf281</span></div>
        <div title="Code: 0xf282" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-edge"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-edge</span><span class="i-code">0xf282</span></div>
        <div title="Code: 0xf283" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-credit-card-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-credit-card-alt</span><span class="i-code">0xf283</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf284" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-codiepie"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-codiepie</span><span class="i-code">0xf284</span></div>
        <div title="Code: 0xf285" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-modx"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-modx</span><span class="i-code">0xf285</span></div>
        <div title="Code: 0xf286" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fort-awesome"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fort-awesome</span><span class="i-code">0xf286</span></div>
        <div title="Code: 0xf287" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-usb"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-usb</span><span class="i-code">0xf287</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf288" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-product-hunt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-product-hunt</span><span class="i-code">0xf288</span></div>
        <div title="Code: 0xf289" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mixcloud"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mixcloud</span><span class="i-code">0xf289</span></div>
        <div title="Code: 0xf28a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-scribd-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-scribd-1</span><span class="i-code">0xf28a</span></div>
        <div title="Code: 0xf28b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-circle</span><span class="i-code">0xf28b</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf28c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pause-circle-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pause-circle-o</span><span class="i-code">0xf28c</span></div>
        <div title="Code: 0xf28d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-circle</span><span class="i-code">0xf28d</span></div>
        <div title="Code: 0xf28e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-stop-circle-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-stop-circle-o</span><span class="i-code">0xf28e</span></div>
        <div title="Code: 0xf290" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shopping-bag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shopping-bag</span><span class="i-code">0xf290</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf291" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-shopping-basket"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-shopping-basket</span><span class="i-code">0xf291</span></div>
        <div title="Code: 0xf292" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-hashtag"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-hashtag</span><span class="i-code">0xf292</span></div>
        <div title="Code: 0xf293" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bluetooth"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bluetooth</span><span class="i-code">0xf293</span></div>
        <div title="Code: 0xf294" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bluetooth-b"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bluetooth-b</span><span class="i-code">0xf294</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf295" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-percent"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-percent</span><span class="i-code">0xf295</span></div>
        <div title="Code: 0xf296" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-gitlab"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-gitlab</span><span class="i-code">0xf296</span></div>
        <div title="Code: 0xf297" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wpbeginner"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wpbeginner</span><span class="i-code">0xf297</span></div>
        <div title="Code: 0xf298" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wpforms"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wpforms</span><span class="i-code">0xf298</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf299" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-envira"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-envira</span><span class="i-code">0xf299</span></div>
        <div title="Code: 0xf29a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-universal-access-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-universal-access-1</span><span class="i-code">0xf29a</span></div>
        <div title="Code: 0xf29b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wheelchair-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wheelchair-alt</span><span class="i-code">0xf29b</span></div>
        <div title="Code: 0xf29c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-question-circle-o"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-question-circle-o</span><span class="i-code">0xf29c</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf29d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blind-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blind-1</span><span class="i-code">0xf29d</span></div>
        <div title="Code: 0xf29e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-audio-description"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-audio-description</span><span class="i-code">0xf29e</span></div>
        <div title="Code: 0xf2a0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-volume-control-phone"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-volume-control-phone</span><span class="i-code">0xf2a0</span></div>
        <div title="Code: 0xf2a1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-braille-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-braille-1</span><span class="i-code">0xf2a1</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf2a2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-assistive-listening-systems"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-assistive-listening-systems</span><span class="i-code">0xf2a2</span></div>
        <div title="Code: 0xf2a3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-american-sign-language-interpreting"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-american-sign-language-interpreting</span><span class="i-code">0xf2a3</span></div>
        <div title="Code: 0xf2a4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-asl-interpreting"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-asl-interpreting</span><span class="i-code">0xf2a4</span></div>
        <div title="Code: 0xf2a5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-glide"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-glide</span><span class="i-code">0xf2a5</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf2a6" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-glide-g"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-glide-g</span><span class="i-code">0xf2a6</span></div>
        <div title="Code: 0xf2a7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sign-language"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sign-language</span><span class="i-code">0xf2a7</span></div>
        <div title="Code: 0xf2a8" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-low-vision"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-low-vision</span><span class="i-code">0xf2a8</span></div>
        <div title="Code: 0xf2a9" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-viadeo-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-viadeo-1</span><span class="i-code">0xf2a9</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf2aa" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-viadeo-square"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-viadeo-square</span><span class="i-code">0xf2aa</span></div>
        <div title="Code: 0xf2ab" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snapchat"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snapchat</span><span class="i-code">0xf2ab</span></div>
        <div title="Code: 0xf2ac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snapchat-ghost"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snapchat-ghost</span><span class="i-code">0xf2ac</span></div>
        <div title="Code: 0xf2ad" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-snapchat-square"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-snapchat-square</span><span class="i-code">0xf2ad</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf2ae" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-pied-piper"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-pied-piper</span><span class="i-code">0xf2ae</span></div>
        <div title="Code: 0xf2b0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-first-order"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-first-order</span><span class="i-code">0xf2b0</span></div>
        <div title="Code: 0xf2b1" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yoast"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yoast</span><span class="i-code">0xf2b1</span></div>
        <div title="Code: 0xf2b2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-themeisle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-themeisle</span><span class="i-code">0xf2b2</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf2b3" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-google-plus-circle"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-google-plus-circle</span><span class="i-code">0xf2b3</span></div>
        <div title="Code: 0xf2b4" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-font-awesome"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-font-awesome</span><span class="i-code">0xf2b4</span></div>
        <div title="Code: 0xf300" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-1</span><span class="i-code">0xf300</span></div>
        <div title="Code: 0xf301" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-facebook-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-facebook-rect</span><span class="i-code">0xf301</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf302" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-1</span><span class="i-code">0xf302</span></div>
        <div title="Code: 0xf303" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-twitter-bird"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-twitter-bird</span><span class="i-code">0xf303</span></div>
        <div title="Code: 0xf304" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-icq"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-icq</span><span class="i-code">0xf304</span></div>
        <div title="Code: 0xf305" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yandex"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yandex</span><span class="i-code">0xf305</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf306" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-yandex-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-yandex-rect</span><span class="i-code">0xf306</span></div>
        <div title="Code: 0xf307" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-text-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-text-1</span><span class="i-code">0xf307</span></div>
        <div title="Code: 0xf308" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-github-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-github-1</span><span class="i-code">0xf308</span></div>
        <div title="Code: 0xf309" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-googleplus-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-googleplus-rect</span><span class="i-code">0xf309</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf30a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vkontakte-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vkontakte-rect</span><span class="i-code">0xf30a</span></div>
        <div title="Code: 0xf30b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype</span><span class="i-code">0xf30b</span></div>
        <div title="Code: 0xf30c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-odnoklassniki"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-odnoklassniki</span><span class="i-code">0xf30c</span></div>
        <div title="Code: 0xf30d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-odnoklassniki-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-odnoklassniki-rect</span><span class="i-code">0xf30d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf30e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-rect</span><span class="i-code">0xf30e</span></div>
        <div title="Code: 0xf30f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vimeo-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vimeo-1</span><span class="i-code">0xf30f</span></div>
        <div title="Code: 0xf310" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-rect</span><span class="i-code">0xf310</span></div>
        <div title="Code: 0xf311" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tumblr-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tumblr-1</span><span class="i-code">0xf311</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf312" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-rect</span><span class="i-code">0xf312</span></div>
        <div title="Code: 0xf313" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youtube"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youtube</span><span class="i-code">0xf313</span></div>
        <div title="Code: 0xf314" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blogger-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blogger-1</span><span class="i-code">0xf314</span></div>
        <div title="Code: 0xf315" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-blogger-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-blogger-rect</span><span class="i-code">0xf315</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf316" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-deviantart-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-deviantart-1</span><span class="i-code">0xf316</span></div>
        <div title="Code: 0xf317" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-jabber"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-jabber</span><span class="i-code">0xf317</span></div>
        <div title="Code: 0xf318" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm</span><span class="i-code">0xf318</span></div>
        <div title="Code: 0xf319" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lastfm-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lastfm-rect</span><span class="i-code">0xf319</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf31a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-1</span><span class="i-code">0xf31a</span></div>
        <div title="Code: 0xf31b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-linkedin-rect-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-linkedin-rect-1</span><span class="i-code">0xf31b</span></div>
        <div title="Code: 0xf31c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picasa-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picasa-1</span><span class="i-code">0xf31c</span></div>
        <div title="Code: 0xf31d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-wordpress-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-wordpress-1</span><span class="i-code">0xf31d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf31e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-1</span><span class="i-code">0xf31e</span></div>
        <div title="Code: 0xf31f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-filled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-filled</span><span class="i-code">0xf31f</span></div>
        <div title="Code: 0xf320" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-diigo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-diigo</span><span class="i-code">0xf320</span></div>
        <div title="Code: 0xf321" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box</span><span class="i-code">0xf321</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf322" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-box-rect"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-box-rect</span><span class="i-code">0xf322</span></div>
        <div title="Code: 0xf323" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-tudou"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-tudou</span><span class="i-code">0xf323</span></div>
        <div title="Code: 0xf324" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-youku"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-youku</span><span class="i-code">0xf324</span></div>
        <div title="Code: 0xf325" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-win8"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-win8</span><span class="i-code">0xf325</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf326" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-amex"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-amex</span><span class="i-code">0xf326</span></div>
        <div title="Code: 0xf327" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-discover"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-discover</span><span class="i-code">0xf327</span></div>
        <div title="Code: 0xf328" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-visa"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-visa</span><span class="i-code">0xf328</span></div>
        <div title="Code: 0xf329" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mastercard"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mastercard</span><span class="i-code">0xf329</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf32a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-houzz"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-houzz</span><span class="i-code">0xf32a</span></div>
        <div title="Code: 0xf32b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-bandcamp"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-bandcamp</span><span class="i-code">0xf32b</span></div>
        <div title="Code: 0xf32c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-codepen"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-codepen</span><span class="i-code">0xf32c</span></div>
        <div title="Code: 0xf32d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-instagram-4"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-instagram-4</span><span class="i-code">0xf32d</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf330" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-dropbox-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-dropbox-1</span><span class="i-code">0xf330</span></div>
        <div title="Code: 0xf333" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-evernote-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-evernote-1</span><span class="i-code">0xf333</span></div>
        <div title="Code: 0xf336" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-flattr-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-flattr-1</span><span class="i-code">0xf336</span></div>
        <div title="Code: 0xf339" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-5"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-5</span><span class="i-code">0xf339</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf33a" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-skype-circled"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-skype-circled</span><span class="i-code">0xf33a</span></div>
        <div title="Code: 0xf33c" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-renren"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-renren</span><span class="i-code">0xf33c</span></div>
        <div title="Code: 0xf33f" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sina-weibo"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sina-weibo</span><span class="i-code">0xf33f</span></div>
        <div title="Code: 0xf342" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-paypal-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-paypal-1</span><span class="i-code">0xf342</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf345" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-picasa-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-picasa-2</span><span class="i-code">0xf345</span></div>
        <div title="Code: 0xf348" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-soundcloud-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-soundcloud-2</span><span class="i-code">0xf348</span></div>
        <div title="Code: 0xf34b" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-mixi"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-mixi</span><span class="i-code">0xf34b</span></div>
        <div title="Code: 0xf34e" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-behance-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-behance-1</span><span class="i-code">0xf34e</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf351" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-google-circles"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-google-circles</span><span class="i-code">0xf351</span></div>
        <div title="Code: 0xf354" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-vkontakte-1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-vkontakte-1</span><span class="i-code">0xf354</span></div>
        <div title="Code: 0xf357" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-smashing"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-smashing</span><span class="i-code">0xf357</span></div>
        <div title="Code: 0xf4ac" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-comment-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-comment-3</span><span class="i-code">0xf4ac</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf4c2" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-folder-open-empty"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-folder-open-empty</span><span class="i-code">0xf4c2</span></div>
        <div title="Code: 0xf4c5" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-calendar-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-calendar-3</span><span class="i-code">0xf4c5</span></div>
        <div title="Code: 0xf4f0" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-newspaper"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-newspaper</span><span class="i-code">0xf4f0</span></div>
        <div title="Code: 0xf4f7" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-camera-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-camera-2</span><span class="i-code">0xf4f7</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf50d" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-search-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-search-3</span><span class="i-code">0xf50d</span></div>
        <div title="Code: 0xf510" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-alt"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-alt</span><span class="i-code">0xf510</span></div>
        <div title="Code: 0xf512" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-3"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-3</span><span class="i-code">0xf512</span></div>
        <div title="Code: 0xf513" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-lock-open-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-lock-open-2</span><span class="i-code">0xf513</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf514" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-joystick"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-joystick</span><span class="i-code">0xf514</span></div>
        <div title="Code: 0xf525" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-fire-2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-fire-2</span><span class="i-code">0xf525</span></div>
        <div title="Code: 0xf526" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-chart-bar"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-chart-bar</span><span class="i-code">0xf526</span></div>
        <div title="Code: 0xf527" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spread"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spread</span><span class="i-code">0xf527</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf528" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spinner1"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spinner1</span><span class="i-code">0xf528</span></div>
        <div title="Code: 0xf529" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-spinner2"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-spinner2</span><span class="i-code">0xf529</span></div>
        <div title="Code: 0xf600" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-db-shape"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-db-shape</span><span class="i-code">0xf600</span></div>
        <div title="Code: 0xf601" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-sweden"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-sweden</span><span class="i-code">0xf601</span></div>
      </div>
      <div class="row">
        <div title="Code: 0xf603" class="the-icons span3"><i onclick="insert_icon(this)" class="icon-logo-db"></i> <span class="i-name" onclick="insert_icon_name(this)">icon-logo-db</span><span class="i-code">0xf603</span></div>
      </div>
	  
	  <div class="row">
        <div class="the-icons span3"><i onclick="insert_icon(this)" class=""><b>[ X ]</b></i> <span class="" onclick="insert_icon(this)">reset</span></div>
      </div>
	  
    </div>	
	</div>
	</div>
	
	
	
	
  
  
<script>
var val = "";
var id = "<?php if (isset($_GET['input'])) { echo $_GET['input']; }  ?>";
function insert_icon(obj){
val = obj.getAttribute('class');
window.parent.document.getElementById("input_"+id).value = val;
window.parent.document.getElementById("icon_"+id).innerHTML = '<i class="'+val+'"></i>';
setTimeout(window.parent.document.getElementById("cboxClose").click(), 100);
}

function insert_icon_name(obj){
val = obj.innerText;
window.parent.document.getElementById("input_"+id).value = val;
window.parent.document.getElementById("icon_"+id).innerHTML = '<i class="'+val+'"></i>';
setTimeout(window.parent.document.getElementById("cboxClose").click(), 100);
}

function adaptive() {
var h_top = $("#search_ic").outerHeight(true) + 1;
var w_ic = $("#icons div.ic_list").outerWidth(true); 
var ag_win_h = $(window).height();	
var h_ic = ag_win_h - h_top;


$("#icons").css({height: h_ic + "px"});
//$(".ic_list").css({width: w_ic + "px",  margin: "0 auto"});
$("body").css({marginTop: h_top + "px"});
}

$(document).ready(function(){ adaptive(); });
$(window).on('resize', function(event) { adaptive(); });

//*---search in list---
$(".agt_search_next").css("display", "none");
function ag_search_in_list(input, list, cont, btn, btnn) {

var check_val = $("#"+input).val(); if (check_val.length < 3) { 
alert("<?php echo $ag_lng['empty_query']; ?>");
return false; 
}
var ag_body = $("body");
var search = $("#"+input),
content = $("#"+cont),
matches = "",
matches = $(), 
index = 0;	

var agt_search_go = $("#"+btn);

content.find("span").removeClass("ag_this_found");
content.find("span").removeClass("match");

if (search.val().length >= 3) {
$("#"+btnn).fadeIn(300);
$("#"+btn).css({display: "none"});
content.highlight(search.val(), function(found) {
matches = found;
if (matches.length && content.is(":not(:animated)")){ scroll(0); }
});
} 


function scroll(i) { index = i; 
$(".match").removeClass("ag_this_found");
content.scrollTo(matches.eq(i).closest("div.the-icons"), 300, { axis:"y" } ); 
matches.eq(i).addClass("ag_this_found");
}	
function scrollNext() { 
if (list == "ag_list_items_block") { matches.length && scroll( (index + 2) % matches.length ); }
else { matches.length && scroll( (index + 1) % matches.length ); }
}
$("#"+btnn).click(function(){ scrollNext(); });

var ag_found_count = content.find(".match").length;

var reset_list_sear = setInterval(function(){
    var curVal = search.val();
    var prevVal  = check_val || null;

if (prevVal != curVal) {
$("#"+btnn).css({display: "none"});
$("#"+btn).fadeIn(300);
matches = $();
content.find("span").removeClass("ag_this_found");
content.find("span").removeClass("match");
ag_found_count = 0;
clearInterval(reset_list_sear);
}

}, 100);

$("#"+btnn).html('<?php echo $ag_lng['next_search']; ?><i class="icon-forward-circled"></i>');	

if (ag_found_count == 0) { $("#"+btnn).html('<span class="ag_disabled"><?php echo $ag_lng['not_found_list']; ?></span>'); }
if (list == "ag_list_items_block") { if (ag_found_count == 2) {$("#"+btnn).html('<?php echo $ag_lng['end_found_list']; ?>');} }
else {if (ag_found_count == 1) {$("#"+btnn).html('<?php echo $ag_lng['end_found_list']; ?>');}}


}



</script> 
  
  </body>
</html>