<!DOCTYPE html>
<html lang="ru-RU">
<head>
	<meta charset="UTF-8">
	<title>Салон маникюра ООО"ШАННЭЙЛ 4"</title>
	<meta content="website" property="og:type">
	<meta content="https://channail4.ru/salon/" property="og:url">
	<meta content="Школа маникюра ШАННЭЙЛ 4" property="og:site_name">
	<meta name="description" content="Салон маникюра ООО'ШАННЭЙЛ 4'. Авторская школа маникюра в Москве Кутикульное Царство. Очное и онлайн обучение маникюрному икусству.">
	<meta property="og:description" content="Салон маникюра ООО'ШАННЭЙЛ 4'. Школа маникюра ШАННЭЙЛ 4. Авторская школа маникюра в Москве Кутикульное Царство. Очное и онлайн обучение маникюрному икусству.">
	<!-- <link rel="stylesheet" href="css/swiper-bundle.min.css"> -->
	<link rel="stylesheet" href="css/flickity.min.css">
	<link href='css/style.css' rel='stylesheet' type='text/css'>
	<link href="img/favicon.jpg" rel="icon" >
	<link rel="canonical" href="https://channail4.ru/salon/">
	<meta content="width=device-width, initial-scale=1.0, viewport-fit=cover" name="viewport">
</head>
<body class="home">
	<main>
		<div class="top">
			<a href="/" class="top_logo"><img src="img/gerb.png"></a>
			<img width="1024" height="1277" src="img/back1024.png" class="top_background">
			<!-- <img src="img/back320.png" class="top_background_mobile"> -->
			<h1 class="top_h1">салон<br>красоты</h1>
			<p class="top_p">Салон «СНАNNAIL4» находится на 51 этаже в Москва-сити. Помимо обычного маникюра и педикюра, салон предоставляет эксклюзивную услугу анатомической техники маникюра «Глубокая нить», после которой запускается процесс приостановки роста околоногтевой кожи.</p>
			<p class="top_quest">как действует техника</p>
			<h2 class="top_deep">«ГЛУБОКАЯ НИТЬ»?</h2>
		</div>
		<div class="middle">
			<p class="middle_info">«Глубокая нить» работает по пленочной анатомии, не нарушая природные процессы вашей кожи. Мы предлагаем две техники анатомического маникюра:<br>
			•  Слайсинг - мокрый вид, аналог классического маникюра.<br>
			•  Анатомическая фреза - аппаратный маникюр новой фрезой.<br>
			Техника решит все проблемы околоногтевой кожи.<br>
			Если вы обладатель плоской кутикулы, то мы изменим ее строение, она перестанет прилегать к ногтю и примет эстетичный вид. Мучаетесь с заусенцами? После пары сеансов в анатомической технике вы забудете о них. Нарастает птеригий? Перестанет сразу же. Не нравится голый ноготь, когда отрастает гель-лак? Согласны, сделаем вам покрытие, которое не будет отрастать 3 недели.</p>
			<img width="918" height="333" src="img/1_procedur.png" class="middle_img">
		</div>
		<div class="buttons">
			<h3 class="buttons_h3">КАК МЫ РАБОТАЕМ?</h3>
			<p class="buttons_p">Мы единственные в мире, кто работает по пленочной анатомии. Наше главное правило - кожа всегда права. Именно она решает с какой техникой лучше и носибельнее. Мы слышим не только пожелание клиента, но и его кожи.<br>Наша цель - создать вам более долгую носибельность, продлить свежесть маникюра и сделать ваши походы в салон реже.<br>Мастер проведет для вас эксперимент. В первый сеанс сделает на одной руке сухой вид (анатомическую фрезу), на другой мокрый вид (слайсинг). Через пару сеансов вы самостоятельно увидите какую технику маникюра предпочитает ваша кожа (может потребоваться пару сеансов).</p>
			<img width="330" height="248" src="img/photo.png" class="buttons_master">
			<a class="buttons_button" href="#">ЗАПИСЬ НА ПРИОСТАНОВКУ</a>
			<a class="buttons_button" href="#">ЗАПИСЬ НА СТАНДАРТНЫЙ МАНИКЮР</a>
		</div>
		<div class="pre-instrument">
			<p class="pre-instrument_instr">ИНСТРУМЕНТЫ</p>
			<p class="pre-instrument_channail">«СНАNNAIL4»</p>
			<hr class="pre-instrument_hr">
			<p class="pre-instrument_p">Гипоаллергенные, лёгкие, удобные в использовании из титановой имплантовой стали. Главное преимущество - они созданы мастером маникюра, человеком, влюбленным в свою профессию. Каждый миллиметр, каждая деталь инструмента продумана так, чтобы полностью исключить вероятность травмирования кожи клиента.</p>
		</div>
		<div class="carusel">
			<div class="carousel" data-flickity='{ "contain": true, "prevNextButtons": true,  "wrapAround": true, "cellAlign": "left", "arrowShape": "M 0 50 L 20 0 H 27 L 8 47 L 85 47 L 85 53 L 8 53 L 27 100 H 20 Z" }'>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/ship.png" class="carousel-cell_img" data-flickity-lazyload="img/ship.png">
			  		<p class="carousel-cell_name">щипчики<br>для слайсинга</p>
			  		<p class="carousel-cell_description">Без острых кончиков, притупленные на фетре, полностью исключают вероятность травмирования.</p>
			  	</div>
			  </div>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/blade.png" class="carousel-cell_img" data-flickity-lazyload="img/blade.png">
			  		<p class="carousel-cell_name">titanium<br>BLADE</p>
			  		<p class="carousel-cell_description">Очищает пластину от птеригия и подготавливает ее к обработке, не создавая пропилов.</p>
			  	</div>
			  </div>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/kist.png" class="carousel-cell_img" data-flickity-lazyload="img/kist.png">
			  		<p class="carousel-cell_name">титановая кисть<br>со сьемным<br>наконечником</p>
			  		<p class="carousel-cell_description">Сделана из синтетического ворса, не пачкает кутикулу.</p>
			  	</div>
			  </div>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/pilka.png" class="carousel-cell_img" data-flickity-lazyload="img/pilka.png">
			  		<p class="carousel-cell_name">титановая<br>пилка из<br> имплантовой<br>стали</p>
			  		<p class="carousel-cell_description">Основа для сменных файлов. Хорошо заходит в подногтевой карман.</p>
			  	</div>
			  </div>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/lopat.png" class="carousel-cell_img" data-flickity-lazyload="img/lopat.png">
			  		<p class="carousel-cell_name">титановая<br>лопатка для<br>педикюра</p>
			  		<p class="carousel-cell_description">Основа для сменных файлов. Покрыта карбоновым напылением.</p>
			  	</div>
			  </div>
			  <div class="carousel-cell">
			  	<div class="carousel-cell_container">
			  		<img width="256" height="363" src="img/anat.png" class="carousel-cell_img" data-flickity-lazyload="img/anat.png">
			  		<p class="carousel-cell_name">Двусторонняя<br>анатомическая<br>лопатка</p>
			  		<p class="carousel-cell_description">Чистит ногтевую пластину от птеригия.</p>
			  	</div>
			  </div>
			</div>
		</div>
		<div class="hand">
			<p class="hand_title">При вас<br>мастер<br>вскрывает<br>крафт-пакет</p>
			<p class="hand_description">'Инструменты проходят этоп дезинфекции. Пилки, бафики и лопатки для педикюра - одноразовые, со сменной основой.</p>
		</div>
		
		<div class="bottom">
			<hr class="hr_pre">
			<p class="contacts">НАШИ КОНТАКТЫ</p>
			<div class="contact_icons">
				<div class="contact_icons_img"><a href="tel:+79855861415"></a></div>
				<div class="contact_icons_img"><a href="https://www.instagram.com/chan_nail4school/" rel="nofollow" target="_blank"></a></div>
				<div class="contact_icons_img"><a href="https://wa.me/79855861415?text=Здравствуйте%2C%20хотела%20бы%20узнать%20" rel="nofollow" target="_blank"></a></div>
			</div>			
		</div>
		<div class="footer">
			<div class="footer_agree-container">
				<a class="footer_agree" href="https://goo.gl/maps/hRANBzD7e9aQiMZa6" rel="nofollow" target="_blank">Москва, Пресненская набережная д.8, строение 1,<br> Офис 513М, 51 этаж. Башня - Город Столиц. м.Деловой центр</a>
			</div>
			<div class="footer_info_container">
				<div class="footer_info_block">
					<p class="pre-instrument-info"><strong>ИП КРЕМИНСКАЯ И.Ю.</strong></p>
					<p class="pre-instrument-info">Адрес: г.Москва, поселок Толстопальцево, ул.Ленина, д.28, кв.1</p>
					<p class="pre-instrument-info">ИНН 972703148973</p>
					<p class="pre-instrument-info">ОКПО:2000553389</p>
					<p class="pre-instrument-info">ОГРНИП: 319774600726296</p>
					<p class="pre-instrument-info">Расчетный счет: 40802810738000074331</p>
					<p class="pre-instrument-info">Банк: ПАО Сбербанк</p>
					<p class="pre-instrument-info">БИК: 044525225</p>
					<p class="pre-instrument-info">Корр. счет: 30101810400000000225</p>
					<p class="pre-instrument-info">Телефон: (898551715449), 89855861415</p>
					<p class="pre-instrument-info">Email: <a href="mailto:channail4school@yandex.ru" class="elementor-heading-title elementor-size-default">channail4school@yandex.ru</a></p>
				</div>
				<div class="footer_info_block">
					<p class="pre-instrument-info"><strong>ООО «ШАННЭЙЛ 4 НЭЙЛ КУТЮР»&nbsp; </strong></p>
					<p class="pre-instrument-info">Юр. адрес: 123112, г. Москва,&nbsp; набережная Пресненская&nbsp; д.8, стр.1, комн.2, ч.пом.513м, э.51</p>
					<p class="pre-instrument-info">ИНН 9703001389</p>
					<p class="pre-instrument-info">КПП 770301001</p>
					<p class="pre-instrument-info">ОГРН 1197746551540</p>
					<p class="pre-instrument-info">Телефон: +7 (985) 586-14-15</p>
					<p class="pre-instrument-info">Email: <a href="mailto:channail4school@yandex.ru" class="elementor-heading-title elementor-size-default">channail4school@yandex.ru</a></p>
					<p class="pre-instrument-info"><strong>Генеральный директор Креминская Ирина Юрьевна</strong></p>
				</div>
			</div>
			<div class="footer_agree-container">
				<a href="../courses/agreement.html" target="_blank" class="footer_agree">Согласие на обработку персональных данных</a>
				<a href="../courses/oferta.html" target="_blank" class="footer_agree">Договор оферты</a>
				<a href="../courses/privacy.html" target="_blank" class="footer_agree">Политика защиты персональной информации</a>
			</div>
		
<div class="modal" id="modal1">
	<a class="close-modal" data-modal="#modal1" href="#" style="display: none;">
		<img src="img/close.png" width="30" class="modal_close"></a>
		<div class="modal__content">
		</div>
	</div>
</main>
<script src="js/jquery.min.js"></script>
<script src="js/popup.js"></script>
<script src="js/flickity.pkgd.min.js"></script>
</body>
</html>